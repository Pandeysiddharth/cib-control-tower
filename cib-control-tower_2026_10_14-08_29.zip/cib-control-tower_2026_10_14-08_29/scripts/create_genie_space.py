#!/usr/bin/env python3
import json, os, secrets, subprocess, sys

CATALOG = "control_tower_cib"
SCHEMA = "model_monitoring"
WAREHOUSE = "d1fcbbdbe403bdbc"
FQ = f"{CATALOG}.{SCHEMA}"

def hid():
    return secrets.token_hex(16)

tables = [
    "unified_metrics", "model_registry", "metric_allowlist", "alerts",
    "boundary_ledger", "rejected_fields_log", "serving_cost_daily",
    "v_model_daily_status", "v_current_status",
]
_ids = sorted(f"{FQ}.{t}" for t in tables)
data_sources = {"tables": [{"identifier": i, "column_configs": []} for i in _ids]}

instructions_text = [
    "## SCOPE AND SAFETY\n",
    "- Only aggregated model monitoring metrics exist in this hub. There is no customer data, no inference rows, no features, no predictions and no logs.\n",
    "- For questions about individual customers, accounts, transactions, specific predictions or raw logs, say that data does not exist in this hub and offer the aggregated view instead.\n",
    "- For 'why' questions, reason only from the metrics: when the deviation started, which slices and metrics moved, and which models share the same upstream_feed. Say that root-cause investigation on raw data must be done by the model owner inside the spoke workspace.\n",
    "\n",
    "## DEFAULTS\n",
    "- Use slice_name = 'overall' unless a segment such as country is explicitly asked for.\n",
    "- Always filter on a single metric_name; never mix different metrics in one aggregate.\n",
    "- Join on model_name, model_version and workspace. Show model_name together with workspace and region.\n",
    "- Round drift, psi, auc, f1, precision, recall and positive_rate to 3 decimals.\n",
    "\n",
    "## TIME\n",
    "- The data is a snapshot. Treat MAX(CAST(window_start AS DATE)) as 'today'; never use current_date().\n",
    "- 'last 7 days' = window dates after date_sub(latest date, 7). 'this week' = last 7 days. 'last month' = last 30 days.\n",
    "- Accuracy metrics (auc, f1, precision, recall) arrive weeks late because labels are delayed. Say so when it is relevant.\n",
    "\n",
    "## STATUS\n",
    "- status is OK, WARN or BREACH per metric. Use metric_allowlist.breach_direction to interpret thresholds (ABOVE = value above threshold breaches; BELOW = value below threshold breaches).\n",
    "- For 'right now', 'current' or 'latest', use v_current_status. Its current_status is STALE, BREACH, WARN or OK. STALE means the workspace stopped sending metrics and must NEVER be called healthy.\n",
    "- For history and trends, use unified_metrics or v_model_daily_status.\n",
    "- A workspace is stale when its latest last_sync_at in boundary_ledger is more than 30 hours before the newest last_sync_at across all workspaces.\n",
    "\n",
    "## OTHER TABLES\n",
    "- alerts: metric_name = 'sync_stale' means the workspace stopped reporting.\n",
    "- boundary_ledger: raw_rows_exported and log_rows_exported are always 0; only aggregated metric rows move.\n",
    "- rejected_fields_log: fields the export gate blocked (field names only, never values).\n",
    "- serving_cost_daily: keeps arriving even when metrics stop, so the endpoint is alive but the exporter is not.\n",
    "- model_registry.upstream_feed: models sharing a feed share upstream incidents, including across regions.\n",
]

instructions = {"text_instructions": [{"id": hid(), "content": instructions_text}]}

def q(question, sql):
    return {"id": hid(), "question": [question],
            "answer": [{"format": "SQL", "content": [sql]}]}

benchmarks = {"questions": [
    q("Which models are breaching right now, and in which region?",
      f"SELECT model_name, workspace, region, breached_metrics\nFROM {FQ}.v_current_status\nWHERE current_status = 'BREACH'\nORDER BY region, model_name"),
    q("Which model's prediction drift has increased the most in the last 14 days?",
      f"WITH latest AS (SELECT MAX(CAST(window_start AS DATE)) AS d FROM {FQ}.unified_metrics)\nSELECT model_name, workspace,\n  ROUND(AVG(CASE WHEN CAST(window_start AS DATE) > date_sub((SELECT d FROM latest), 7) THEN metric_value END), 3) AS last7,\n  ROUND(AVG(CASE WHEN CAST(window_start AS DATE) <= date_sub((SELECT d FROM latest), 7)\n                  AND CAST(window_start AS DATE) > date_sub((SELECT d FROM latest), 14) THEN metric_value END), 3) AS prev7,\n  ROUND(AVG(CASE WHEN CAST(window_start AS DATE) > date_sub((SELECT d FROM latest), 7) THEN metric_value END)\n      - AVG(CASE WHEN CAST(window_start AS DATE) <= date_sub((SELECT d FROM latest), 7)\n                  AND CAST(window_start AS DATE) > date_sub((SELECT d FROM latest), 14) THEN metric_value END), 3) AS increase\nFROM {FQ}.unified_metrics\nWHERE metric_name = 'prediction_drift_js' AND slice_name = 'overall'\nGROUP BY model_name, workspace\nORDER BY increase DESC"),
    q("Show AUC trend for all high-risk models.",
      f"SELECT u.model_name, u.workspace, CAST(u.window_start AS DATE) AS window_date, ROUND(u.metric_value, 3) AS auc\nFROM {FQ}.unified_metrics u\nJOIN {FQ}.model_registry r\n  ON u.model_name = r.model_name AND u.model_version = r.model_version AND u.workspace = r.workspace\nWHERE u.metric_name = 'auc' AND u.slice_name = 'overall' AND r.risk_tier = 'High'\nORDER BY u.model_name, window_date"),
    q("Which workspaces have stopped reporting?",
      f"WITH s AS (SELECT workspace, MAX(last_sync_at) AS last_sync FROM {FQ}.boundary_ledger GROUP BY workspace),\n     g AS (SELECT MAX(last_sync_at) AS newest FROM {FQ}.boundary_ledger)\nSELECT s.workspace, s.last_sync,\n  ROUND((unix_timestamp((SELECT newest FROM g)) - unix_timestamp(s.last_sync)) / 3600.0, 1) AS hours_behind\nFROM s CROSS JOIN g\nWHERE s.last_sync < (SELECT newest FROM g) - INTERVAL 30 HOURS\nORDER BY hours_behind DESC"),
    q("Compare drift across regions this week.",
      f"WITH latest AS (SELECT MAX(CAST(window_start AS DATE)) AS d FROM {FQ}.unified_metrics)\nSELECT region, ROUND(AVG(metric_value), 3) AS avg_prediction_drift_js\nFROM {FQ}.unified_metrics\nWHERE metric_name = 'prediction_drift_js' AND slice_name = 'overall'\n  AND CAST(window_start AS DATE) > date_sub((SELECT d FROM latest), 7)\nGROUP BY region\nORDER BY avg_prediction_drift_js DESC"),
    q("Which models share the same upstream feed as the one with the volume drop?",
      f"WITH drops AS (\n  SELECT DISTINCT r.upstream_feed\n  FROM {FQ}.v_current_status v\n  JOIN {FQ}.model_registry r\n    ON v.model_name = r.model_name AND v.model_version = r.model_version AND v.workspace = r.workspace\n  WHERE v.breached_metrics LIKE '%row_count%'\n)\nSELECT r.model_name, r.workspace, r.region, r.upstream_feed\nFROM {FQ}.model_registry r\nJOIN drops d ON r.upstream_feed = d.upstream_feed\nORDER BY r.upstream_feed, r.model_name"),
    q("Show country-level prediction drift for aml_alert_scorer on the latest date.",
      f"WITH latest AS (SELECT MAX(CAST(window_start AS DATE)) AS d FROM {FQ}.unified_metrics WHERE model_name = 'aml_alert_scorer')\nSELECT slice_value AS country, ROUND(metric_value, 3) AS prediction_drift_js, status\nFROM {FQ}.unified_metrics\nWHERE model_name = 'aml_alert_scorer' AND metric_name = 'prediction_drift_js'\n  AND slice_name = 'country' AND CAST(window_start AS DATE) = (SELECT d FROM latest)\nORDER BY prediction_drift_js DESC"),
    q("How many open alerts are there by severity?",
      f"SELECT severity, COUNT(*) AS open_alerts\nFROM {FQ}.alerts\nWHERE status IN ('OPEN', 'ACK')\nGROUP BY severity\nORDER BY CASE severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 ELSE 3 END"),
    q("Show the data boundary totals per workspace.",
      f"SELECT workspace, SUM(raw_rows_exported) AS raw_rows, SUM(log_rows_exported) AS log_rows,\n  SUM(metric_rows_exported) AS metric_rows, ROUND(SUM(bytes_transferred) / 1024.0, 1) AS kb_transferred\nFROM {FQ}.boundary_ledger\nGROUP BY workspace\nORDER BY workspace"),
    q("What is the serving cost by workspace for the last 30 days?",
      f"WITH latest AS (SELECT MAX(date) AS d FROM {FQ}.serving_cost_daily)\nSELECT workspace, ROUND(SUM(cost_usd), 2) AS cost_usd, ROUND(SUM(dbus), 1) AS dbus\nFROM {FQ}.serving_cost_daily\nWHERE date > date_sub((SELECT d FROM latest), 30)\nGROUP BY workspace\nORDER BY cost_usd DESC"),
    q("How many days was each model in breach in the last 30 days?",
      f"WITH latest AS (SELECT MAX(window_date) AS d FROM {FQ}.v_model_daily_status)\nSELECT model_name, workspace, COUNT(*) AS days_in_breach\nFROM {FQ}.v_model_daily_status\nWHERE worst_status = 'BREACH' AND window_date > date_sub((SELECT d FROM latest), 30)\nGROUP BY model_name, workspace\nORDER BY days_in_breach DESC"),
    q("Show the most recent fields blocked by the export gate.",
      f"SELECT workspace, run_date, field_name, reason\nFROM {FQ}.rejected_fields_log\nORDER BY run_date DESC\nLIMIT 50"),
]}

serialized = {
    "version": 2,
    "data_sources": data_sources,
    "instructions": instructions,
    "benchmarks": benchmarks,
}

description = ("Aggregated model monitoring metrics for every CIB classical ML model across Databricks "
    "workspaces and regions. Ask about drift, data quality, volume, freshness, accuracy, alerts, workspace "
    "sync health, serving cost and what data leaves each workspace. Contains only aggregated metrics: no "
    "customer data, no inference rows, no logs.")

req = {
    "warehouse_id": WAREHOUSE,
    "title": "Unified Model Monitoring Control Tower",
    "description": description,
    "serialized_space": json.dumps(serialized),
}
parent = os.environ.get("GENIE_PARENT_PATH")
if parent:
    req["parent_path"] = parent

with open("/tmp/space_req.json", "w") as f:
    json.dump(req, f)

out = subprocess.run(
    ["databricks", "genie", "create-space", "--json", "@/tmp/space_req.json", "-o", "json"],
    capture_output=True, text=True)
if out.returncode != 0:
    print("RC", out.returncode)
    print("STDERR:", out.stderr[:2000])
    sys.exit(out.returncode)
resp = json.loads(out.stdout)
print("SPACE_ID=" + resp.get("space_id", "?"))
sys.exit(0)
