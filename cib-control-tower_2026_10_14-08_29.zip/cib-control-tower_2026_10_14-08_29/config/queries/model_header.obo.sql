-- Header + current status for a single model.
-- @param p_model STRING = aml_alert_scorer
-- @param p_workspace STRING = cib-fcc-prod-uks
SELECT
  r.model_name, r.model_version, r.workspace, r.region, r.workstream,
  r.serving_type, r.owner, r.upstream_feed, r.risk_tier, r.onboarded_at,
  COALESCE(v.current_status, 'AWAITING') AS current_status,
  COALESCE(v.breach_count, 0) AS breach_count,
  COALESCE(v.warn_count, 0) AS warn_count,
  COALESCE(v.breached_metrics, '') AS breached_metrics,
  COALESCE(v.warned_metrics, '') AS warned_metrics,
  v.last_sync_at
FROM control_tower_cib.model_monitoring.model_registry r
LEFT JOIN control_tower_cib.model_monitoring.v_current_status v
  ON r.model_name = v.model_name AND r.model_version = v.model_version AND r.workspace = v.workspace
WHERE r.model_name = :p_model AND r.workspace = :p_workspace
LIMIT 1
