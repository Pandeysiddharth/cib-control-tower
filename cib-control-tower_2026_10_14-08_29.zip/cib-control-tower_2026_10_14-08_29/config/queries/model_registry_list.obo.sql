-- All registered models for selectors.
SELECT
  model_name, model_version, workspace, region, workstream, serving_type,
  owner, upstream_feed, risk_tier, onboarded_at, active
FROM control_tower_cib.model_monitoring.model_registry
ORDER BY workspace, model_name
