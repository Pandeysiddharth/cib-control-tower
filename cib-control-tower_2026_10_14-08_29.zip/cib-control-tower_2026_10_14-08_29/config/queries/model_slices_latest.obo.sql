-- Latest-date slice values for one model (country slices).
-- @param p_model STRING = aml_alert_scorer
-- @param p_workspace STRING = cib-fcc-prod-uks
WITH latest AS (
  SELECT MAX(CAST(window_start AS DATE)) AS d
  FROM control_tower_cib.model_monitoring.unified_metrics
  WHERE model_name = :p_model AND workspace = :p_workspace AND slice_name = 'country'
)
SELECT
  slice_name, slice_value, metric_name,
  metric_value, threshold, status
FROM control_tower_cib.model_monitoring.unified_metrics
WHERE model_name = :p_model AND workspace = :p_workspace AND slice_name = 'country'
  AND CAST(window_start AS DATE) = (SELECT d FROM latest)
ORDER BY metric_name, slice_value
