-- Daily serving cost trend by workspace over the date range.
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
-- @param p_region STRING
-- @param p_workspace STRING
-- @param p_workstream STRING
-- @param p_risk STRING
SELECT
  c.date,
  c.workspace,
  ROUND(SUM(c.cost_usd), 2) AS cost_usd
FROM control_tower_cib.model_monitoring.serving_cost_daily c
JOIN control_tower_cib.model_monitoring.model_registry r
  ON c.model_name = r.model_name AND c.workspace = r.workspace
WHERE c.date BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
  AND (:p_region = '' OR c.region = :p_region)
  AND (:p_workspace = '' OR c.workspace = :p_workspace)
  AND (:p_workstream = '' OR r.workstream = :p_workstream)
  AND (:p_risk = '' OR r.risk_tier = :p_risk)
GROUP BY c.date, c.workspace
ORDER BY c.date, c.workspace
