-- Workspaces reporting (synced within 30h of the newest) vs expected (all registered).
WITH g AS (SELECT MAX(last_sync_at) AS newest FROM control_tower_cib.model_monitoring.boundary_ledger),
     s AS (
       SELECT workspace, MAX(last_sync_at) AS last_sync
       FROM control_tower_cib.model_monitoring.boundary_ledger GROUP BY workspace
     ),
     expected AS (
       SELECT COUNT(DISTINCT workspace) AS n FROM control_tower_cib.model_monitoring.model_registry WHERE active = TRUE
     )
SELECT
  (SELECT n FROM expected) AS expected_workspaces,
  SUM(CASE WHEN s.last_sync >= g.newest - INTERVAL 30 HOURS THEN 1 ELSE 0 END) AS reporting_workspaces
FROM s CROSS JOIN g
