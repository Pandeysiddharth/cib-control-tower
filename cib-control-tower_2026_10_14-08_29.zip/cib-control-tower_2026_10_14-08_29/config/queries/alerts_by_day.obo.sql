-- Alerts opened per day by severity.
-- @param p_region STRING
-- @param p_workspace STRING
SELECT
  CAST(opened_at AS DATE) AS opened_date,
  severity,
  COUNT(*) AS n
FROM control_tower_cib.model_monitoring.alerts
WHERE (:p_region = '' OR region = :p_region)
  AND (:p_workspace = '' OR workspace = :p_workspace)
GROUP BY CAST(opened_at AS DATE), severity
ORDER BY opened_date
