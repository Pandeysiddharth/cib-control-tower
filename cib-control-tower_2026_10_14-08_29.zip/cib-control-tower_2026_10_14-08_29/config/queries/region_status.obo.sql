-- Status counts per region and workspace (current), including STALE and AWAITING.
-- @param p_region STRING
-- @param p_workspace STRING
-- @param p_workstream STRING
-- @param p_risk STRING
SELECT
  r.region,
  r.workspace,
  COALESCE(v.current_status, 'AWAITING') AS current_status,
  COUNT(*) AS n
FROM control_tower_cib.model_monitoring.model_registry r
LEFT JOIN control_tower_cib.model_monitoring.v_current_status v
  ON r.model_name = v.model_name AND r.model_version = v.model_version AND r.workspace = v.workspace
WHERE r.active = TRUE
  AND (:p_region = '' OR r.region = :p_region)
  AND (:p_workspace = '' OR r.workspace = :p_workspace)
  AND (:p_workstream = '' OR r.workstream = :p_workstream)
  AND (:p_risk = '' OR r.risk_tier = :p_risk)
GROUP BY r.region, r.workspace, COALESCE(v.current_status, 'AWAITING')
ORDER BY r.region, r.workspace
