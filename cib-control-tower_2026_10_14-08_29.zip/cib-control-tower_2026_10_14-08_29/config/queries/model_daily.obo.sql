-- Per-day worst status for one model (breach-history timeline + strip).
-- @param p_model STRING = aml_alert_scorer
-- @param p_workspace STRING = cib-fcc-prod-uks
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
SELECT window_date, worst_status, breach_metrics, warn_metrics
FROM control_tower_cib.model_monitoring.v_model_daily_status
WHERE model_name = :p_model AND workspace = :p_workspace
  AND window_date BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
ORDER BY window_date
