-- Country drift trend for one model (prediction_drift_js by country over time).
-- @param p_model STRING = aml_alert_scorer
-- @param p_workspace STRING = cib-fcc-prod-uks
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
SELECT
  CAST(window_start AS DATE) AS window_date,
  slice_value,
  metric_value
FROM control_tower_cib.model_monitoring.unified_metrics
WHERE model_name = :p_model AND workspace = :p_workspace
  AND slice_name = 'country' AND metric_name = 'prediction_drift_js'
  AND CAST(window_start AS DATE) BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
ORDER BY window_date, slice_value
