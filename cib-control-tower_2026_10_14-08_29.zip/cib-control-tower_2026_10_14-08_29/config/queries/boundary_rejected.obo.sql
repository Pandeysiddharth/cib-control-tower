-- Recent fields blocked at the source by the export gate.
-- @param p_workspace STRING
SELECT workspace, run_date, field_name, reason
FROM control_tower_cib.model_monitoring.rejected_fields_log
WHERE (:p_workspace = '' OR workspace = :p_workspace)
ORDER BY run_date DESC, workspace
LIMIT 100
