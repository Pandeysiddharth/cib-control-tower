-- Per-model per-day worst status for the health heatmap.
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
-- @param p_region STRING
-- @param p_workspace STRING
-- @param p_workstream STRING
-- @param p_risk STRING
SELECT
  d.model_name,
  d.model_version,
  d.workspace,
  d.region,
  d.workstream,
  d.window_date,
  d.worst_status,
  d.breach_metrics,
  d.warn_metrics
FROM control_tower_cib.model_monitoring.v_model_daily_status d
JOIN control_tower_cib.model_monitoring.model_registry r
  ON d.model_name = r.model_name AND d.model_version = r.model_version AND d.workspace = r.workspace
WHERE d.window_date BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
  AND (:p_region = '' OR d.region = :p_region)
  AND (:p_workspace = '' OR d.workspace = :p_workspace)
  AND (:p_workstream = '' OR d.workstream = :p_workstream)
  AND (:p_risk = '' OR r.risk_tier = :p_risk)
ORDER BY d.workspace, d.model_name, d.window_date
