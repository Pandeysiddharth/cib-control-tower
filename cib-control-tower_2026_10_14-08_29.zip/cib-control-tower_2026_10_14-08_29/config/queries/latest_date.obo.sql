-- Latest window date in the snapshot; the whole app treats this as "today".
SELECT
  CAST(MAX(window_start) AS DATE) AS latest_date,
  CAST(MIN(window_start) AS DATE) AS earliest_date
FROM control_tower_cib.model_monitoring.unified_metrics
