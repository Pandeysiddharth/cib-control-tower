-- Workspace / spoke sync health for the topology diagram.
WITH g AS (SELECT MAX(last_sync_at) AS newest FROM control_tower_cib.model_monitoring.boundary_ledger),
     s AS (
       SELECT workspace, MAX(region) AS region, MAX(last_sync_at) AS last_sync,
              MAX(transport_option) AS transport_option
       FROM control_tower_cib.model_monitoring.boundary_ledger GROUP BY workspace
     ),
     mc AS (
       SELECT workspace, COUNT(*) AS model_count
       FROM control_tower_cib.model_monitoring.model_registry WHERE active = TRUE GROUP BY workspace
     ),
     bc AS (
       SELECT workspace,
         SUM(CASE WHEN current_status = 'BREACH' THEN 1 ELSE 0 END) AS breach_count,
         SUM(CASE WHEN current_status = 'STALE' THEN 1 ELSE 0 END) AS stale_count
       FROM control_tower_cib.model_monitoring.v_current_status GROUP BY workspace
     )
SELECT
  s.workspace, s.region, s.last_sync, s.transport_option,
  ROUND((unix_timestamp((SELECT newest FROM g)) - unix_timestamp(s.last_sync)) / 3600.0, 1) AS hours_behind,
  CASE WHEN s.last_sync < (SELECT newest FROM g) - INTERVAL 30 HOURS THEN TRUE ELSE FALSE END AS is_stale,
  COALESCE(mc.model_count, 0) AS model_count,
  COALESCE(bc.breach_count, 0) AS breach_count,
  COALESCE(bc.stale_count, 0) AS stale_count
FROM s
LEFT JOIN mc ON s.workspace = mc.workspace
LEFT JOIN bc ON s.workspace = bc.workspace
ORDER BY s.region, s.workspace
