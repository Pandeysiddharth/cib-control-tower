-- One row per active model with its current status (AWAITING when no metrics yet).
-- @param p_region STRING
-- @param p_workspace STRING
-- @param p_workstream STRING
-- @param p_risk STRING
SELECT
  r.model_name,
  r.model_version,
  r.workspace,
  r.region,
  r.workstream,
  r.risk_tier,
  r.owner,
  r.upstream_feed,
  r.serving_type,
  COALESCE(v.current_status, 'AWAITING') AS current_status,
  COALESCE(v.breach_count, 0) AS breach_count,
  COALESCE(v.warn_count, 0) AS warn_count,
  COALESCE(v.breached_metrics, '') AS breached_metrics,
  COALESCE(v.warned_metrics, '') AS warned_metrics,
  v.last_sync_at
FROM control_tower_cib.model_monitoring.model_registry r
LEFT JOIN control_tower_cib.model_monitoring.v_current_status v
  ON r.model_name = v.model_name AND r.model_version = v.model_version AND r.workspace = v.workspace
WHERE r.active = TRUE
  AND (:p_region = '' OR r.region = :p_region)
  AND (:p_workspace = '' OR r.workspace = :p_workspace)
  AND (:p_workstream = '' OR r.workstream = :p_workstream)
  AND (:p_risk = '' OR r.risk_tier = :p_risk)
ORDER BY r.workspace, r.model_name
