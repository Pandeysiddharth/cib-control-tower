-- Alerts with filters and computed age (in days vs the latest sync in the hub).
-- @param p_status STRING
-- @param p_severity STRING
-- @param p_region STRING
-- @param p_workspace STRING
WITH g AS (SELECT MAX(last_sync_at) AS newest FROM control_tower_cib.model_monitoring.boundary_ledger)
SELECT
  a.alert_id, a.model_name, a.workspace, a.region, a.metric_name, a.severity,
  a.opened_at, a.status, a.assignee, a.note, a.resolved_at,
  ROUND((unix_timestamp((SELECT newest FROM g)) - unix_timestamp(a.opened_at)) / 86400.0, 1) AS age_days
FROM control_tower_cib.model_monitoring.alerts a
WHERE (:p_status = '' OR a.status = :p_status)
  AND (:p_severity = '' OR a.severity = :p_severity)
  AND (:p_region = '' OR a.region = :p_region)
  AND (:p_workspace = '' OR a.workspace = :p_workspace)
ORDER BY
  CASE a.status WHEN 'OPEN' THEN 1 WHEN 'ACK' THEN 2 ELSE 3 END,
  CASE a.severity WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 ELSE 3 END,
  a.opened_at DESC
