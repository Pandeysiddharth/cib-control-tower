-- KB transferred per day per workspace over the date range.
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
SELECT
  run_date,
  workspace,
  ROUND(SUM(bytes_transferred) / 1024.0, 2) AS kb_transferred
FROM control_tower_cib.model_monitoring.boundary_ledger
WHERE run_date BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
GROUP BY run_date, workspace
ORDER BY run_date, workspace
