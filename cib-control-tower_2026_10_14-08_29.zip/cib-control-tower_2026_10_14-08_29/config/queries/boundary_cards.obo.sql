-- Per-workspace data boundary summary over the selected date range.
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
WITH latest AS (
  SELECT workspace, MAX(last_sync_at) AS last_sync, MAX(transport_option) AS transport_option
  FROM control_tower_cib.model_monitoring.boundary_ledger GROUP BY workspace
)
SELECT
  b.workspace,
  MAX(b.region) AS region,
  SUM(b.raw_rows_exported) AS raw_rows,
  SUM(b.log_rows_exported) AS log_rows,
  SUM(b.metric_rows_exported) AS metric_rows,
  ROUND(SUM(b.bytes_transferred) / 1024.0, 1) AS kb_transferred,
  SUM(b.rejected_fields_count) AS rejected_fields,
  SUM(b.suppressed_slices_count) AS suppressed_slices,
  l.last_sync,
  l.transport_option
FROM control_tower_cib.model_monitoring.boundary_ledger b
JOIN latest l ON b.workspace = l.workspace
WHERE b.run_date BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
GROUP BY b.workspace, l.last_sync, l.transport_option
ORDER BY b.workspace
