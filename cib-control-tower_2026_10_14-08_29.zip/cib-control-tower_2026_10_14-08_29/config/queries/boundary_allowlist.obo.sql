-- Allowed metrics (contract) and their thresholds / directions.
SELECT metric_name, description, category, unit, default_threshold, breach_direction
FROM control_tower_cib.model_monitoring.metric_allowlist
ORDER BY category, metric_name
