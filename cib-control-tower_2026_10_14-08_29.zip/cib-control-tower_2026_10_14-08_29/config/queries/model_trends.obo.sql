-- Daily overall-slice metric values + thresholds for one model over the date range.
-- @param p_model STRING = aml_alert_scorer
-- @param p_workspace STRING = cib-fcc-prod-uks
-- @param p_start DATE = 2024-01-01
-- @param p_end DATE = 2024-12-31
SELECT
  CAST(window_start AS DATE) AS window_date,
  metric_name,
  metric_value,
  threshold,
  status
FROM control_tower_cib.model_monitoring.unified_metrics
WHERE model_name = :p_model
  AND workspace = :p_workspace
  AND slice_name = 'overall'
  AND CAST(window_start AS DATE) BETWEEN CAST(:p_start AS DATE) AND CAST(:p_end AS DATE)
ORDER BY metric_name, window_date
