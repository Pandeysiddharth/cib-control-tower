import { useMemo, useState } from 'react';
import { useAnalyticsQuery, Button, Separator, Badge } from '@databricks/appkit-ui/react';
import { Printer, Copy, Check, FileText } from 'lucide-react';
import { sql } from '@databricks/appkit-ui/js';
import { useFilters, registryParams, dateParams, modelDateParams } from '../lib/filters';
import { SectionCard, StatusChip, QueryState } from '../components/common';
import { TrendChart, type TrendPoint } from '../components/charts';
import { statusMeta } from '../lib/status';
import { fmtDate, fmtInt, fmtKb, metricLabel } from '../lib/format';

const RISK_RANK: Record<string, number> = { High: 3, Medium: 2, Low: 1 };

function PackTrend({ model, workspace, metric }: { model: string; workspace: string; metric: string }) {
  const f = useFilters();
  const q = useAnalyticsQuery('model_trends', modelDateParams(model, workspace, f));
  const points: TrendPoint[] = (q.data ?? [])
    .filter((r) => r.metric_name === metric)
    .map((r) => ({ window_date: r.window_date, value: Number(r.metric_value), threshold: r.threshold }));
  if (points.length === 0) return null;
  return (
    <div>
      <div className="mb-1 text-xs font-medium">{model} · {metricLabel(metric)}</div>
      <TrendChart metric={metric} points={points} height={160} />
    </div>
  );
}

export function RiskPack() {
  const f = useFilters();
  const [copied, setCopied] = useState(false);
  const fleet = useAnalyticsQuery('fleet_current_status', registryParams(f));
  const alerts = useAnalyticsQuery('alerts_list', {
    p_status: sql.string('OPEN'), p_severity: sql.string(''), p_region: sql.string(f.region), p_workspace: sql.string(f.workspace),
  });
  const boundary = useAnalyticsQuery('boundary_cards', dateParams(f));

  const rows = fleet.data ?? [];
  const counts = useMemo(() => {
    const c: Record<string, number> = { OK: 0, WARN: 0, BREACH: 0, STALE: 0, AWAITING: 0 };
    for (const r of rows) if (c[r.current_status] !== undefined) c[r.current_status]++;
    return c;
  }, [rows]);

  const atRisk = useMemo(
    () => rows.filter((r) => r.current_status !== 'OK')
      .sort((a, b) => (statusMeta(b.current_status).rank - statusMeta(a.current_status).rank) || ((RISK_RANK[b.risk_tier] ?? 0) - (RISK_RANK[a.risk_tier] ?? 0)))
      .slice(0, 5),
    [rows],
  );

  const openAlerts = (alerts.data ?? []).filter((a) => a.status !== 'RESOLVED');

  const execSummary = useMemo(() => {
    const total = rows.length;
    const breach = rows.filter((r) => r.current_status === 'BREACH');
    const stale = rows.filter((r) => r.current_status === 'STALE');
    const warn = rows.filter((r) => r.current_status === 'WARN');
    const parts: string[] = [];
    parts.push(`Across ${total} monitored models, ${breach.length} are breaching, ${warn.length} are in warning and ${stale.length} are stale (their workspace stopped reporting).`);
    if (breach.length) parts.push(`Active breaches: ${breach.map((b) => `${b.model_name} (${(b.breached_metrics || '').split(',')[0]?.trim()})`).join(', ')}.`);
    if (stale.length) parts.push(`Stale models are not healthy — they are unmonitored until ${Array.from(new Set(stale.map((s) => s.workspace))).join(', ')} resume sending metrics.`);
    parts.push('All figures are derived from aggregated metrics only; no customer data is held in the hub.');
    return parts.join(' ');
  }, [rows]);

  function markdown(): string {
    const lines: string[] = [];
    lines.push(`# Model Risk Pack`);
    lines.push(`_Range ${fmtDate(f.start)} – ${fmtDate(f.end)}${f.region ? ` · ${f.region}` : ''}${f.workspace ? ` · ${f.workspace}` : ''}_\n`);
    lines.push(`## Fleet summary`);
    lines.push(`- Models: ${rows.length}`);
    lines.push(`- Breach: ${counts.BREACH} · Warn: ${counts.WARN} · Stale: ${counts.STALE} · OK: ${counts.OK}\n`);
    lines.push(`## Executive summary`);
    lines.push(execSummary + '\n');
    lines.push(`## Models needing attention`);
    atRisk.forEach((r) => lines.push(`- **${r.model_name} ${r.model_version}** (${r.workspace}, ${r.risk_tier}) — ${r.current_status}: ${r.breached_metrics || r.warned_metrics || '—'}`));
    lines.push(`\n## Open alerts`);
    openAlerts.forEach((a) => lines.push(`- [${a.severity}] ${a.model_name} · ${metricLabel(a.metric_name)} · ${a.status}`));
    lines.push(`\n## Data boundary`);
    (boundary.data ?? []).forEach((b) => lines.push(`- ${b.workspace}: ${fmtInt(b.metric_rows)} metric rows, ${fmtKb(b.kb_transferred)}, raw/log rows 0`));
    return lines.join('\n');
  }

  const copyMd = () => navigator.clipboard?.writeText(markdown()).then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Model Risk Pack</h1>
          <p className="text-sm text-muted-foreground">
            Range {fmtDate(f.start)} – {fmtDate(f.end)}{f.region ? ` · ${f.region}` : ''}{f.workspace ? ` · ${f.workspace}` : ''}. Written from aggregated numbers only.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={copyMd}>{copied ? <Check className="mr-2 h-4 w-4 text-success" /> : <Copy className="mr-2 h-4 w-4" />}Copy as markdown</Button>
          <Button onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" />Print to PDF</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
        {(['BREACH', 'STALE', 'WARN', 'OK', 'AWAITING'] as const).map((s) => (
          <div key={s} className="rounded-lg border p-3 text-center">
            <div className="text-2xl font-semibold tabular-nums" style={{ color: statusMeta(s).color }}>{counts[s]}</div>
            <div className="mt-1"><StatusChip status={s} /></div>
          </div>
        ))}
      </div>

      <SectionCard title="Executive summary">
        <p className="text-sm leading-relaxed">{execSummary}</p>
      </SectionCard>

      <SectionCard title="Models needing attention" description="Top 5 by severity and risk tier.">
        <QueryState loading={fleet.loading} error={fleet.error} data={atRisk} empty="All models healthy">
          {(items) => (
            <div className="space-y-2">
              {items.map((r) => (
                <div key={`${r.model_name}-${r.workspace}`} className="flex items-center justify-between rounded-md border p-2.5 text-sm">
                  <div>
                    <span className="font-medium">{r.model_name} {r.model_version}</span>
                    <span className="ml-2 text-xs text-muted-foreground">{r.workspace} · {r.region} · {r.owner}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{r.risk_tier}</Badge>
                    <span className="text-xs text-muted-foreground">{r.breached_metrics || r.warned_metrics}</span>
                    <StatusChip status={r.current_status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </QueryState>
      </SectionCard>

      <SectionCard title="Key trends" description="Primary deviating metric per at-risk model.">
        <div className="grid gap-6 md:grid-cols-2">
          {atRisk.map((r) => {
            const metric = (r.breached_metrics || r.warned_metrics || 'prediction_drift_js').split(',')[0]?.trim();
            if (!metric || metric === 'sync_stale') return null;
            return <PackTrend key={`${r.model_name}-${r.workspace}`} model={r.model_name} workspace={r.workspace} metric={metric} />;
          })}
        </div>
      </SectionCard>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Open alerts">
          <QueryState loading={alerts.loading} error={alerts.error} data={openAlerts} empty="No open alerts">
            {(items) => (
              <ul className="space-y-1.5 text-sm">
                {items.map((a) => (
                  <li key={a.alert_id} className="flex items-center justify-between rounded border p-2">
                    <span>{a.model_name} · {metricLabel(a.metric_name)}</span>
                    <Badge variant={a.severity === 'Critical' ? 'destructive' : 'secondary'}>{a.severity} · {a.status}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </SectionCard>

        <SectionCard title="Data boundary summary">
          <QueryState loading={boundary.loading} error={boundary.error} data={boundary.data}>
            {(items) => (
              <ul className="space-y-1.5 text-sm">
                {items.map((b) => (
                  <li key={b.workspace} className="flex items-center justify-between rounded border p-2">
                    <span>{b.workspace}</span>
                    <span className="text-xs text-muted-foreground">{fmtInt(b.metric_rows)} rows · {fmtKb(b.kb_transferred)} · raw/log 0</span>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </SectionCard>
      </div>

      <Separator />
      <p className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
        <FileText className="h-3.5 w-3.5" /> Generated from aggregated monitoring metrics only. No customer data in this hub.
      </p>
    </div>
  );
}
