import { useMemo, useState } from 'react';
import {
  useAnalyticsQuery, BarChart, Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem, Button, Badge,
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, Input, Label,
} from '@databricks/appkit-ui/react';
import { Check, UserPlus, CircleCheck, MessageSquarePlus } from 'lucide-react';
import { sql } from '@databricks/appkit-ui/js';
import { SectionCard, QueryState } from '../components/common';
import { statusColor } from '../lib/colors';
import { fmtDateTime, metricLabel } from '../lib/format';

interface AlertRow {
  alert_id: string; model_name: string; workspace: string; region: string; metric_name: string;
  severity: string; opened_at: string; status: string; assignee: string | null; note: string | null;
  resolved_at: string | null; age_days: number;
}

const ALL = '__all__';
type Overlay = Record<string, Partial<Pick<AlertRow, 'status' | 'assignee' | 'note' | 'resolved_at'>>>;

export function AlertsPage() {
  const [status, setStatus] = useState('');
  const [severity, setSeverity] = useState('');
  const [region, setRegion] = useState('');
  const [workspace, setWorkspace] = useState('');
  const [reloadKey, setReloadKey] = useState(0);
  const [overlay, setOverlay] = useState<Overlay>({});
  const [dialog, setDialog] = useState<{ id: string; mode: 'assign' | 'note' } | null>(null);
  const [dialogValue, setDialogValue] = useState('');

  const q = useAnalyticsQuery('alerts_list', {
    p_status: sql.string(status), p_severity: sql.string(severity),
    p_region: sql.string(region), p_workspace: sql.string(workspace),
  }, { autoStart: true });
  const byDay = useAnalyticsQuery('alerts_by_day', { p_region: sql.string(region), p_workspace: sql.string(workspace) });

  // void reloadKey to force a dependency when we bump it
  void reloadKey;

  const rows = useMemo(
    () => (q.data ?? []).map((r) => ({ ...r, ...overlay[r.alert_id] })),
    [q.data, overlay],
  );

  const regions = Array.from(new Set((q.data ?? []).map((r) => r.region))).sort();
  const workspaces = Array.from(new Set((q.data ?? []).map((r) => r.workspace))).sort();

  const chartData = useMemo(() => {
    const byDate = new Map<string, Record<string, number | string>>();
    for (const r of (byDay.data ?? []) as { opened_date: string; severity: string; n: number }[]) {
      if (!byDate.has(r.opened_date)) byDate.set(r.opened_date, { date: r.opened_date, Critical: 0, High: 0, Medium: 0 });
      byDate.get(r.opened_date)![r.severity] = Number(r.n);
    }
    return Array.from(byDate.values()).sort((a, b) => String(a.date).localeCompare(String(b.date)));
  }, [byDay.data]);

  async function act(id: string, action: 'ack' | 'resolve' | 'assign' | 'note', payload?: { assignee?: string; note?: string }) {
    const res = await fetch(`/api/alerts/${encodeURIComponent(id)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, ...payload }),
    });
    if (res.ok) {
      setOverlay((o) => ({
        ...o,
        [id]: {
          ...o[id],
          ...(action === 'ack' ? { status: 'ACK' } : {}),
          ...(action === 'resolve' ? { status: 'RESOLVED', resolved_at: new Date().toISOString() } : {}),
          ...(payload?.assignee !== undefined ? { assignee: payload.assignee } : {}),
          ...(payload?.note !== undefined ? { note: payload.note } : {}),
        },
      }));
      setReloadKey((k) => k + 1);
    }
  }

  const openDialog = (id: string, mode: 'assign' | 'note', current: string) => {
    setDialog({ id, mode }); setDialogValue(current);
  };
  const submitDialog = async () => {
    if (!dialog) return;
    await act(dialog.id, dialog.mode, dialog.mode === 'assign' ? { assignee: dialogValue } : { note: dialogValue });
    setDialog(null);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Alerts</h1>
        <p className="text-sm text-muted-foreground">Breach and sync-stale alerts across the fleet. Actions write back to the alerts table.</p>
      </div>

      <SectionCard title="Alerts opened per day" description="By severity.">
        <QueryState loading={byDay.loading} error={byDay.error} data={chartData}>
          {() => (
            <BarChart data={chartData} xKey="date" yKey={['Critical', 'High', 'Medium']} stacked height={200} showLegend
              colors={[statusColor('BREACH'), statusColor('WARN'), statusColor('AWAITING')]} />
          )}
        </QueryState>
      </SectionCard>

      <SectionCard title="Alert queue" action={
        <div className="flex flex-wrap gap-2">
          <FilterSel label="Status" value={status} set={setStatus} options={['OPEN', 'ACK', 'RESOLVED']} />
          <FilterSel label="Severity" value={severity} set={setSeverity} options={['Critical', 'High', 'Medium']} />
          <FilterSel label="Region" value={region} set={setRegion} options={regions} />
          <FilterSel label="Workspace" value={workspace} set={setWorkspace} options={workspaces} />
        </div>
      }>
        <QueryState loading={q.loading} error={q.error} data={rows} empty="No alerts match these filters">
          {(items) => (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Severity</TableHead><TableHead>Model</TableHead><TableHead>Workspace</TableHead>
                    <TableHead>Metric</TableHead><TableHead>Opened</TableHead><TableHead className="text-right">Age</TableHead>
                    <TableHead>Status</TableHead><TableHead>Assignee</TableHead><TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {items.map((a) => (
                    <TableRow key={a.alert_id}>
                      <TableCell><Badge variant={a.severity === 'Critical' ? 'destructive' : 'secondary'}>{a.severity}</Badge></TableCell>
                      <TableCell className="font-medium">{a.model_name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{a.workspace}</TableCell>
                      <TableCell>{metricLabel(a.metric_name)}</TableCell>
                      <TableCell className="text-xs">{fmtDateTime(a.opened_at)}</TableCell>
                      <TableCell className="text-right tabular-nums text-xs">{Number(a.age_days).toFixed(0)}d</TableCell>
                      <TableCell><StatusChipMini status={a.status} /></TableCell>
                      <TableCell className="text-xs">{a.assignee ?? '—'}</TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-1">
                          {a.status === 'OPEN' && (
                            <Button size="icon" variant="ghost" title="Acknowledge" onClick={() => act(a.alert_id, 'ack')}><Check className="h-4 w-4" /></Button>
                          )}
                          <Button size="icon" variant="ghost" title="Assign" onClick={() => openDialog(a.alert_id, 'assign', a.assignee ?? '')}><UserPlus className="h-4 w-4" /></Button>
                          <Button size="icon" variant="ghost" title="Add note" onClick={() => openDialog(a.alert_id, 'note', a.note ?? '')}><MessageSquarePlus className="h-4 w-4" /></Button>
                          {a.status !== 'RESOLVED' && (
                            <Button size="icon" variant="ghost" title="Resolve" onClick={() => act(a.alert_id, 'resolve')}><CircleCheck className="h-4 w-4" /></Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </QueryState>
      </SectionCard>

      <Dialog open={!!dialog} onOpenChange={(o) => !o && setDialog(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{dialog?.mode === 'assign' ? 'Assign alert' : 'Add note'}</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <Label>{dialog?.mode === 'assign' ? 'Assignee' : 'Note'}</Label>
            <Input value={dialogValue} onChange={(e) => setDialogValue(e.target.value)} autoFocus
              placeholder={dialog?.mode === 'assign' ? 'e.g. Marcus Webb' : 'Short note'} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialog(null)}>Cancel</Button>
            <Button onClick={submitDialog}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatusChipMini({ status }: { status: string }) {
  const variant = status === 'RESOLVED' ? 'secondary' : status === 'ACK' ? 'outline' : 'destructive';
  return <Badge variant={variant}>{status}</Badge>;
}

function FilterSel({ label, value, set, options }: { label: string; value: string; set: (v: string) => void; options: string[] }) {
  return (
    <Select value={value === '' ? ALL : value} onValueChange={(v) => set(v === ALL ? '' : v)}>
      <SelectTrigger className="h-8 w-[140px] text-xs"><SelectValue placeholder={label} /></SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL}>All {label.toLowerCase()}</SelectItem>
        {options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
      </SelectContent>
    </Select>
  );
}
