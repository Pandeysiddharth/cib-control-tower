import { useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router';
import {
  useAnalyticsQuery, Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
  Button, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Badge, LineChart,
} from '@databricks/appkit-ui/react';
import { Sparkles, Info } from 'lucide-react';
import { sql } from '@databricks/appkit-ui/js';
import { useFilters, modelDateParams, modelParams } from '../lib/filters';
import { SectionCard, StatusChip, QueryState, LoadingRows, ErrorState, EmptyState } from '../components/common';
import { TrendChart, type TrendPoint } from '../components/charts';
import { fmtDate, fmtNum, fmtDateTime, metricLabel } from '../lib/format';
import { useGeniePanel } from '../components/AskGeniePanel';

interface DailyRow { window_date: string; worst_status: string; breach_metrics: number; warn_metrics: number; }

const TREND_METRICS = ['prediction_drift_js', 'feature_psi_max', 'row_count', 'auc', 'f1', 'latency_p95_ms', 'error_rate_pct', 'null_pct'];
const ACCURACY = new Set(['auc', 'f1', 'precision', 'recall']);

interface Episode { start: string; end: string; days: number; }
function episodes(daily: DailyRow[]): Episode[] {
  const out: Episode[] = [];
  const sorted = [...daily].sort((a, b) => a.window_date.localeCompare(b.window_date));
  let run: DailyRow[] = [];
  const flush = () => {
    if (run.length) out.push({ start: run[0].window_date, end: run[run.length - 1].window_date, days: run.length });
    run = [];
  };
  for (const d of sorted) {
    if (d.worst_status === 'BREACH') run.push(d); else flush();
  }
  flush();
  return out.reverse();
}

export function ModelDetail() {
  const f = useFilters();
  const { openGenie } = useGeniePanel();
  const [params, setParams] = useSearchParams();

  const list = useAnalyticsQuery('model_registry_list', {});
  const models = list.data ?? [];

  const selModel = params.get('model') ?? '';
  const selWs = params.get('workspace') ?? '';

  useEffect(() => {
    if (!selModel && models.length) {
      const first = models[0];
      setParams({ model: first.model_name, workspace: first.workspace }, { replace: true });
    }
  }, [models, selModel, setParams]);

  const header = useAnalyticsQuery('model_header', modelParams(selModel, selWs));
  const trends = useAnalyticsQuery('model_trends', modelDateParams(selModel, selWs, f));
  const slices = useAnalyticsQuery('model_slices_latest', modelParams(selModel, selWs));
  const sliceTrend = useAnalyticsQuery('model_slice_trend', modelDateParams(selModel, selWs, f));
  const daily = useAnalyticsQuery('model_daily', modelDateParams(selModel, selWs, f));
  const alerts = useAnalyticsQuery('alerts_list', {
    p_status: sql.string(''), p_severity: sql.string(''),
    p_region: sql.string(''), p_workspace: sql.string(selWs),
  });

  const h = (header.data?.[0] ?? null) as Record<string, unknown> | null;

  const byMetric = useMemo(() => {
    const m = new Map<string, TrendPoint[]>();
    for (const r of trends.data ?? []) {
      if (!m.has(r.metric_name)) m.set(r.metric_name, []);
      m.get(r.metric_name)!.push({ window_date: r.window_date, value: Number(r.metric_value), threshold: r.threshold });
    }
    return m;
  }, [trends.data]);

  const sliceChartData = useMemo(() => {
    const byDate = new Map<string, Record<string, number | string>>();
    const countries = new Set<string>();
    for (const r of (sliceTrend.data ?? []) as { window_date: string; slice_value: string; metric_value: number }[]) {
      countries.add(r.slice_value);
      const d = r.window_date;
      if (!byDate.has(d)) byDate.set(d, { date: d });
      byDate.get(d)![r.slice_value] = Number(r.metric_value);
    }
    return { data: Array.from(byDate.values()), countries: Array.from(countries).sort() };
  }, [sliceTrend.data]);

  const modelAlerts = (alerts.data ?? []).filter((a) => a.model_name === selModel);
  const breachEpisodes = useMemo(() => episodes(daily.data ?? []), [daily.data]);

  const explain = () => {
    const metric = String(h?.breached_metrics ?? '').split(',')[0]?.trim() || 'a monitored metric';
    const date = f.end;
    openGenie(
      `For model ${selModel} in ${selWs}, the metric ${metric} breached on ${date}. Using only unified_metrics, model_registry and alerts: (1) when did it start deviating, (2) which slices or other metrics moved at the same time, (3) which other models share the same upstream_feed and are also affected, and (4) summarise likely causes and what the model owner should check locally in the spoke workspace.`,
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Model Detail</h1>
          <p className="text-sm text-muted-foreground">Trends, slices, breach history and alerts for one model.</p>
        </div>
        <div className="flex items-end gap-2">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Model</label>
            <Select
              value={selModel && selWs ? `${selModel}||${selWs}` : ''}
              onValueChange={(v) => { const [m, w] = v.split('||'); setParams({ model: m, workspace: w }); }}
            >
              <SelectTrigger className="w-[320px]"><SelectValue placeholder="Select a model" /></SelectTrigger>
              <SelectContent>
                {models.map((m) => (
                  <SelectItem key={`${m.model_name}||${m.workspace}`} value={`${m.model_name}||${m.workspace}`}>
                    {m.model_name} · {m.workspace}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={explain}><Sparkles className="mr-2 h-4 w-4" /> Explain this breach</Button>
        </div>
      </div>

      {/* Header */}
      {header.loading ? <LoadingRows rows={2} /> : header.error ? <ErrorState message={header.error} />
        : h ? (
          <div className="rounded-lg border bg-card p-4">
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
              <div className="flex items-center gap-2">
                <span className="text-lg font-semibold">{String(h.model_name)}</span>
                <Badge variant="outline">{String(h.model_version)}</Badge>
                <StatusChip status={String(h.current_status)} />
              </div>
              <Meta label="Workspace" value={String(h.workspace)} />
              <Meta label="Region" value={String(h.region)} />
              <Meta label="Owner" value={String(h.owner)} />
              <Meta label="Serving" value={String(h.serving_type)} />
              <Meta label="Risk tier" value={String(h.risk_tier)} />
              <Meta label="Upstream feed" value={String(h.upstream_feed)} />
            </div>
            {(String(h.breached_metrics) || String(h.warned_metrics)) && (
              <p className="mt-3 text-xs text-muted-foreground">
                {String(h.breached_metrics) && <>Breaching: <span className="text-destructive">{String(h.breached_metrics)}</span>. </>}
                {String(h.warned_metrics) && <>Warning: {String(h.warned_metrics)}.</>}
              </p>
            )}
          </div>
        ) : <EmptyState title="Select a model" />}

      {/* Trends */}
      <SectionCard title="Metric trends" description="Daily values with threshold lines. Accuracy metrics (AUC, F1) arrive weeks late because labels are delayed.">
        <QueryState loading={trends.loading} error={trends.error} data={trends.data}>
          {() => (
            <div className="grid gap-6 md:grid-cols-2">
              {TREND_METRICS.filter((m) => byMetric.has(m)).map((m) => (
                <div key={m}>
                  <div className="mb-1 flex items-center gap-2 text-sm font-medium">
                    {metricLabel(m)}
                    {ACCURACY.has(m) && (
                      <span className="inline-flex items-center gap-1 text-[10px] font-normal text-muted-foreground">
                        <Info className="h-3 w-3" /> labels delayed
                      </span>
                    )}
                  </div>
                  <TrendChart metric={m} points={byMetric.get(m)!} />
                </div>
              ))}
            </div>
          )}
        </QueryState>
      </SectionCard>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Slice table */}
        <SectionCard title="Country slices (latest)" description="Per-country values on the latest window.">
          <QueryState loading={slices.loading} error={slices.error} data={slices.data} empty="This model has no slice metrics">
            {(srows) => (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Slice</TableHead><TableHead>Metric</TableHead>
                    <TableHead className="text-right">Value</TableHead><TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {[...srows].sort((a, b) => a.metric_name.localeCompare(b.metric_name) || a.slice_value.localeCompare(b.slice_value)).map((r, i) => (
                    <TableRow key={i}>
                      <TableCell className="font-medium">{r.slice_value}</TableCell>
                      <TableCell>{metricLabel(r.metric_name)}</TableCell>
                      <TableCell className="text-right tabular-nums">{fmtNum(r.metric_value, 3)}</TableCell>
                      <TableCell><StatusChip status={r.status} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </QueryState>
        </SectionCard>

        {/* Slice drift chart */}
        <SectionCard title="Prediction drift by country" description="Where drift is concentrated across slices.">
          {sliceTrend.loading ? <LoadingRows /> : sliceChartData.data.length === 0
            ? <EmptyState title="This model has no slice metrics" />
            : (
              <LineChart
                data={sliceChartData.data}
                xKey="date"
                yKey={sliceChartData.countries}
                height={240}
                showLegend
                smooth={false}
                colorPalette="categorical"
              />
            )}
        </SectionCard>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Breach history */}
        <SectionCard title="Breach history" description="Episodes of consecutive breach days on the overall slice.">
          <QueryState loading={daily.loading} error={daily.error} data={breachEpisodes} empty="No breaches in the selected range">
            {(eps) => (
              <ul className="space-y-2">
                {eps.map((e, i) => (
                  <li key={i} className="flex items-center justify-between rounded-md border p-2.5 text-sm">
                    <span className="inline-flex items-center gap-2"><StatusChip status="BREACH" /> {fmtDate(e.start)} → {fmtDate(e.end)}</span>
                    <Badge variant="secondary">{e.days} day{e.days > 1 ? 's' : ''}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </SectionCard>

        {/* Open alerts */}
        <SectionCard title="Alerts for this model">
          <QueryState loading={alerts.loading} error={alerts.error} data={modelAlerts} empty="No alerts for this model">
            {(items) => (
              <ul className="space-y-2">
                {items.map((a) => (
                  <li key={a.alert_id} className="rounded-md border p-2.5 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{metricLabel(a.metric_name)}</span>
                      <Badge variant={a.status === 'RESOLVED' ? 'secondary' : 'destructive'}>{a.severity} · {a.status}</Badge>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">Opened {fmtDateTime(a.opened_at)}{a.assignee ? ` · ${a.assignee}` : ''}</div>
                    {a.note && <div className="mt-1 text-xs">{a.note}</div>}
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </SectionCard>
      </div>

      <p className="text-center text-xs text-muted-foreground">
        Root-cause investigation on raw data happens locally in the spoke workspace.
      </p>
    </div>
  );
}

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div className="leading-tight">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-sm font-medium">{value}</div>
    </div>
  );
}
