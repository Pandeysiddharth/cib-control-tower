import { useMemo } from 'react';
import { useNavigate } from 'react-router';
import { useAnalyticsQuery, BarChart, Button } from '@databricks/appkit-ui/react';
import { Activity, AlertTriangle, CheckCircle2, CloudOff, XCircle, Server, FileText, ArrowRight, ShieldCheck } from 'lucide-react';
import { useFilters, registryParams, registryDateParams } from '../lib/filters';
import { KpiTile, SectionCard, StatusChip, QueryState } from '../components/common';
import { Heatmap } from '../components/Heatmap';
import { statusMeta } from '../lib/status';
import { statusColor } from '../lib/colors';
import { metricLabel } from '../lib/format';
import { useGeniePanel } from '../components/AskGeniePanel';

interface FleetRow {
  model_name: string; model_version: string; workspace: string; region: string; workstream: string;
  risk_tier: string; owner: string; upstream_feed: string; serving_type: string;
  current_status: string; breach_count: number; warn_count: number;
  breached_metrics: string; warned_metrics: string; last_sync_at: string | null;
}

function summarize(r: FleetRow): string {
  const metric = (r.breached_metrics || r.warned_metrics || '').split(',')[0]?.trim();
  if (r.current_status === 'STALE') return `${r.workspace} stopped sending metrics — treat as unmonitored, not healthy.`;
  if (r.current_status === 'BREACH') return `${metricLabel(metric)} breaching on the ${r.workstream} ${r.serving_type} model in ${r.region}.`;
  if (r.current_status === 'WARN') return `${metricLabel(metric)} approaching its threshold in ${r.region}.`;
  if (r.current_status === 'AWAITING') return 'Onboarded — awaiting first metrics sync from the spoke.';
  return 'Healthy across all monitored metrics.';
}

const RISK_RANK: Record<string, number> = { High: 3, Medium: 2, Low: 1 };

export function FleetOverview() {
  const f = useFilters();
  const nav = useNavigate();
  const { openGenie } = useGeniePanel();

  const fleet = useAnalyticsQuery('fleet_current_status', registryParams(f));
  const reporting = useAnalyticsQuery('workspaces_reporting', {});
  const heat = useAnalyticsQuery('heatmap', registryDateParams(f));
  const region = useAnalyticsQuery('region_status', registryParams(f));

  const rows = fleet.data ?? [];
  const counts = useMemo(() => {
    const c: Record<string, number> = { OK: 0, WARN: 0, BREACH: 0, STALE: 0, AWAITING: 0 };
    for (const r of rows) if (c[r.current_status] !== undefined) c[r.current_status]++;
    return { total: rows.length, OK: c.OK, WARN: c.WARN, BREACH: c.BREACH, STALE: c.STALE, AWAITING: c.AWAITING };
  }, [rows]);
  const healthyPct = counts.total ? Math.round((counts.OK / counts.total) * 100) : 0;

  const staleModels = useMemo(
    () => new Set(rows.filter((r) => r.current_status === 'STALE').map((r) => `${r.model_name}|${r.workspace}`)),
    [rows],
  );

  const needsAttention = useMemo(
    () => rows
      .filter((r) => r.current_status !== 'OK')
      .sort((a, b) => (statusMeta(b.current_status).rank - statusMeta(a.current_status).rank)
        || ((RISK_RANK[b.risk_tier] ?? 0) - (RISK_RANK[a.risk_tier] ?? 0)))
      .slice(0, 5),
    [rows],
  );

  const regionBars = useMemo(() => {
    const byWs = new Map<string, Record<string, number | string>>();
    for (const r of region.data ?? []) {
      const ws = String(r.workspace);
      if (!byWs.has(ws)) byWs.set(ws, { workspace: ws, OK: 0, WARN: 0, BREACH: 0, STALE: 0, AWAITING: 0 });
      byWs.get(ws)![String(r.current_status)] = Number(r.n);
    }
    return Array.from(byWs.values());
  }, [region.data]);

  const rep = reporting.data?.[0];

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold">Fleet Overview</h1>
          <p className="text-sm text-muted-foreground">Current health of every monitored model across workspaces and regions.</p>
        </div>
        <Button variant="outline" onClick={() => nav('/riskpack')}>
          <FileText className="mr-2 h-4 w-4" /> Generate model risk pack
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <KpiTile label="Models monitored" value={counts.total} icon={<Activity className="h-3.5 w-3.5" />} />
        <KpiTile label="Healthy" value={`${healthyPct}%`} accent="success" sub={`${counts.OK} OK`} icon={<CheckCircle2 className="h-3.5 w-3.5" />} />
        <KpiTile label="Warnings" value={counts.WARN} accent="warning" icon={<AlertTriangle className="h-3.5 w-3.5" />} />
        <KpiTile label="Breaches" value={counts.BREACH} accent="destructive" icon={<XCircle className="h-3.5 w-3.5" />} />
        <KpiTile label="Stale models" value={counts.STALE} accent="stale" icon={<CloudOff className="h-3.5 w-3.5" />} />
        <KpiTile label="Workspaces reporting" value={rep ? `${rep.reporting_workspaces}/${rep.expected_workspaces}` : '—'} icon={<Server className="h-3.5 w-3.5" />} sub="synced in last 30h" />
      </div>

      <SectionCard title="Model-by-day health heatmap" description="Worst daily status per model. Grey = workspace went silent. Click a cell to inspect that model and date.">
        <QueryState loading={heat.loading} error={heat.error} data={heat.data}>
          {(hrows) => (
            <Heatmap
              rows={hrows}
              start={f.start}
              end={f.end}
              staleModels={staleModels}
              onCellClick={(m, ws, d) => nav(`/models?model=${encodeURIComponent(m)}&workspace=${encodeURIComponent(ws)}&date=${d}`)}
            />
          )}
        </QueryState>
      </SectionCard>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Status by workspace" description="Current model status split per spoke workspace.">
          <QueryState loading={region.loading} error={region.error} data={regionBars}>
            {() => (
              <BarChart
                data={regionBars}
                xKey="workspace"
                yKey={['OK', 'WARN', 'BREACH', 'STALE', 'AWAITING']}
                stacked
                height={260}
                showLegend
                colors={[statusColor('OK'), statusColor('WARN'), statusColor('BREACH'), statusColor('STALE'), statusColor('AWAITING')]}
              />
            )}
          </QueryState>
        </SectionCard>

        <SectionCard title="Needs attention" description="Top 5 ranked by severity and risk tier.">
          <QueryState loading={fleet.loading} error={fleet.error} data={needsAttention} empty="Everything is healthy">
            {(items) => (
              <ul className="space-y-2">
                {items.map((r) => (
                  <li key={`${r.model_name}-${r.workspace}`}>
                    <button
                      onClick={() => nav(`/models?model=${encodeURIComponent(r.model_name)}&workspace=${encodeURIComponent(r.workspace)}`)}
                      className="flex w-full items-start gap-3 rounded-md border p-3 text-left transition-colors hover:bg-muted"
                    >
                      <StatusChip status={r.current_status} />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="truncate text-sm font-medium">{r.model_name} <span className="text-muted-foreground">{r.model_version}</span></span>
                          <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] uppercase text-muted-foreground">{r.risk_tier} risk</span>
                        </div>
                        <p className="mt-0.5 text-xs text-muted-foreground">{summarize(r)}</p>
                      </div>
                      <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </QueryState>
        </SectionCard>
      </div>

      <button
        onClick={() => nav('/boundary')}
        className="flex w-full items-center gap-3 rounded-lg border bg-success/5 p-4 text-left transition-colors hover:bg-success/10"
      >
        <ShieldCheck className="h-5 w-5 text-success" />
        <div className="flex-1">
          <div className="text-sm font-medium">Metrics only. Raw data never leaves its workspace.</div>
          <div className="text-xs text-muted-foreground">Open the Data Boundary Ledger to see exactly what each spoke exports.</div>
        </div>
        <ArrowRight className="h-4 w-4 text-muted-foreground" />
      </button>

      <div className="flex justify-center">
        <Button variant="ghost" size="sm" onClick={() => openGenie('Which models are breaching right now, and in which region?')}>
          Ask Genie about the current fleet status
        </Button>
      </div>
    </div>
  );
}
