import { useMemo } from 'react';
import {
  useAnalyticsQuery, LineChart, Table, TableBody, TableCell, TableHead, TableHeader, TableRow, Badge,
} from '@databricks/appkit-ui/react';
import { CheckCircle2, ShieldCheck, Ban, Scissors } from 'lucide-react';
import { sql } from '@databricks/appkit-ui/js';
import { useFilters, dateParams } from '../lib/filters';
import { SectionCard, QueryState, KpiTile } from '../components/common';
import { fmtInt, fmtKb, fmtDateTime, fmtDate, fmtNum, metricLabel } from '../lib/format';

export function DataBoundary() {
  const f = useFilters();
  const cards = useAnalyticsQuery('boundary_cards', dateParams(f));
  const allow = useAnalyticsQuery('boundary_allowlist', {});
  const rejected = useAnalyticsQuery('boundary_rejected', { p_workspace: sql.string(f.workspace) });
  const kbTrend = useAnalyticsQuery('boundary_kb_trend', dateParams(f));

  const totals = useMemo(() => {
    const rows = cards.data ?? [];
    return {
      raw: rows.reduce((s, r) => s + Number(r.raw_rows), 0),
      log: rows.reduce((s, r) => s + Number(r.log_rows), 0),
      metric: rows.reduce((s, r) => s + Number(r.metric_rows), 0),
      suppressed: rows.reduce((s, r) => s + Number(r.suppressed_slices), 0),
    };
  }, [cards.data]);

  const kbData = useMemo(() => {
    const byDate = new Map<string, Record<string, number | string>>();
    const wss = new Set<string>();
    for (const r of (kbTrend.data ?? []) as { run_date: string; workspace: string; kb_transferred: number }[]) {
      wss.add(r.workspace);
      const d = r.run_date;
      if (!byDate.has(d)) byDate.set(d, { date: d });
      byDate.get(d)![r.workspace] = Number(r.kb_transferred);
    }
    return { data: Array.from(byDate.values()), workspaces: Array.from(wss).sort() };
  }, [kbTrend.data]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Data Boundary Ledger</h1>
        <p className="text-sm text-muted-foreground">Proof that only aggregated metrics leave each spoke. No raw data, no logs — ever.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiTile label="Raw rows exported" value={fmtInt(totals.raw)} accent="success" icon={<CheckCircle2 className="h-3.5 w-3.5" />} sub="always zero" />
        <KpiTile label="Log rows exported" value={fmtInt(totals.log)} accent="success" icon={<CheckCircle2 className="h-3.5 w-3.5" />} sub="always zero" />
        <KpiTile label="Metric rows exported" value={fmtInt(totals.metric)} icon={<ShieldCheck className="h-3.5 w-3.5" />} sub="in range" />
        <KpiTile label="Small slices suppressed" value={fmtInt(totals.suppressed)} icon={<Scissors className="h-3.5 w-3.5" />} sub="fewer than 100 records" />
      </div>

      <SectionCard title="What each workspace exports" description="Per-spoke boundary summary over the selected date range.">
        <QueryState loading={cards.loading} error={cards.error} data={cards.data}>
          {(rows) => (
            <div className="grid gap-3 md:grid-cols-2">
              {rows.map((r) => (
                <div key={r.workspace} className="rounded-lg border p-4">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{r.workspace}</div>
                    <Badge variant="outline">{r.region}</Badge>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                    <Fact ok label="Raw rows" value={fmtInt(r.raw_rows)} />
                    <Fact ok label="Log rows" value={fmtInt(r.log_rows)} />
                    <Fact label="Metric rows" value={fmtInt(r.metric_rows)} />
                    <Fact label="Transferred" value={fmtKb(r.kb_transferred)} />
                    <Fact label="Rejected fields" value={fmtInt(r.rejected_fields)} />
                    <Fact label="Suppressed slices" value={fmtInt(r.suppressed_slices)} />
                  </div>
                  <div className="mt-3 border-t pt-2 text-xs text-muted-foreground">
                    <div>Transport: {r.transport_option}</div>
                    <div>Last sync: {fmtDateTime(r.last_sync)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </QueryState>
      </SectionCard>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Allowed contract metrics" description="The only metrics the export gate lets through.">
          <QueryState loading={allow.loading} error={allow.error} data={allow.data}>
            {(rows) => (
              <div className="max-h-80 overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow><TableHead>Metric</TableHead><TableHead>Category</TableHead><TableHead>Unit</TableHead><TableHead>Dir</TableHead></TableRow>
                  </TableHeader>
                  <TableBody>
                    {rows.map((r) => (
                      <TableRow key={r.metric_name}>
                        <TableCell className="font-medium">{metricLabel(r.metric_name)}</TableCell>
                        <TableCell className="text-xs">{r.category}</TableCell>
                        <TableCell className="text-xs">{r.unit}</TableCell>
                        <TableCell className="text-xs">{r.breach_direction}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </QueryState>
        </SectionCard>

        <SectionCard title="Blocked at the source" description="Fields the export gate rejected — field names only, never values.">
          <QueryState loading={rejected.loading} error={rejected.error} data={rejected.data} empty="No rejected fields in range">
            {(rows) => (
              <div className="max-h-80 space-y-2 overflow-auto">
                {rows.map((r, i) => (
                  <div key={i} className="flex items-start gap-2 rounded-md border p-2 text-sm">
                    <Ban className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <code className="rounded bg-muted px-1 text-xs">{r.field_name}</code>
                        <span className="text-[11px] text-muted-foreground">{fmtDate(r.run_date)} · {r.workspace}</span>
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">{r.reason}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </QueryState>
        </SectionCard>
      </div>

      <SectionCard title="Bytes transferred per day" description="Only kilobytes of aggregated metrics ever cross the boundary.">
        <QueryState loading={kbTrend.loading} error={kbTrend.error} data={kbData.data}>
          {() => (
            <LineChart data={kbData.data} xKey="date" yKey={kbData.workspaces} height={240} showLegend smooth={false}
              colorPalette="categorical" valueFormatter={(v) => `${fmtNum(v, 1)} KB`} />
          )}
        </QueryState>
      </SectionCard>
    </div>
  );
}

function Fact({ label, value, ok }: { label: string; value: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between rounded border px-2 py-1">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`inline-flex items-center gap-1 text-sm font-medium tabular-nums ${ok ? 'text-success' : ''}`}>
        {ok && <CheckCircle2 className="h-3.5 w-3.5" />}{value}
      </span>
    </div>
  );
}
