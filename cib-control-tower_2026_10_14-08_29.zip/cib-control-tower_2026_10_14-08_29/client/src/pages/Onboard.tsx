import { useState } from 'react';
import {
  Input, Label, Button, Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
  Alert, AlertTitle, AlertDescription,
} from '@databricks/appkit-ui/react';
import { CheckCircle2, PlusCircle, TriangleAlert, Circle } from 'lucide-react';
import { SectionCard } from '../components/common';

const WORKSPACES: Record<string, string> = {
  'cib-fcc-prod-uks': 'UK South',
  'cib-credit-prod-uks': 'UK South',
  'cib-markets-prod-sea': 'Southeast Asia',
  'cib-txnbank-prod-cin': 'Central India',
};
const WORKSTREAMS = ['Financial Crime Compliance', 'Credit Risk', 'Markets', 'Transaction Banking'];

interface FormState {
  model_name: string; model_version: string; workstream: string; workspace: string;
  serving_type: string; owner: string; upstream_feed: string; risk_tier: string;
}
const EMPTY: FormState = {
  model_name: '', model_version: '', workstream: '', workspace: '',
  serving_type: '', owner: '', upstream_feed: '', risk_tier: '',
};

export function Onboard() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<FormState | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const set = (k: keyof FormState, v: string) => setForm((s) => ({ ...s, [k]: v }));
  const region = WORKSPACES[form.workspace] ?? '';

  const missing = (Object.keys(EMPTY) as (keyof FormState)[]).filter((k) => !form[k]);

  async function submit() {
    setError(null);
    if (missing.length) { setError('Please complete all required fields.'); return; }
    setSubmitting(true);
    try {
      const res = await fetch('/api/models', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, region }),
      });
      const body = await res.json();
      if (!res.ok) { setError(body.error ?? 'Could not onboard the model.'); return; }
      setDone(form);
      setForm(EMPTY);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Request failed.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Onboard a Model</h1>
        <p className="text-sm text-muted-foreground">Register a new model in the hub. It appears as “Awaiting first sync” until the spoke exporter sends metrics.</p>
      </div>

      {done && (
        <Alert>
          <CheckCircle2 className="h-4 w-4 text-success" />
          <AlertTitle>{done.model_name} {done.model_version} onboarded</AlertTitle>
          <AlertDescription>
            <p className="mb-2">What happens next in the {done.workspace} spoke:</p>
            <ul className="space-y-1 text-sm">
              <li className="flex items-center gap-2"><Circle className="h-3 w-3" /> Create the inference-profile monitor on the model’s predictions</li>
              <li className="flex items-center gap-2"><Circle className="h-3 w-3" /> Deploy the exporter config (metric allowlist + export gate)</li>
              <li className="flex items-center gap-2"><Circle className="h-3 w-3" /> First aggregated metrics arrive the morning after the first window</li>
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {error && (
        <Alert variant="destructive"><TriangleAlert className="h-4 w-4" /><AlertTitle>{error}</AlertTitle></Alert>
      )}

      <SectionCard title="Model details">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Model name"><Input value={form.model_name} onChange={(e) => set('model_name', e.target.value)} placeholder="e.g. aml_alert_scorer" /></Field>
          <Field label="Version"><Input value={form.model_version} onChange={(e) => set('model_version', e.target.value)} placeholder="e.g. v1" /></Field>
          <Field label="Workspace">
            <Sel value={form.workspace} onChange={(v) => set('workspace', v)} options={Object.keys(WORKSPACES)} placeholder="Select workspace" />
          </Field>
          <Field label="Region"><Input value={region} readOnly placeholder="Auto from workspace" className="bg-muted" /></Field>
          <Field label="Workstream"><Sel value={form.workstream} onChange={(v) => set('workstream', v)} options={WORKSTREAMS} placeholder="Select workstream" /></Field>
          <Field label="Serving type"><Sel value={form.serving_type} onChange={(v) => set('serving_type', v)} options={['realtime', 'batch']} placeholder="Select serving" /></Field>
          <Field label="Owner"><Input value={form.owner} onChange={(e) => set('owner', e.target.value)} placeholder="e.g. Priya Nair" /></Field>
          <Field label="Risk tier"><Sel value={form.risk_tier} onChange={(v) => set('risk_tier', v)} options={['High', 'Medium', 'Low']} placeholder="Select risk tier" /></Field>
          <Field label="Upstream feed" className="sm:col-span-2"><Input value={form.upstream_feed} onChange={(e) => set('upstream_feed', e.target.value)} placeholder="e.g. payments_gateway_feed" /></Field>
        </div>
        <div className="mt-4 flex justify-end">
          <Button onClick={submit} disabled={submitting}>
            <PlusCircle className="mr-2 h-4 w-4" />{submitting ? 'Onboarding…' : 'Onboard model'}
          </Button>
        </div>
      </SectionCard>
    </div>
  );
}

function Field({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`flex flex-col gap-1.5 ${className ?? ''}`}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function Sel({ value, onChange, options, placeholder }: { value: string; onChange: (v: string) => void; options: string[]; placeholder: string }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger><SelectValue placeholder={placeholder} /></SelectTrigger>
      <SelectContent>{options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
    </Select>
  );
}
