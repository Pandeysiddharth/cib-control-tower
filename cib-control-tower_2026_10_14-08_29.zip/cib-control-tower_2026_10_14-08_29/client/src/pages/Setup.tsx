import { useEffect, useState } from 'react';
import {
  Button, Progress, Alert, AlertTitle, AlertDescription, Input, Badge, Separator,
} from '@databricks/appkit-ui/react';
import {
  Database, RotateCcw, CalendarClock, CheckCircle2, XCircle, Copy, Check, Loader2, Sparkles,
} from 'lucide-react';
import { SectionCard } from '../components/common';
import { SAMPLE_QUESTIONS, useAppConfig } from '../lib/useAppConfig';

interface ProgressEvent {
  phase: string; table?: string; inserted?: number; total?: number; message?: string;
  result?: { tables?: Record<string, number> }; error?: string;
}

async function runStream(url: string, onEvent: (e: ProgressEvent) => void): Promise<void> {
  const res = await fetch(url, { method: 'POST' });
  if (!res.body) throw new Error('No response stream');
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const parts = buf.split('\n\n');
    buf = parts.pop() ?? '';
    for (const part of parts) {
      const line = part.split('\n').find((l) => l.startsWith('data:'));
      if (line) { try { onEvent(JSON.parse(line.slice(5).trim())); } catch { /* ignore */ } }
    }
  }
}

const GENERAL_INSTRUCTIONS = `## SCOPE AND SAFETY
- Only aggregated model monitoring metrics exist in this hub. No customer data, inference rows, features, predictions or logs.
- For questions about individual customers/accounts/transactions/predictions/logs, say that data does not exist here and offer the aggregated view.
- For "why" questions reason only from the metrics (when it started, which slices/metrics moved, which models share the same upstream_feed). Root cause on raw data is investigated by the owner in the spoke.

## DEFAULTS
- Use slice_name='overall' unless a segment such as country is asked for. Always filter on one metric_name. Join on model_name, model_version, workspace. Round drift/psi/auc/f1/precision/recall/positive_rate to 3 decimals.

## TIME
- Treat MAX(CAST(window_start AS DATE)) as today; never current_date(). Accuracy metrics arrive weeks late because labels are delayed.

## STATUS
- Use v_current_status for current/latest (STALE, BREACH, WARN, OK). STALE = the workspace stopped sending metrics and must never be called healthy. Use unified_metrics / v_model_daily_status for history.`;

export function Setup() {
  const { config } = useAppConfig();
  const [initialized, setInitialized] = useState<boolean | null>(null);
  const [running, setRunning] = useState<string | null>(null);
  const [pct, setPct] = useState(0);
  const [message, setMessage] = useState('');
  const [counts, setCounts] = useState<Record<string, number> | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [checks, setChecks] = useState<Record<string, unknown> | null>(null);
  const [spaceId, setSpaceId] = useState('');
  const [copied, setCopied] = useState<string | null>(null);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const loadStatus = () => fetch('/api/setup/status').then((r) => r.json()).then((s) => setInitialized(s.initialized)).catch(() => setInitialized(false));
  const loadChecks = () => fetch('/api/setup/checks').then((r) => r.json()).then(setChecks).catch(() => setChecks(null));

  useEffect(() => { loadStatus(); loadChecks(); }, []);
  useEffect(() => { if (config?.genieSpaceId) setSpaceId(config.genieSpaceId); }, [config]);

  async function run(action: 'seed' | 'reset' | 'refresh') {
    setRunning(action); setErr(null); setPct(0); setCounts(null); setMessage('Starting…');
    try {
      await runStream(`/api/setup/${action}`, (e) => {
        if (e.error) { setErr(e.error); return; }
        if (e.message) setMessage(e.message);
        if (e.phase === 'insert' && e.total) {
          setMessage(`Inserting ${e.table}…`);
          setPct(Math.min(99, Math.round(((e.inserted ?? 0) / e.total) * 100)));
        }
        if (e.phase === 'complete') { setPct(100); setMessage('Done'); if (e.result?.tables) setCounts(e.result.tables); }
      });
      await loadStatus(); await loadChecks();
    } catch (e) {
      setErr(e instanceof Error ? e.message : 'Operation failed');
    } finally {
      setRunning(null);
    }
  }

  const copy = (key: string, text: string) => {
    navigator.clipboard?.writeText(text).then(() => { setCopied(key); setTimeout(() => setCopied(null), 1500); });
  };

  async function saveSpace() {
    setSavedMsg(null);
    const res = await fetch('/api/config/genie', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ spaceId }),
    });
    const b = await res.json();
    setSavedMsg(res.ok ? b.note : (b.error ?? 'Could not save'));
  }

  const checkItems = buildChecks(checks, config?.genieConnected ?? false);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Setup</h1>
        <p className="text-sm text-muted-foreground">
          Create and seed the demo data in <code className="rounded bg-muted px-1">{config?.catalog}.{config?.schema}</code>.
          All data is synthetic and aggregated — no customer data.
        </p>
      </div>

      {initialized === false && (
        <Alert>
          <Database className="h-4 w-4" />
          <AlertTitle>No data yet</AlertTitle>
          <AlertDescription>The hub tables are empty or missing. Click “Initialize demo data” to create and seed them.</AlertDescription>
        </Alert>
      )}

      <SectionCard title="Demo data" description="Initialization is idempotent and seeds ~15,000 aggregated metric rows in batches.">
        <div className="flex flex-wrap gap-3">
          <Button onClick={() => run('seed')} disabled={!!running}>
            {running === 'seed' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Database className="mr-2 h-4 w-4" />}
            Initialize demo data
          </Button>
          <Button variant="outline" onClick={() => run('refresh')} disabled={!!running}>
            {running === 'refresh' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <CalendarClock className="mr-2 h-4 w-4" />}
            Refresh dates
          </Button>
          <Button variant="outline" onClick={() => run('reset')} disabled={!!running}>
            {running === 'reset' ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RotateCcw className="mr-2 h-4 w-4" />}
            Reset demo data
          </Button>
        </div>

        {running && (
          <div className="mt-4 space-y-2">
            <Progress value={pct} />
            <div className="text-xs text-muted-foreground">{message} · {pct}%</div>
          </div>
        )}

        {err && (
          <Alert variant="destructive" className="mt-4"><XCircle className="h-4 w-4" /><AlertTitle>Setup error</AlertTitle><AlertDescription>{err}</AlertDescription></Alert>
        )}

        {counts && (
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {Object.entries(counts).map(([t, n]) => (
              <div key={t} className="rounded-md border p-2 text-center">
                <div className="text-lg font-semibold tabular-nums">{n.toLocaleString()}</div>
                <div className="text-[11px] text-muted-foreground">{t}</div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard title="Acceptance checks" description="Validates the seeded data matches the expected scenario." action={
        <Button size="sm" variant="ghost" onClick={loadChecks}>Re-run</Button>
      }>
        <ul className="space-y-2">
          {checkItems.map((c) => (
            <li key={c.label} className="flex items-start gap-2 text-sm">
              {c.pass ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" /> : <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />}
              <div>
                <span className={c.pass ? '' : 'text-destructive'}>{c.label}</span>
                {c.detail && <span className="ml-1 text-xs text-muted-foreground">({c.detail})</span>}
              </div>
            </li>
          ))}
        </ul>
      </SectionCard>

      <SectionCard title="Genie" description="Natural-language querying over the hub tables.">
        <div className="mb-3 flex items-center gap-2">
          <span className="text-sm">Status:</span>
          {config?.genieConnected
            ? <Badge className="bg-success text-success-foreground"><CheckCircle2 className="mr-1 h-3 w-3" />Connected</Badge>
            : <Badge variant="secondary">Not connected</Badge>}
          {config?.genieSpaceId && <code className="rounded bg-muted px-1 text-xs">{config.genieSpaceId}</code>}
        </div>

        {!config?.genieConnected && (
          <p className="mb-3 text-sm text-muted-foreground">
            To connect, create an AI/BI Genie space over the seven tables and two views, then set
            <code className="mx-1 rounded bg-muted px-1">DATABRICKS_GENIE_SPACE_ID</code> and restart. Use the copy
            buttons below to seed the space description, instructions and sample questions.
          </p>
        )}

        <div className="grid gap-3 md:grid-cols-2">
          <CopyBlock title="Space description" copied={copied === 'desc'} onCopy={() => copy('desc', SPACE_DESCRIPTION)} text={SPACE_DESCRIPTION} />
          <CopyBlock title="General instructions" copied={copied === 'ins'} onCopy={() => copy('ins', GENERAL_INSTRUCTIONS)} text={GENERAL_INSTRUCTIONS} />
          <CopyBlock title="Sample questions" copied={copied === 'q'} onCopy={() => copy('q', SAMPLE_QUESTIONS.join('\n'))} text={SAMPLE_QUESTIONS.join('\n')} />
          <CopyBlock title="Example SQL (breaching now)" copied={copied === 'sql'} onCopy={() => copy('sql', EXAMPLE_SQL)} text={EXAMPLE_SQL} />
        </div>

        <Separator className="my-4" />
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex flex-col gap-1">
            <label className="text-xs text-muted-foreground">Genie space ID</label>
            <Input value={spaceId} onChange={(e) => setSpaceId(e.target.value)} placeholder="01f1…" className="w-80" />
          </div>
          <Button variant="outline" onClick={saveSpace} disabled={!spaceId}><Sparkles className="mr-2 h-4 w-4" />Save space ID</Button>
        </div>
        {savedMsg && <p className="mt-2 text-xs text-muted-foreground">{savedMsg}</p>}
      </SectionCard>
    </div>
  );
}

interface CheckItem { label: string; pass: boolean; detail?: string }
function buildChecks(checks: Record<string, unknown> | null, genieConnected: boolean): CheckItem[] {
  if (!checks) return [{ label: 'Run the seed to evaluate acceptance checks', pass: false }];
  const sc = (checks.statusCounts as { current_status: string; n: string }[] | undefined) ?? [];
  const map: Record<string, number> = {};
  for (const r of sc) map[r.current_status] = Number(r.n);
  const dims = (checks.dims as Record<string, string>) ?? {};
  const boundary = (checks.boundary as Record<string, string>) ?? {};
  const mu = Number((checks.mu as Record<string, string>)?.n ?? 1);
  const nonAllow = Number((checks.nonAllow as Record<string, string>)?.n ?? 1);
  const dimsOk = Number(dims.models) === 12 && Number(dims.workspaces) === 4 && Number(dims.regions) === 3;
  const statusOk = map.BREACH === 4 && map.STALE === 3 && map.WARN === 1 && map.OK === 4;
  const boundaryOk = Number(boundary.raw ?? 1) === 0 && Number(boundary.log ?? 1) === 0;
  return [
    { label: '12 models, 4 workspaces, 3 regions', pass: dimsOk, detail: `${dims.models ?? '?'} / ${dims.workspaces ?? '?'} / ${dims.regions ?? '?'}` },
    { label: 'Status counts: 4 BREACH, 3 STALE, 1 WARN, 4 OK', pass: statusOk, detail: `B${map.BREACH ?? 0} S${map.STALE ?? 0} W${map.WARN ?? 0} O${map.OK ?? 0}` },
    { label: 'Raw and log rows exported are all zero', pass: boundaryOk, detail: `raw=${boundary.raw ?? '?'}, log=${boundary.log ?? '?'}` },
    { label: 'No country=MU rows in unified_metrics', pass: mu === 0, detail: `${mu} rows` },
    { label: 'No non-allowlisted metric names', pass: nonAllow === 0, detail: `${nonAllow} rows` },
    { label: 'Genie connected', pass: genieConnected, detail: genieConnected ? 'space configured' : 'set DATABRICKS_GENIE_SPACE_ID' },
  ];
}

function CopyBlock({ title, text, onCopy, copied }: { title: string; text: string; onCopy: () => void; copied: boolean }) {
  return (
    <div className="rounded-md border">
      <div className="flex items-center justify-between border-b px-3 py-1.5">
        <span className="text-xs font-medium">{title}</span>
        <Button size="sm" variant="ghost" className="h-7" onClick={onCopy}>
          {copied ? <Check className="h-3.5 w-3.5 text-success" /> : <Copy className="h-3.5 w-3.5" />}
        </Button>
      </div>
      <pre className="max-h-40 overflow-auto whitespace-pre-wrap p-3 text-[11px] text-muted-foreground">{text}</pre>
    </div>
  );
}

const SPACE_DESCRIPTION = 'Aggregated model monitoring metrics for every CIB classical ML model across Databricks workspaces and regions. Ask about drift, data quality, volume, freshness, accuracy, alerts, workspace sync health, serving cost and what data leaves each workspace. Contains only aggregated metrics: no customer data, no inference rows, no logs.';

const EXAMPLE_SQL = `SELECT model_name, workspace, region, breached_metrics
FROM control_tower_cib.model_monitoring.v_current_status
WHERE current_status = 'BREACH'
ORDER BY region, model_name`;
