import { useMemo } from 'react';
import {
  useAnalyticsQuery, BarChart, LineChart, Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
  Alert, AlertTitle, AlertDescription,
} from '@databricks/appkit-ui/react';
import { DollarSign, TriangleAlert } from 'lucide-react';
import { useFilters, registryDateParams } from '../lib/filters';
import { SectionCard, QueryState, KpiTile } from '../components/common';
import { fmtUsd, isTrue } from '../lib/format';

export function CostUsage() {
  const f = useFilters();
  const byWs = useAnalyticsQuery('cost_by_workspace', registryDateParams(f));
  const byModel = useAnalyticsQuery('cost_by_model', registryDateParams(f));
  const topEp = useAnalyticsQuery('cost_top_endpoints', registryDateParams(f));
  const trend = useAnalyticsQuery('cost_trend', registryDateParams(f));
  const topo = useAnalyticsQuery('topology_health', {});

  const total = (byWs.data ?? []).reduce((s, r) => s + Number(r.cost_usd), 0);
  const staleWs = new Set((topo.data ?? []).filter((r) => isTrue(r.is_stale)).map((r) => r.workspace));
  const staleWithCost = (byWs.data ?? []).filter((r) => staleWs.has(r.workspace));

  const trendData = useMemo(() => {
    const byDate = new Map<string, Record<string, number | string>>();
    const wss = new Set<string>();
    for (const r of (trend.data ?? []) as { date: string; workspace: string; cost_usd: number }[]) {
      wss.add(r.workspace);
      const d = r.date;
      if (!byDate.has(d)) byDate.set(d, { date: d });
      byDate.get(d)![r.workspace] = Number(r.cost_usd);
    }
    return { data: Array.from(byDate.values()), workspaces: Array.from(wss).sort() };
  }, [trend.data]);

  const topModels = (byModel.data ?? []).slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Cost & Usage</h1>
        <p className="text-sm text-muted-foreground">Daily serving cost by workspace and model, honouring the global filters.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiTile label="Total serving cost" value={fmtUsd(total)} icon={<DollarSign className="h-3.5 w-3.5" />} sub="selected range" />
        <KpiTile label="Workspaces" value={(byWs.data ?? []).length} />
        <KpiTile label="Endpoints" value={(topEp.data ?? []).length >= 10 ? '10+' : (topEp.data ?? []).length} />
        <KpiTile label="Models with cost" value={(byModel.data ?? []).length} />
      </div>

      {staleWithCost.length > 0 && (
        <Alert>
          <TriangleAlert className="h-4 w-4" />
          <AlertTitle>Cost keeps flowing for silent workspaces</AlertTitle>
          <AlertDescription>
            {staleWithCost.map((r) => `${r.workspace} (${fmtUsd(r.cost_usd)})`).join(', ')} {staleWithCost.length === 1 ? 'is' : 'are'} still
            billing serving cost even though {staleWithCost.length === 1 ? 'it has' : 'they have'} stopped sending metrics — the endpoint is alive but the exporter is not.
          </AlertDescription>
        </Alert>
      )}

      <SectionCard title="Daily cost trend by workspace">
        <QueryState loading={trend.loading} error={trend.error} data={trendData.data}>
          {() => (
            <LineChart data={trendData.data} xKey="date" yKey={trendData.workspaces} height={260} showLegend smooth={false}
              colorPalette="categorical" valueFormatter={(v) => fmtUsd(v)} />
          )}
        </QueryState>
      </SectionCard>

      <div className="grid gap-6 lg:grid-cols-2">
        <SectionCard title="Cost by workspace">
          <QueryState loading={byWs.loading} error={byWs.error} data={byWs.data}>
            {(rows) => (
              <BarChart data={rows.map((r) => ({ workspace: r.workspace, Cost: Number(r.cost_usd) }))}
                xKey="workspace" yKey={['Cost']} orientation="horizontal" height={240}
                colorPalette="sequential" valueFormatter={(v) => fmtUsd(v)} />
            )}
          </QueryState>
        </SectionCard>

        <SectionCard title="Top 10 endpoints by cost">
          <QueryState loading={topEp.loading} error={topEp.error} data={topEp.data}>
            {(rows) => (
              <Table>
                <TableHeader>
                  <TableRow><TableHead>Endpoint</TableHead><TableHead>Workspace</TableHead><TableHead className="text-right">Cost</TableHead></TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => (
                    <TableRow key={r.endpoint_name}>
                      <TableCell className="font-medium">{r.endpoint_name}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{r.workspace}</TableCell>
                      <TableCell className="text-right tabular-nums">{fmtUsd(r.cost_usd)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </QueryState>
        </SectionCard>
      </div>

      <SectionCard title="Cost per model" description="Top 10 models by serving cost in range.">
        <QueryState loading={byModel.loading} error={byModel.error} data={topModels}>
          {(rows) => (
            <BarChart data={rows.map((r) => ({ model: r.model_name, Cost: Number(r.cost_usd) }))}
              xKey="model" yKey={['Cost']} height={260} colorPalette="sequential" valueFormatter={(v) => fmtUsd(v)} />
          )}
        </QueryState>
      </SectionCard>
    </div>
  );
}
