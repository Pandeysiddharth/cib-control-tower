import { GenieChatPanel } from '../components/GenieChatPanel';
import { useWhoami } from '../lib/useWhoami';

export function AskGeniePage() {
  const who = useWhoami();
  return (
    <div className="flex h-[calc(100vh-8.5rem)] flex-col">
      <div className="mb-3">
        <h1 className="text-xl font-semibold">Ask Genie</h1>
        <p className="text-sm text-muted-foreground">
          Natural-language questions over aggregated monitoring metrics — drift, data quality, alerts,
          sync health, cost and the data boundary. No customer data, inference rows or logs exist here.
        </p>
      </div>
      <div className="min-h-0 flex-1 overflow-hidden rounded-lg border bg-card">
        <GenieChatPanel showChips userEmail={who.email ?? (who.preview ? 'editor (preview)' : null)} />
      </div>
    </div>
  );
}
