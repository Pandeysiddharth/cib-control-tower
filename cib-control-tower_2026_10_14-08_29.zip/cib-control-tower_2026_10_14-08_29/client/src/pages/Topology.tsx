import { useState, useMemo } from 'react';
import {
  useAnalyticsQuery, ToggleGroup, ToggleGroupItem, Table, TableBody, TableCell, TableHead,
  TableHeader, TableRow, Badge,
} from '@databricks/appkit-ui/react';
import { Server, Database, CloudOff, CheckCircle2 } from 'lucide-react';
import { SectionCard, QueryState } from '../components/common';
import { statusMeta } from '../lib/status';
import { fmtDateTime, isTrue } from '../lib/format';

interface TopoRow {
  workspace: string; region: string; last_sync: string; transport_option: string;
  hours_behind: number; is_stale: boolean; model_count: number; breach_count: number; stale_count: number;
}

const TRANSPORTS = [
  { key: 'opt1', label: 'Option 1 — Shared catalog', leaves: 'No (same region)', history: 'Yes', cross: 'No', approval: 'Low', note: 'Spoke writes metrics into a shared Unity Catalog in the same region as the hub.' },
  { key: 'opt2a', label: 'Option 2a — API push (Private Link)', leaves: 'Aggregated only', history: 'Yes', cross: 'Yes', approval: 'Medium', note: 'Spoke pushes aggregated metrics over Private Link across regions.' },
  { key: 'opt2b', label: 'Option 2b — Delta Sharing (metrics view)', leaves: 'Aggregated only', history: 'Yes', cross: 'Yes', approval: 'Medium', note: 'Hub reads a shared metrics-only Delta Sharing view; raw tables are never shared.' },
  { key: 'opt3', label: 'Option 3 — Live federated', leaves: 'Nothing stored', history: 'No central history', cross: 'Yes', approval: 'High', note: 'Hub queries metrics live via federation; nothing is persisted centrally.' },
];

export function Topology() {
  const [transport, setTransport] = useState('opt2a');
  const topo = useAnalyticsQuery('topology_health', {});
  const t = TRANSPORTS.find((x) => x.key === transport)!;

  const byRegion = useMemo(() => {
    const m = new Map<string, TopoRow[]>();
    for (const r of topo.data ?? []) {
      if (!m.has(r.region)) m.set(r.region, []);
      m.get(r.region)!.push(r);
    }
    return Array.from(m.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  }, [topo.data]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Topology & Transport</h1>
        <p className="text-sm text-muted-foreground">
          Spokes compute metrics locally and send only aggregates to the hub (UK South). The transport
          toggle is illustrative and changes no data — only aggregated metrics ever travel.
        </p>
      </div>

      <SectionCard title="Hub-and-spoke" description="Spokes coloured by sync health.">
        <QueryState loading={topo.loading} error={topo.error} data={topo.data}>
          {() => (
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="flex items-center gap-2 rounded-lg border-2 border-primary bg-primary/5 px-5 py-3">
                  <Server className="h-5 w-5 text-primary" />
                  <div>
                    <div className="text-sm font-semibold">Monitoring Hub</div>
                    <div className="text-xs text-muted-foreground">UK South · aggregated metrics only</div>
                  </div>
                </div>
              </div>

              <div className={`mx-auto h-6 w-px border-l-2 border-dashed border-primary/50 ${transport === 'opt3' ? '' : 'animate-pulse'}`} />

              <div className="grid gap-4 md:grid-cols-3">
                {byRegion.map(([region, spokes]) => (
                  <div key={region} className="rounded-lg border bg-muted/30 p-3">
                    <div className="mb-2 text-center text-xs font-semibold uppercase tracking-wide text-muted-foreground">{region}</div>
                    <div className="space-y-2">
                      {spokes.map((s) => {
                        const stale = isTrue(s.is_stale);
                        const color = stale ? statusMeta('STALE').color : Number(s.breach_count) > 0 ? statusMeta('BREACH').color : statusMeta('OK').color;
                        return (
                          <div key={s.workspace} className="rounded-md border bg-card p-2.5" style={{ borderLeftWidth: 4, borderLeftColor: color }}>
                            <div className="flex items-center justify-between">
                              <span className="inline-flex items-center gap-1.5 text-sm font-medium">
                                <Database className="h-3.5 w-3.5" />{s.workspace}
                              </span>
                              {stale
                                ? <Badge variant="secondary"><CloudOff className="mr-1 h-3 w-3" />stale</Badge>
                                : <Badge variant="outline"><CheckCircle2 className="mr-1 h-3 w-3" />live</Badge>}
                            </div>
                            <div className="mt-1 text-[11px] text-muted-foreground">
                              {s.model_count} models · {s.breach_count} breaching · {Number(s.hours_behind).toFixed(0)}h behind
                            </div>
                            <div className="mt-0.5 text-[11px] text-muted-foreground">Last sync {fmtDateTime(s.last_sync)}</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </QueryState>
      </SectionCard>

      <SectionCard title="Transport option" description="Compare how metrics travel from spoke to hub. Illustrative only.">
        <ToggleGroup type="single" value={transport} onValueChange={(v) => v && setTransport(v)} className="mb-4 flex-wrap justify-start gap-2">
          {TRANSPORTS.map((x) => (
            <ToggleGroupItem key={x.key} value={x.key} className="border text-xs data-[state=on]:bg-primary data-[state=on]:text-primary-foreground">
              {x.label}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>

        <p className="mb-3 text-sm text-muted-foreground">{t.note}</p>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Does any data leave the workspace?</TableHead>
              <TableHead>Central history & alerts</TableHead>
              <TableHead>Works across regions</TableHead>
              <TableHead>Policy approval needed</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">{t.leaves}</TableCell>
              <TableCell>{t.history}</TableCell>
              <TableCell>{t.cross}</TableCell>
              <TableCell>{t.approval}</TableCell>
            </TableRow>
          </TableBody>
        </Table>
        <p className="mt-3 inline-flex items-center gap-1.5 text-xs text-success">
          <CheckCircle2 className="h-3.5 w-3.5" /> In every option, only aggregated metrics travel — raw data stays in the spoke.
        </p>
      </SectionCard>
    </div>
  );
}
