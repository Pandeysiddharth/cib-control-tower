import { createBrowserRouter, RouterProvider } from 'react-router';
import { FilterProvider } from './lib/filters';
import { GeniePanelProvider } from './components/AskGeniePanel';
import { Layout } from './components/Layout';
import { FleetOverview } from './pages/FleetOverview';
import { ModelDetail } from './pages/ModelDetail';
import { AlertsPage } from './pages/Alerts';
import { AskGeniePage } from './pages/AskGenie';
import { DataBoundary } from './pages/DataBoundary';
import { Topology } from './pages/Topology';
import { CostUsage } from './pages/Cost';
import { Onboard } from './pages/Onboard';
import { RiskPack } from './pages/RiskPack';
import { Setup } from './pages/Setup';

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      { path: '/', element: <FleetOverview /> },
      { path: '/models', element: <ModelDetail /> },
      { path: '/alerts', element: <AlertsPage /> },
      { path: '/ask', element: <AskGeniePage /> },
      { path: '/boundary', element: <DataBoundary /> },
      { path: '/topology', element: <Topology /> },
      { path: '/cost', element: <CostUsage /> },
      { path: '/onboard', element: <Onboard /> },
      { path: '/riskpack', element: <RiskPack /> },
      { path: '/setup', element: <Setup /> },
    ],
  },
]);

export default function App() {
  return (
    <FilterProvider>
      <GeniePanelProvider>
        <RouterProvider router={router} />
      </GeniePanelProvider>
    </FilterProvider>
  );
}
