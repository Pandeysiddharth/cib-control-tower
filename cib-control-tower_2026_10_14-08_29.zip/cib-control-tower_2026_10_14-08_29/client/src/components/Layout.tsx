import { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router';
import {
  useAnalyticsQuery, Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
  Button, Sheet, SheetContent, Separator,
} from '@databricks/appkit-ui/react';
import {
  LayoutDashboard, Activity, Bell, Sparkles, ShieldCheck, Network, DollarSign,
  PlusCircle, FileText, Settings, Menu, RotateCcw,
} from 'lucide-react';
import { useFilters } from '../lib/filters';

const NAV = [
  { to: '/', label: 'Fleet Overview', Icon: LayoutDashboard, end: true },
  { to: '/models', label: 'Model Detail', Icon: Activity },
  { to: '/alerts', label: 'Alerts', Icon: Bell },
  { to: '/ask', label: 'Ask Genie', Icon: Sparkles },
  { to: '/boundary', label: 'Data Boundary Ledger', Icon: ShieldCheck },
  { to: '/topology', label: 'Topology & Transport', Icon: Network },
  { to: '/cost', label: 'Cost & Usage', Icon: DollarSign },
  { to: '/onboard', label: 'Onboard a Model', Icon: PlusCircle },
  { to: '/riskpack', label: 'Model Risk Pack', Icon: FileText },
  { to: '/setup', label: 'Setup', Icon: Settings },
];

const ALL = '__all__';

function NavItems({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="flex flex-col gap-0.5 p-2">
      {NAV.map(({ to, label, Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          onClick={onNavigate}
          className={({ isActive }) =>
            `flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors ${
              isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            }`
          }
        >
          <Icon className="h-4 w-4 shrink-0" />
          {label}
        </NavLink>
      ))}
    </nav>
  );
}

function FilterSelect({
  label, value, onChange, options,
}: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[10px] font-medium uppercase tracking-wide text-navy-muted">{label}</label>
      <Select value={value === '' ? ALL : value} onValueChange={(v) => onChange(v === ALL ? '' : v)}>
        <SelectTrigger className="h-8 w-[150px] border-white/15 bg-white/10 text-xs text-navy-foreground">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={ALL}>All</SelectItem>
          {options.map((o) => (
            <SelectItem key={o} value={o}>{o}</SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function FilterBar() {
  const f = useFilters();
  const { data } = useAnalyticsQuery('model_registry_list', {});
  const rows = data ?? [];
  const uniq = (key: string) => Array.from(new Set(rows.map((r) => String((r as Record<string, unknown>)[key])))).sort();

  return (
    <div className="flex flex-wrap items-end gap-3 border-b bg-navy px-4 py-2.5 text-navy-foreground md:px-6">
      <FilterSelect label="Region" value={f.region} onChange={f.setRegion} options={uniq('region')} />
      <FilterSelect label="Workspace" value={f.workspace} onChange={f.setWorkspace} options={uniq('workspace')} />
      <FilterSelect label="Workstream" value={f.workstream} onChange={f.setWorkstream} options={uniq('workstream')} />
      <FilterSelect label="Risk tier" value={f.risk} onChange={f.setRisk} options={['High', 'Medium', 'Low']} />
      <div className="flex flex-col gap-1">
        <label className="text-[10px] font-medium uppercase tracking-wide text-navy-muted">From</label>
        <input type="date" value={f.start} min={f.earliestDate} max={f.end}
          onChange={(e) => f.setStart(e.target.value)}
          className="h-8 rounded-md border border-white/15 bg-white/10 px-2 text-xs text-navy-foreground [color-scheme:dark]" />
      </div>
      <div className="flex flex-col gap-1">
        <label className="text-[10px] font-medium uppercase tracking-wide text-navy-muted">To</label>
        <input type="date" value={f.end} min={f.start} max={f.latestDate}
          onChange={(e) => f.setEnd(e.target.value)}
          className="h-8 rounded-md border border-white/15 bg-white/10 px-2 text-xs text-navy-foreground [color-scheme:dark]" />
      </div>
      <Button variant="ghost" size="sm" onClick={f.reset}
        className="h-8 text-navy-foreground hover:bg-white/10 hover:text-navy-foreground">
        <RotateCcw className="mr-1 h-3.5 w-3.5" /> Reset
      </Button>
    </div>
  );
}

export function Layout() {
  const [mobileNav, setMobileNav] = useState(false);
  const { pathname } = useLocation();
  const hideFilters = ['/setup', '/onboard', '/ask'].includes(pathname);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Top navy chrome */}
      <header className="flex items-center gap-3 bg-navy px-4 py-3 text-navy-foreground md:px-6">
        <Button variant="ghost" size="icon" className="md:hidden text-navy-foreground hover:bg-white/10"
          onClick={() => setMobileNav(true)}>
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <ShieldCheck className="h-5 w-5" />
          </div>
          <div className="leading-tight">
            <div className="text-sm font-semibold">Unified Model Monitoring Control Tower</div>
            <div className="text-[11px] text-navy-muted">Hub-and-spoke · aggregated metrics only</div>
          </div>
        </div>
      </header>

      {!hideFilters && <FilterBar />}

      <div className="flex flex-1">
        {/* Desktop sidebar */}
        <aside className="hidden w-60 shrink-0 border-r bg-sidebar md:block">
          <div className="sticky top-0">
            <NavItems />
          </div>
        </aside>

        {/* Mobile nav */}
        <Sheet open={mobileNav} onOpenChange={setMobileNav}>
          <SheetContent side="left" className="w-64 p-0">
            <div className="py-6"><NavItems onNavigate={() => setMobileNav(false)} /></div>
          </SheetContent>
        </Sheet>

        <main className="min-w-0 flex-1 p-4 md:p-6">
          <Outlet />
        </main>
      </div>

      <Separator />
      <footer className="bg-navy px-4 py-3 text-center text-xs text-navy-muted md:px-6">
        Aggregated monitoring metrics only. No customer data in this hub.
      </footer>
    </div>
  );
}
