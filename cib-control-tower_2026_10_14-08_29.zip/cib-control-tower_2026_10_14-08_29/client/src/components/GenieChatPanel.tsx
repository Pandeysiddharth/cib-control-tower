import { useEffect, useRef } from 'react';
import {
  GenieChatMessageList, GenieChatInput, useGenieChat, Badge, Button, Alert, AlertTitle,
  AlertDescription,
} from '@databricks/appkit-ui/react';
import { Sparkles, Info, ShieldCheck } from 'lucide-react';
import { SAMPLE_QUESTIONS, useAppConfig } from '../lib/useAppConfig';

interface Props {
  /** A question to auto-send when it changes (used by "Explain this breach"). */
  pendingQuestion?: string | null;
  onConsumed?: () => void;
  showChips?: boolean;
  className?: string;
  userEmail?: string | null;
}

export function GenieChatPanel({ pendingQuestion, onConsumed, showChips = true, className, userEmail }: Props) {
  const { config } = useAppConfig();
  const connected = config?.genieConnected ?? false;
  const { messages, status, sendMessage, hasPreviousPage, fetchPreviousPage, error } = useGenieChat({
    alias: 'default',
    persistInUrl: false,
  });
  const lastSent = useRef<string | null>(null);

  useEffect(() => {
    if (connected && pendingQuestion && pendingQuestion !== lastSent.current) {
      lastSent.current = pendingQuestion;
      sendMessage(pendingQuestion);
      onConsumed?.();
    }
  }, [pendingQuestion, connected, sendMessage, onConsumed]);

  if (!connected) {
    return (
      <div className={`flex flex-col gap-4 p-4 ${className ?? ''}`}>
        <Alert>
          <Info className="h-4 w-4" />
          <AlertTitle>Genie not connected</AlertTitle>
          <AlertDescription>
            Natural-language querying is turned off because no Genie space is configured. Open the
            Setup page to connect a space, then reload.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className={`flex h-full min-h-0 flex-col ${className ?? ''}`}>
      <div className="flex items-center justify-between border-b px-4 py-2 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5" /> Runs as {userEmail || 'the signed-in user'} · aggregated metrics only
        </span>
        <Badge variant="outline" className="font-normal">AI-generated — verify</Badge>
      </div>

      <GenieChatMessageList
        messages={messages}
        status={status}
        hasPreviousPage={hasPreviousPage}
        onFetchPreviousPage={fetchPreviousPage}
        className="flex-1 min-h-0"
      />

      {error && (
        <div className="px-4 pb-2 text-xs text-destructive">{error}</div>
      )}

      {showChips && messages.length === 0 && (
        <div className="flex flex-wrap gap-2 px-4 pb-2">
          {SAMPLE_QUESTIONS.map((q) => (
            <Button key={q} size="sm" variant="outline" className="h-auto whitespace-normal py-1 text-left text-xs"
              onClick={() => sendMessage(q)}>
              <Sparkles className="mr-1 h-3 w-3 shrink-0" />{q}
            </Button>
          ))}
        </div>
      )}

      <div className="border-t p-3">
        <GenieChatInput onSend={sendMessage} placeholder="Ask about drift, alerts, cost, data boundary…" />
      </div>
    </div>
  );
}
