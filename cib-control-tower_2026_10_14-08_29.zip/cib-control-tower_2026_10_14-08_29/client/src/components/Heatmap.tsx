import { useMemo } from 'react';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@databricks/appkit-ui/react';
import { statusMeta } from '../lib/status';
import { fmtDate } from '../lib/format';

export interface HeatmapRow {
  model_name: string;
  workspace: string;
  window_date: string;
  worst_status: string;
}

interface Props {
  rows: HeatmapRow[];
  start: string;
  end: string;
  /** models whose workspace is currently STALE → paint missing recent days grey */
  staleModels: Set<string>;
  onCellClick: (model: string, workspace: string, date: string) => void;
}

function dateRange(start: string, end: string): string[] {
  const out: string[] = [];
  if (!start || !end) return out;
  const d = new Date(start + 'T00:00:00Z');
  const last = new Date(end + 'T00:00:00Z');
  while (d <= last && out.length < 400) {
    out.push(d.toISOString().slice(0, 10));
    d.setUTCDate(d.getUTCDate() + 1);
  }
  return out;
}

export function Heatmap({ rows, start, end, staleModels, onCellClick }: Props) {
  const dates = useMemo(() => dateRange(start, end), [start, end]);

  const { groups, cellMap, maxDate } = useMemo(() => {
    const cellMap = new Map<string, string>(); // model|workspace|date -> status
    const maxDate = new Map<string, string>(); // model|workspace -> last date with data
    const byWs = new Map<string, Map<string, string>>(); // workspace -> model -> workspace (track models)
    for (const r of rows) {
      const key = `${r.model_name}|${r.workspace}`;
      cellMap.set(`${key}|${r.window_date}`, r.worst_status);
      const prev = maxDate.get(key);
      if (!prev || r.window_date > prev) maxDate.set(key, r.window_date);
      if (!byWs.has(r.workspace)) byWs.set(r.workspace, new Map());
      byWs.get(r.workspace)!.set(r.model_name, r.workspace);
    }
    const groups = Array.from(byWs.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([ws, models]) => ({ workspace: ws, models: Array.from(models.keys()).sort() }));
    return { groups, cellMap, maxDate };
  }, [rows]);

  if (dates.length === 0 || groups.length === 0) {
    return <div className="text-sm text-muted-foreground">No data for the current filters.</div>;
  }

  const cellW = 'min(14px, 2.6vw)';

  return (
    <TooltipProvider>
      <div className="overflow-x-auto">
        <div className="min-w-fit">
          {groups.map((g) => (
            <div key={g.workspace} className="mb-3">
              <div className="mb-1 text-xs font-semibold text-muted-foreground">{g.workspace}</div>
              {g.models.map((model) => {
                const key = `${model}|${g.workspace}`;
                const md = maxDate.get(key);
                const isStale = staleModels.has(key);
                return (
                  <div key={model} className="flex items-center gap-2">
                    <div className="w-44 shrink-0 truncate text-right text-[11px] text-foreground" title={model}>{model}</div>
                    <div className="flex gap-[2px]">
                      {dates.map((date) => {
                        const status = cellMap.get(`${key}|${date}`);
                        let color: string;
                        let label: string;
                        if (status) {
                          color = statusMeta(status).color;
                          label = statusMeta(status).label;
                        } else if (isStale && md && date > md) {
                          color = statusMeta('STALE').color;
                          label = 'Stale (no data)';
                        } else {
                          color = 'var(--muted)';
                          label = 'No data';
                        }
                        return (
                          <Tooltip key={date}>
                            <TooltipTrigger asChild>
                              <button
                                onClick={() => onCellClick(model, g.workspace, date)}
                                className="h-3.5 rounded-[2px] transition-transform hover:scale-150"
                                style={{ width: cellW, minWidth: 6, backgroundColor: color }}
                                aria-label={`${model} ${date} ${label}`}
                              />
                            </TooltipTrigger>
                            <TooltipContent>
                              <div className="text-xs">
                                <div className="font-medium">{model}</div>
                                <div>{fmtDate(date)} · {label}</div>
                              </div>
                            </TooltipContent>
                          </Tooltip>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </TooltipProvider>
  );
}
