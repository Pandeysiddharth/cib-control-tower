import { LineChart } from '@databricks/appkit-ui/react';
import { metricLabel } from '../lib/format';
import { PRIMARY, DESTRUCTIVE } from '../lib/colors';

export interface TrendPoint {
  window_date: string;
  value: number;
  threshold?: number | null;
}

/** A single-metric trend line with an optional flat threshold line. */
export function TrendChart({
  metric, points, height = 200,
}: { metric: string; points: TrendPoint[]; height?: number }) {
  const hasThreshold = points.some((p) => p.threshold !== null && p.threshold !== undefined);
  const data = points.map((p) => ({
    date: p.window_date,
    [metricLabel(metric)]: Number(p.value),
    ...(hasThreshold ? { Threshold: p.threshold === null || p.threshold === undefined ? null : Number(p.threshold) } : {}),
  }));
  const yKey = hasThreshold ? [metricLabel(metric), 'Threshold'] : [metricLabel(metric)];
  return (
    <LineChart
      data={data}
      xKey="date"
      yKey={yKey}
      height={height}
      showLegend={hasThreshold}
      smooth={false}
      colors={hasThreshold ? [PRIMARY(), DESTRUCTIVE()] : [PRIMARY()]}
      valueFormatter={(v) => Number(v).toLocaleString('en-US', { maximumFractionDigits: 3 })}
    />
  );
}
