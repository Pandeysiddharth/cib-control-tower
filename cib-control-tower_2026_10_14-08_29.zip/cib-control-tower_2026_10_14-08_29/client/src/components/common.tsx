import type { ReactNode } from 'react';
import {
  Card, CardHeader, CardTitle, CardDescription, CardContent, CardAction,
  Skeleton, Empty, EmptyHeader, EmptyTitle, EmptyDescription, Alert, AlertTitle,
  AlertDescription,
} from '@databricks/appkit-ui/react';
import { Inbox, TriangleAlert } from 'lucide-react';
import { statusMeta } from '../lib/status';

export function StatusChip({ status, className }: { status: string; className?: string }) {
  const m = statusMeta(status);
  const Icon = m.Icon;
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${m.chip} ${className ?? ''}`}>
      <Icon className="h-3 w-3" />
      {m.label}
    </span>
  );
}

export function KpiTile({
  label, value, sub, accent, icon,
}: { label: string; value: ReactNode; sub?: ReactNode; accent?: 'default' | 'destructive' | 'warning' | 'success' | 'stale'; icon?: ReactNode }) {
  const accentClass =
    accent === 'destructive' ? 'text-destructive'
      : accent === 'warning' ? 'text-foreground'
        : accent === 'success' ? 'text-success'
          : accent === 'stale' ? 'text-stale'
            : 'text-foreground';
  return (
    <Card className="gap-2">
      <CardHeader className="pb-0">
        <CardDescription className="flex items-center gap-1.5 text-xs uppercase tracking-wide">
          {icon}{label}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className={`text-3xl font-semibold tabular-nums ${accentClass}`}>{value}</div>
        {sub && <div className="mt-1 text-xs text-muted-foreground">{sub}</div>}
      </CardContent>
    </Card>
  );
}

export function SectionCard({
  title, description, action, children, className,
}: { title: string; description?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
        {action && <CardAction>{action}</CardAction>}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

export function LoadingRows({ rows = 4 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-9 w-full" />
      ))}
    </div>
  );
}

export function EmptyState({ title, description }: { title: string; description?: string }) {
  return (
    <Empty>
      <EmptyHeader>
        <Inbox className="h-6 w-6 text-muted-foreground" />
        <EmptyTitle>{title}</EmptyTitle>
        {description && <EmptyDescription>{description}</EmptyDescription>}
      </EmptyHeader>
    </Empty>
  );
}

export function ErrorState({ message }: { message: string }) {
  return (
    <Alert variant="destructive">
      <TriangleAlert className="h-4 w-4" />
      <AlertTitle>Could not load data</AlertTitle>
      <AlertDescription>{message}</AlertDescription>
    </Alert>
  );
}

/** Standard loading/error/empty wrapper for a query result. */
export function QueryState<T>({
  loading, error, data, children, empty,
}: {
  loading: boolean; error: string | null; data: T[] | null;
  children: (rows: T[]) => ReactNode; empty?: string;
}) {
  if (loading) return <LoadingRows />;
  if (error) return <ErrorState message={error} />;
  if (!data || data.length === 0) return <EmptyState title={empty ?? 'No data for the current filters'} />;
  return <>{children(data)}</>;
}
