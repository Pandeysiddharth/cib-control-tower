import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, Button,
} from '@databricks/appkit-ui/react';
import { Sparkles } from 'lucide-react';
import { GenieChatPanel } from './GenieChatPanel';

interface GeniePanelContextValue {
  openGenie: (question?: string) => void;
}

const GeniePanelContext = createContext<GeniePanelContextValue | null>(null);

export function GeniePanelProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState<string | null>(null);

  const openGenie = useCallback((question?: string) => {
    if (question) setPending(question);
    setOpen(true);
  }, []);

  return (
    <GeniePanelContext.Provider value={{ openGenie }}>
      {children}

      {/* Persistent Ask Genie button, available on every page */}
      <Button
        onClick={() => openGenie()}
        className="fixed bottom-5 right-5 z-40 shadow-lg"
        size="lg"
      >
        <Sparkles className="mr-2 h-4 w-4" /> Ask Genie
      </Button>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="flex w-full flex-col gap-0 p-0 sm:max-w-xl">
          <SheetHeader className="border-b px-4 py-3">
            <SheetTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" /> Ask Genie
            </SheetTitle>
            <SheetDescription>
              Natural-language questions over aggregated monitoring metrics. No customer data in this hub.
            </SheetDescription>
          </SheetHeader>
          <div className="min-h-0 flex-1">
            <GenieChatPanel pendingQuestion={pending} onConsumed={() => setPending(null)} />
          </div>
        </SheetContent>
      </Sheet>
    </GeniePanelContext.Provider>
  );
}

export function useGeniePanel(): GeniePanelContextValue {
  const ctx = useContext(GeniePanelContext);
  if (!ctx) throw new Error('useGeniePanel must be used within GeniePanelProvider');
  return ctx;
}
