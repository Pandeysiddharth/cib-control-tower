import { CheckCircle2, AlertTriangle, XCircle, CloudOff, Clock, type LucideIcon } from 'lucide-react';

export type Status = 'OK' | 'WARN' | 'BREACH' | 'STALE' | 'AWAITING';

interface StatusMeta {
  label: string;
  Icon: LucideIcon;
  /** Tailwind classes for a solid chip */
  chip: string;
  /** CSS color var for dots / heatmap cells */
  color: string;
  /** subtle background tint classes */
  tint: string;
  rank: number;
}

const META: Record<Status, StatusMeta> = {
  BREACH: { label: 'Breach', Icon: XCircle, chip: 'bg-destructive text-destructive-foreground', color: 'var(--destructive)', tint: 'bg-destructive/10 text-destructive', rank: 4 },
  STALE: { label: 'Stale', Icon: CloudOff, chip: 'bg-stale text-stale-foreground', color: 'var(--stale)', tint: 'bg-stale/15 text-stale', rank: 3 },
  WARN: { label: 'Warn', Icon: AlertTriangle, chip: 'bg-warning text-warning-foreground', color: 'var(--warning)', tint: 'bg-warning/15 text-foreground', rank: 2 },
  AWAITING: { label: 'Awaiting first sync', Icon: Clock, chip: 'bg-awaiting text-awaiting-foreground', color: 'var(--awaiting)', tint: 'bg-awaiting/15 text-foreground', rank: 1 },
  OK: { label: 'OK', Icon: CheckCircle2, chip: 'bg-success text-success-foreground', color: 'var(--success)', tint: 'bg-success/10 text-success', rank: 0 },
};

export function statusMeta(status: string): StatusMeta {
  return META[(status as Status)] ?? META.OK;
}

export const STATUS_ORDER: Status[] = ['BREACH', 'STALE', 'WARN', 'AWAITING', 'OK'];
