import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { useAnalyticsQuery } from '@databricks/appkit-ui/react';
import { sql } from '@databricks/appkit-ui/js';
import { daysAgoStr } from './format';

export interface FilterState {
  region: string;
  workspace: string;
  workstream: string;
  risk: string;
  start: string;
  end: string;
}

interface FilterContextValue extends FilterState {
  setRegion: (v: string) => void;
  setWorkspace: (v: string) => void;
  setWorkstream: (v: string) => void;
  setRisk: (v: string) => void;
  setStart: (v: string) => void;
  setEnd: (v: string) => void;
  reset: () => void;
  latestDate: string;
  earliestDate: string;
  ready: boolean;
}

const FilterContext = createContext<FilterContextValue | null>(null);

export function FilterProvider({ children }: { children: ReactNode }) {
  const { data } = useAnalyticsQuery('latest_date', {});
  const latestDate = (data?.[0]?.latest_date as string | undefined) ?? '';
  const earliestDate = (data?.[0]?.earliest_date as string | undefined) ?? '';

  const [region, setRegion] = useState('');
  const [workspace, setWorkspace] = useState('');
  const [workstream, setWorkstream] = useState('');
  const [risk, setRisk] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [inited, setInited] = useState(false);

  useEffect(() => {
    if (latestDate && !inited) {
      setEnd(latestDate);
      setStart(daysAgoStr(latestDate, 29));
      setInited(true);
    }
  }, [latestDate, inited]);

  const value: FilterContextValue = useMemo(
    () => ({
      region, workspace, workstream, risk, start, end,
      setRegion, setWorkspace, setWorkstream, setRisk, setStart, setEnd,
      reset: () => {
        setRegion(''); setWorkspace(''); setWorkstream(''); setRisk('');
        if (latestDate) { setEnd(latestDate); setStart(daysAgoStr(latestDate, 29)); }
      },
      latestDate, earliestDate, ready: inited,
    }),
    [region, workspace, workstream, risk, start, end, latestDate, earliestDate, inited],
  );

  return <FilterContext.Provider value={value}>{children}</FilterContext.Provider>;
}

export function useFilters(): FilterContextValue {
  const ctx = useContext(FilterContext);
  if (!ctx) throw new Error('useFilters must be used inside FilterProvider');
  return ctx;
}

/** Param builders — pass only the params each query declares. */
export function registryParams(f: FilterState) {
  return {
    p_region: sql.string(f.region),
    p_workspace: sql.string(f.workspace),
    p_workstream: sql.string(f.workstream),
    p_risk: sql.string(f.risk),
  };
}

export function registryDateParams(f: FilterState) {
  return {
    ...registryParams(f),
    p_start: sql.date(f.start || '1900-01-01'),
    p_end: sql.date(f.end || '9999-12-31'),
  };
}

export function dateParams(f: FilterState) {
  return {
    p_start: sql.date(f.start || '1900-01-01'),
    p_end: sql.date(f.end || '9999-12-31'),
  };
}

export function modelDateParams(model: string, workspace: string, f: FilterState) {
  return {
    p_model: sql.string(model),
    p_workspace: sql.string(workspace),
    p_start: sql.date(f.start || '1900-01-01'),
    p_end: sql.date(f.end || '9999-12-31'),
  };
}

export function modelParams(model: string, workspace: string) {
  return {
    p_model: sql.string(model),
    p_workspace: sql.string(workspace),
  };
}
