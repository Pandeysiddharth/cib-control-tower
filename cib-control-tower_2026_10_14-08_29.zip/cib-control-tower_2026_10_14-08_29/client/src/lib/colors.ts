/**
 * Resolve CSS custom properties to concrete color strings for ECharts.
 * ECharts renders to <canvas> via zrender, which cannot read `var(--token)`
 * and cannot parse `oklch(...)`. We resolve the token and normalize it to
 * `rgb(...)` using the browser so zrender always gets a parseable color.
 */
const cache = new Map<string, string>();

function normalizeToRgb(raw: string): string {
  if (typeof document === 'undefined') return raw;
  try {
    const el = document.createElement('span');
    el.style.color = raw;
    el.style.display = 'none';
    document.body.appendChild(el);
    const rgb = getComputedStyle(el).color;
    el.remove();
    return rgb || raw;
  } catch {
    return raw;
  }
}

export function cssVar(name: string): string {
  if (cache.has(name)) return cache.get(name)!;
  let v = '#888888';
  if (typeof window !== 'undefined') {
    const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    if (raw) v = normalizeToRgb(raw);
  }
  cache.set(name, v);
  return v;
}

export const STATUS_VAR: Record<string, string> = {
  BREACH: '--destructive',
  STALE: '--stale',
  WARN: '--warning',
  AWAITING: '--awaiting',
  OK: '--success',
};

export function statusColor(status: string): string {
  return cssVar(STATUS_VAR[status] ?? '--muted-foreground');
}

export const PRIMARY = () => cssVar('--primary');
export const DESTRUCTIVE = () => cssVar('--destructive');
