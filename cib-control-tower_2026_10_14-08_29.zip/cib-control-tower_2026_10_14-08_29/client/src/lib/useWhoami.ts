import { useEffect, useState } from 'react';

let cached: { email: string | null; preview: boolean } | null = null;

export function useWhoami(): { email: string | null; preview: boolean } {
  const [who, setWho] = useState(cached ?? { email: null, preview: true });
  useEffect(() => {
    if (cached) return;
    fetch('/api/whoami').then((r) => r.json()).then((w) => { cached = w; setWho(w); }).catch(() => {});
  }, []);
  return who;
}
