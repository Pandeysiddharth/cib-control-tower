/** Formatting helpers for aggregated metric values. */
export const toNum = (v: number | string | null | undefined): number =>
  v === null || v === undefined || v === '' ? NaN : Number(v);

export function fmtInt(v: number | string | null | undefined): string {
  const n = toNum(v);
  return Number.isNaN(n) ? '—' : Math.round(n).toLocaleString('en-US');
}

export function fmtNum(v: number | string | null | undefined, dp = 3): string {
  const n = toNum(v);
  return Number.isNaN(n) ? '—' : n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: dp });
}

export function fmtUsd(v: number | string | null | undefined): string {
  const n = toNum(v);
  return Number.isNaN(n) ? '—' : `$${n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
}

export function fmtKb(v: number | string | null | undefined): string {
  const n = toNum(v);
  return Number.isNaN(n) ? '—' : `${n.toLocaleString('en-US', { maximumFractionDigits: 1 })} KB`;
}

export function fmtDate(v: string | null | undefined): string {
  if (!v) return '—';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v).slice(0, 10);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

export function fmtDateTime(v: string | null | undefined): string {
  if (!v) return '—';
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return String(v);
  return d.toLocaleString('en-GB', {
    day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', timeZone: 'UTC',
  });
}

export function daysAgoStr(date: string, n: number): string {
  const d = new Date(date + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() - n);
  return d.toISOString().slice(0, 10);
}

export function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/** Friendly metric labels + units for charts and tables. */
export const METRIC_LABELS: Record<string, string> = {
  row_count: 'Row count',
  null_pct: 'Null %',
  feature_psi_max: 'Feature PSI (max)',
  prediction_drift_js: 'Prediction drift (JS)',
  positive_rate: 'Positive rate',
  freshness_hours: 'Freshness (hours)',
  latency_p95_ms: 'Latency p95 (ms)',
  error_rate_pct: 'Error rate %',
  auc: 'AUC',
  f1: 'F1',
  precision: 'Precision',
  recall: 'Recall',
  sync_stale: 'Sync stale',
};

export function metricLabel(name: string): string {
  return METRIC_LABELS[name] ?? name;
}

/** Coerce a SQL boolean (often serialized as the string "true"/"false") to a real boolean. */
export function isTrue(v: unknown): boolean {
  return v === true || v === 'true' || v === 1 || v === '1';
}
