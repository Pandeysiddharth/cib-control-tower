import { useEffect, useState } from 'react';

export interface AppConfig {
  catalog: string;
  schema: string;
  genieSpaceId: string;
  genieConnected: boolean;
}

let cached: AppConfig | null = null;

export function useAppConfig(): { config: AppConfig | null; loading: boolean } {
  const [config, setConfig] = useState<AppConfig | null>(cached);
  const [loading, setLoading] = useState(!cached);

  useEffect(() => {
    if (cached) return;
    let active = true;
    fetch('/api/config')
      .then((r) => r.json())
      .then((c: AppConfig) => {
        cached = c;
        if (active) { setConfig(c); setLoading(false); }
      })
      .catch(() => active && setLoading(false));
    return () => { active = false; };
  }, []);

  return { config, loading };
}

export const SAMPLE_QUESTIONS: string[] = [
  'Which models are breaching right now, and in which region?',
  "Which model's prediction drift has increased the most in the last 14 days?",
  'Show AUC trend for all high-risk models.',
  'Which workspaces have stopped reporting?',
  'Compare drift across regions this week.',
  'Which models share the same upstream feed as the one with the volume drop?',
];
