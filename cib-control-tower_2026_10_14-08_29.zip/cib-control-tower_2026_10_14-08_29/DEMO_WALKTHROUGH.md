# Unified Model Monitoring Control Tower — Demo Walkthrough

A presenter's guide for showing the Control Tower to a customer. It explains the
business problem, the architecture, and gives a scene-by-scene demo script with
the exact data stories to point at and talking points to use.

> **One-line pitch:** A single hub where model owners, model-risk reviewers and
> operations teams monitor every classical ML model across many Databricks
> workspaces and regions — and ask questions in plain English — while **no
> customer data, inference rows or logs ever leave the workspace where the model runs**.

---

## 1. The problem we're solving (set the scene — 1 min)

Large banks run ML models in **many** Databricks workspaces, split by business line
and region for data-residency and blast-radius reasons. That creates three pains:

- **No single pane of glass.** Each team watches its own models; risk and ops have
  no fleet-wide view of what's healthy, drifting, or breaching *right now*.
- **Data cannot be centralised.** Customer data, predictions and logs are
  governed and often cannot leave their region/workspace — so you can't just copy
  everything into one place to monitor it.
- **Answering questions is slow.** "Which models are breaching? Which share the
  broken upstream feed? What's it costing us?" takes a data pull and a analyst.

The Control Tower is a **hub-and-spoke** design that fixes all three.

---

## 2. The architecture (the核心 idea — 2 min)

```
   Spoke workspaces (where models run)                 Hub (this app)
   ┌───────────────────────────┐
   │ model + predictions + logs │  compute metrics      ┌──────────────────┐
   │ (NEVER leave the spoke)    │  locally, then send   │ aggregated       │
   │                            │  ONLY aggregates  ───▶ │ metrics only     │
   │ export gate: allowlist +   │                       │ + Genie + portal │
   │ small-slice suppression    │                       └──────────────────┘
   └───────────────────────────┘
```

- Each **spoke** computes monitoring statistics locally and sends **only
  aggregated metrics** (drift, data quality, volume, freshness, accuracy, latency,
  cost) to the hub.
- An **export gate** in each spoke drops anything not on an approved metric
  allowlist, blocks identifier-like fields, and suppresses tiny slices that could
  re-identify individuals. **Raw rows exported = 0, log rows exported = 0 — always.**
- The **hub** (this app) stores only those aggregates in one Unity Catalog schema
  (`control_tower_cib.model_monitoring`), serves the portal, and powers an AI/BI
  **Genie** space for natural-language questions.
- All demo data is **synthetic**; the app creates and seeds it itself.

**Why the customer cares:** you get fleet-wide monitoring *and* keep your data
protection posture intact. The "Data Boundary Ledger" page is the proof.

---

## 3. Who uses it (three personas)

| Persona | What they come here for |
|---|---|
| **Model owners** | Is my model healthy? What drifted, when, and in which slice? |
| **Model risk reviewers** | Fleet risk posture, breach history, a printable risk pack, and *proof* that no customer data leaves a workspace. |
| **Operations teams** | Which workspaces stopped reporting? What are the open alerts? What is serving costing us? |

---

## 4. The demo environment at a glance

- **12 models** across **4 workspaces** in **3 regions**:
  - `cib-fcc-prod-uks` — Financial Crime Compliance (UK South)
  - `cib-credit-prod-uks` — Credit Risk (UK South)
  - `cib-markets-prod-sea` — Markets (Southeast Asia)
  - `cib-txnbank-prod-cin` — Transaction Banking (Central India)
- Current fleet status (what you'll see on the landing page):
  - **4 BREACH**, **3 STALE**, **1 WARN**, **4 OK**
- The data contains **five planted stories** so the demo always has something to find
  (see the script below). The latest day of data is always "yesterday".

---

## 5. Demo script (10–15 minutes)

Walk the left-hand navigation top to bottom. Each scene below has **what to click**,
**what to say**, and **the story to land**.

### Scene 1 — Fleet Overview (the landing page) · 2 min
**Click:** it's the home page.
**Say:** "This is the whole fleet in one view — every model, every workspace,
every region."
**Point at:**
- **KPI tiles:** 12 monitored, Healthy %, Warnings, Breaches, **Stale models**, and
  **Workspaces reporting vs expected (3/4)**. "Three of four spokes synced in the
  last 30 hours — one went quiet."
- **Model-by-day health heatmap:** rows are models grouped by workspace, columns
  are days, colour is the worst status that day.
  - `aml_alert_scorer` shows **green → amber → red** left-to-right — a *gradual
    drift* building over ~2 weeks.
  - `sanctions_name_match` and `txn_fraud_classifier` go **red in the last 3 days** —
    a sudden break.
  - The `cib-markets-prod-sea` models turn **grey** at the right edge — the spoke
    stopped sending data; grey ≠ healthy.
  - **Click any red cell** → it deep-links into Model Detail for that model and date.
- **Needs attention (top 5):** ranked by severity and risk tier, each with a
  one-line plain-English summary.
- **Green strip:** "Metrics only. Raw data never leaves its workspace." → links to
  the Data Boundary Ledger.

**Land it:** "In five seconds a reviewer knows the fleet is 33% healthy, has four
active breaches, and one spoke has gone dark."

### Scene 2 — Model Detail · 2 min
**Click:** Model Detail → select **`aml_alert_scorer`** (or arrive by clicking a
heatmap cell).
**Say:** "This is the model owner's view."
**Point at:**
- Header: owner, workspace, region, serving type, risk tier, **upstream feed**,
  current status.
- **Trend charts with threshold lines:** `prediction_drift_js` and
  `feature_psi_max` climb through their red threshold lines over the last ~2 weeks,
  while `auc`/`f1` look fine — **because the labels are delayed 14 days, the
  accuracy drop hasn't surfaced yet.** (Note the "labels delayed" tag on accuracy
  charts.)
- **Country slice chart:** the **SG** slice drifts far faster than the others —
  the problem is concentrated in one segment.
- **Breach history** timeline and **open alerts** for the model.
- **"Explain this breach"** button → opens the **Ask Genie** side panel pre-loaded
  with a structured question (when it started, which slices/metrics moved, which
  models share the upstream feed, what to check locally).

**Land it:** "The owner sees not just *that* it's drifting, but *where* (SG) and
that accuracy will confirm it later — and can ask Genie for the narrative."

### Scene 3 — Ask Genie · 2 min (the wow moment)
**Click:** Ask Genie.
**Say:** "Everyone — owners, risk, ops — can ask questions in plain English. It only
ever sees aggregated metrics, and it shows you the SQL it ran."
**Click these chips (good, reliable demo questions):**
1. *"Which models are breaching right now, and in which region?"* → returns the four
   breaching models, all in UK South, with a result table and the generated SQL.
2. *"Which model's prediction drift has increased the most in the last 14 days?"* →
   surfaces `aml_alert_scorer`.
3. *"Which workspaces have stopped reporting?"* → surfaces `cib-markets-prod-sea`.
4. *"Which models share the same upstream feed as the one with the volume drop?"* →
   shows that `txn_fraud_classifier`, `sanctions_name_match` **and** `cashflow_forecast`
   all read `payments_gateway_feed` — the incident spans regions.

**Point at:** the **"Runs as <you>"** identity badge, the **"AI-generated — verify"**
disclaimer, and the collapsible **generated SQL** on each answer.

**Land it:** "No dashboards to pre-build. Ask, get an answer grounded in governed
metrics, and see exactly how it was computed."

### Scene 4 — Alerts · 1 min (operations)
**Click:** Alerts.
**Say:** "Alerts are opened automatically from breach episodes and from workspaces
going silent."
**Point at:**
- The `sync_stale` Critical alerts on the three Markets models.
- The `txn_fraud_classifier` alert is **ACK'd to Marcus Webb** with the note
  *"Investigating payments_gateway_feed outage…"* — showing real triage.
- **Row actions:** Acknowledge, Assign, Resolve, add note — these **write back** to
  the alerts table live.
- The "alerts opened per day by severity" chart.

### Scene 5 — Data Boundary Ledger · 2 min (the data-protection centrepiece)
**Click:** Data Boundary Ledger.
**Say:** "This is the page your data-protection and model-risk reviewers will love.
It's the receipt that proves only aggregates leave each spoke."
**Point at:**
- **Raw rows exported: 0** and **Log rows exported: 0** — with green checks, every
  workspace, always.
- Per-workspace cards: metric rows, **KB** transferred (kilobytes, not gigabytes),
  rejected-field count, suppressed small-slice count, transport option, last sync.
- **Allowed contract metrics** table (the allowlist) and **"Blocked at the source"**
  — real examples like `customer_id`, `account_number`, `free_text_note`,
  `metric:frequent_items`, each with the reason it was dropped (field *names* only,
  never values).

**Land it:** "Centralised monitoring with zero centralisation of sensitive data.
That's the whole point of hub-and-spoke."

### Scene 6 — Topology & Transport · 1 min
**Click:** Topology & Transport.
**Say:** "Here's the physical picture — the hub in UK South and the spokes by
region, coloured by sync health."
**Point at:** `cib-markets-prod-sea` is **stale / ~72h behind**. Toggle the four
transport options (Shared catalog / API push over Private Link / Delta Sharing of a
metrics-only view / Live federated) and read the comparison card. "The toggle is
illustrative — but in every option, only aggregated metrics travel."

### Scene 7 — Cost & Usage · 1 min
**Click:** Cost & Usage.
**Say:** "Serving cost by workspace and model, honouring the same global filters."
**Point at:** the callout **"Cost keeps flowing for silent workspaces"** — the
Markets endpoints are still billing even though they've stopped sending metrics.
"The endpoint is alive; the *exporter* is broken. That's a real, expensive failure
mode you'd otherwise miss."

### Scene 8 — Onboard a Model · 30 sec
**Click:** Onboard a Model.
**Say:** "Registering a new model is a short form. It validates required fields and
prevents duplicate name+version in the same workspace."
**Point at:** on submit it inserts into the registry and shows the spoke checklist
(create monitor, deploy exporter config, first metrics arrive). New models show
**"Awaiting first sync"** on the fleet view — never falsely healthy.

### Scene 9 — Model Risk Pack · 1 min (the leave-behind)
**Click:** Model Risk Pack.
**Say:** "For a committee or an auditor, generate a pack for the current filters."
**Point at:** status counts, a plain-English **executive summary written only from
the aggregated numbers**, top-5 at-risk models with owners, key trend charts, open
alerts and a boundary-ledger summary. **Copy as markdown** or **Print to PDF**.

### Scene 10 — Setup · 1 min (for the technical audience)
**Click:** Setup.
**Say:** "The app is self-contained — it creates and seeds its own demo data in
Unity Catalog."
**Point at:** Initialize / Refresh dates / Reset buttons, the progress bar and row
counts, and the **green acceptance checklist** (12 models, the exact status counts,
raw/log = 0, no suppressed slices leaked, no non-allowlisted metrics, Genie
connected). Also the Genie connection status and the copy-ready space description /
instructions / sample questions.

---

## 6. The five planted stories (your narrative arc)

Use these as the spine of the demo — each illustrates a different real-world failure:

1. **Gradual drift — `aml_alert_scorer`.** Prediction drift and feature PSI climb
   past threshold over ~2 weeks; the **SG country slice** drifts fastest; accuracy
   looks fine *only because labels lag 14 days*. → *Early warning before accuracy
   confirms it; slice-level root-causing.*
2. **Upstream outage — `payments_gateway_feed`.** In the last 3 days
   `txn_fraud_classifier` and `sanctions_name_match` crater on volume + freshness
   (breach); `cashflow_forecast` dips to a warning. All three share the feed —
   **across two regions**. → *One upstream incident, fleet-wide blast radius.*
3. **Silent accuracy decay — `corporate_pd`.** AUC slides below 0.75, but because
   labels lag 30 days the breach only appears in **windows older than a month**. →
   *Delayed-label models need patience; the hub tracks it honestly.*
4. **Silent spoke — `cib-markets-prod-sea`.** Stopped sending metrics 3 days ago;
   its models show **STALE** (never "healthy"), `sync_stale` alerts open, and
   **serving cost keeps accruing**. → *A broken exporter is invisible to the spoke
   team but obvious to the hub.*
5. **Healthy majority + history.** The remaining models are OK, with a few historical
   warnings and already-resolved breaches so trends and the timeline look real.

---

## 7. Key talking points / differentiators

- **Data stays home.** Hub holds only aggregates; the Boundary Ledger proves raw
  and log exports are zero. Centralised insight, decentralised data.
- **STALE is a first-class state.** A workspace that stops reporting is flagged as
  stale and **never shown as healthy** — the most dangerous failure to miss.
- **Honest about delayed labels.** Accuracy metrics surface weeks late by design;
  the UI and Genie both say so, so no one over-trusts a "green" AUC.
- **Shared-feed blast radius.** Models are linked by `upstream_feed`, so one feed
  incident is visible across every affected model and region.
- **Natural language with receipts.** Genie answers show the generated SQL and run
  as the signed-in user over governed, aggregated tables only.
- **Self-contained & reproducible.** One click seeds a believable fleet; "Refresh
  dates" rolls the window so the demo is always "current".
- **Built on the lakehouse.** Unity Catalog governance, a SQL warehouse for every
  query (parameterised, cached), AI/BI Genie — no bespoke infrastructure.

---

## 8. Likely questions & answers

- **"Is any customer data in here?"** No. Only aggregated metrics — no inference
  rows, features, predictions or logs. The Data Boundary Ledger is the audit trail.
- **"How does a spoke send data without exposing it?"** It computes stats locally
  and an export gate enforces an allowlist, blocks identifiers, and suppresses tiny
  slices before anything leaves. See Topology & Transport for the options.
- **"Who can see what?"** Queries run on-behalf-of the signed-in user through the
  SQL warehouse, governed by Unity Catalog permissions.
- **"Does it work across regions?"** Yes — the four demo spokes span three regions;
  the transport options cover same-region and cross-region patterns.
- **"What happens when a model is new?"** It shows "Awaiting first sync", never a
  false green.
- **"Is this real data?"** For the demo it's fully synthetic and generated by the
  app. In production the spokes feed real aggregated metrics into the same schema.

---

## 9. Reset / re-run between demos

- **Setup → Refresh dates** re-seeds so the latest window is "yesterday" (keeps the
  demo current without changing the story).
- **Setup → Reset demo data** drops and recreates everything.
- **Setup → Initialize demo data** (idempotent) if the tables are missing.
- The acceptance checklist on Setup should be **all green** before you present.

---

## 10. 60-second version (if you're short on time)

Fleet Overview (4 breaches, 1 spoke dark) → click the red `aml_alert_scorer` cell →
Model Detail (drift up, SG slice worst, labels lagging) → Ask Genie *"Which models
are breaching right now?"* and *"Which workspaces have stopped reporting?"* → Data
Boundary Ledger (raw/log exported = 0). Done.
