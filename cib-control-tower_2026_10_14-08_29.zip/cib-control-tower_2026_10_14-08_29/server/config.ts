/**
 * Runtime configuration for the Unified Model Monitoring Control Tower.
 * All values come from environment / app.yaml. No hard-coded credentials.
 */
export const CONFIG = {
  catalog: process.env.CONTROL_TOWER_CATALOG || 'control_tower_cib',
  schema: process.env.CONTROL_TOWER_SCHEMA || 'model_monitoring',
  warehouseId: process.env.DATABRICKS_WAREHOUSE_ID || '',
  genieSpaceId: process.env.DATABRICKS_GENIE_SPACE_ID || '',
};

/** Fully-qualified `catalog`.`schema` prefix for table names. */
export function fq(table: string): string {
  return `\`${CONFIG.catalog}\`.\`${CONFIG.schema}\`.\`${table}\``;
}

export function schemaFqn(): string {
  return `\`${CONFIG.catalog}\`.\`${CONFIG.schema}\``;
}
