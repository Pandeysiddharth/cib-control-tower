import { analytics, createApp, genie, server } from '@databricks/appkit';
import type { Request } from 'express';
import { z } from 'zod';
import { CONFIG, fq } from './config.js';
import { createConfigTableSql, createSchemaSql } from './seed/ddl.js';
import { resetAll, seedAll, type ProgressEvent } from './seed/runner.js';
import { strLit } from './seed/sqlvalues.js';

type RunSql = (sql: string) => Promise<unknown>;

/** Normalize analytics.query() result into an array of row objects. */
function rowsOf(result: unknown): Record<string, unknown>[] {
  if (Array.isArray(result)) return result as Record<string, unknown>[];
  const r = result as { data?: unknown; data_array?: unknown } | null;
  if (r && Array.isArray(r.data)) return r.data as Record<string, unknown>[];
  if (r && Array.isArray(r.data_array)) return r.data_array as Record<string, unknown>[];
  return [];
}

// Genie is always registered; with an empty spaces map it stays dormant (no throw)
// until a Space ID is configured, so the rest of the app keeps working.
const geniePlugin = genie({ spaces: CONFIG.genieSpaceId ? { default: CONFIG.genieSpaceId } : {} });

let seedInFlight = false;

await createApp({
  plugins: [server(), analytics({}), geniePlugin],
  async onPluginsReady(appkit) {
    // user-scoped SQL executor (OBO). In preview this is the editor identity.
    const analyticsExports = appkit.analytics as {
      asUser: (req: Request) => { query: RunSql };
    };
    const asUser = (req: Request): RunSql => {
      const scoped = analyticsExports.asUser(req);
      return (sql: string) => scoped.query(sql);
    };

    appkit.server.extend((app) => {
      // ---------- SETUP ----------
      const streamSeed = async (
        req: Request, res: import('express').Response,
        action: (runSql: RunSql, progress: (ev: ProgressEvent) => void) => Promise<unknown>,
      ) => {
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache, no-transform');
        res.setHeader('Connection', 'keep-alive');
        res.flushHeaders?.();
        const send = (ev: ProgressEvent & { result?: unknown; error?: string }) =>
          res.write(`data: ${JSON.stringify(ev)}\n\n`);
        if (seedInFlight) {
          send({ phase: 'error', error: 'A setup operation is already running. Please wait.' });
          res.end();
          return;
        }
        seedInFlight = true;
        try {
          const runSql = asUser(req);
          const result = await action(runSql, (ev) => send(ev));
          send({ phase: 'complete', result });
        } catch (err) {
          send({ phase: 'error', error: err instanceof Error ? err.message : String(err) });
        } finally {
          seedInFlight = false;
          res.end();
        }
      };

      app.post('/api/setup/seed', (req, res) =>
        streamSeed(req, res, (runSql, progress) => seedAll(runSql, progress)));
      app.post('/api/setup/refresh', (req, res) =>
        streamSeed(req, res, (runSql, progress) => seedAll(runSql, progress)));
      app.post('/api/setup/reset', (req, res) =>
        streamSeed(req, res, (runSql, progress) => resetAll(runSql, progress)));

      // Status: are the tables present + initialized? plus acceptance-check counts.
      app.get('/api/setup/status', async (req, res) => {
        try {
          const runSql = asUser(req);
          const checkRows = rowsOf(await runSql(
            `SELECT COUNT(*) AS n FROM ${fq('unified_metrics')}`,
          ));
          const n = Number(checkRows[0]?.n ?? 0);
          res.json({ initialized: n > 0, metricRows: n });
        } catch {
          res.json({ initialized: false, metricRows: 0 });
        }
      });

      // Acceptance checks for the Setup page.
      app.get('/api/setup/checks', async (req, res) => {
        try {
          const runSql = asUser(req);
          const one = async (sql: string) => rowsOf(await runSql(sql));
          const statusCounts = await one(
            `SELECT current_status, COUNT(*) AS n FROM ${fq('v_current_status')} GROUP BY current_status`);
          const dims = (await one(
            `SELECT COUNT(DISTINCT model_name || model_version) AS models,
                    COUNT(DISTINCT workspace) AS workspaces,
                    COUNT(DISTINCT region) AS regions FROM ${fq('model_registry')}`))[0] ?? {};
          const boundary = (await one(
            `SELECT SUM(raw_rows_exported) AS raw, SUM(log_rows_exported) AS log FROM ${fq('boundary_ledger')}`))[0] ?? {};
          const mu = (await one(
            `SELECT COUNT(*) AS n FROM ${fq('unified_metrics')} WHERE slice_value = 'MU'`))[0] ?? {};
          const nonAllow = (await one(
            `SELECT COUNT(*) AS n FROM ${fq('unified_metrics')} u
             LEFT JOIN ${fq('metric_allowlist')} a ON u.metric_name = a.metric_name
             WHERE a.metric_name IS NULL`))[0] ?? {};
          res.json({ statusCounts, dims, boundary, mu, nonAllow });
        } catch (err) {
          res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
        }
      });

      // ---------- IDENTITY ----------
      app.get('/api/whoami', (req, res) => {
        const email = (req.headers['x-forwarded-email'] as string | undefined)
          || (req.headers['x-forwarded-user'] as string | undefined)
          || null;
        res.json({ email, preview: !email });
      });

      // ---------- CONFIG ----------
      app.get('/api/config', (_req, res) => {
        res.json({
          catalog: CONFIG.catalog,
          schema: CONFIG.schema,
          genieSpaceId: CONFIG.genieSpaceId,
          genieConnected: Boolean(CONFIG.genieSpaceId),
        });
      });

      app.post('/api/config/genie', async (req, res) => {
        const parsed = z.object({ spaceId: z.string().min(1) }).safeParse(req.body);
        if (!parsed.success) {
          res.status(400).json({ error: 'spaceId is required' });
          return;
        }
        try {
          const runSql = asUser(req);
          await runSql(createSchemaSql());
          await runSql(createConfigTableSql());
          await runSql(
            `MERGE INTO ${fq('app_config')} t
             USING (SELECT 'genie_space_id' AS config_key, ${strLit(parsed.data.spaceId)} AS config_value) s
             ON t.config_key = s.config_key
             WHEN MATCHED THEN UPDATE SET config_value = s.config_value, updated_at = CURRENT_TIMESTAMP()
             WHEN NOT MATCHED THEN INSERT (config_key, config_value, updated_at)
             VALUES (s.config_key, s.config_value, CURRENT_TIMESTAMP())`);
          res.json({
            ok: true,
            note: 'Saved. Set DATABRICKS_GENIE_SPACE_ID in app.yaml to this value and restart to activate the Genie plugin.',
          });
        } catch (err) {
          res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
        }
      });

      // ---------- MODEL ONBOARDING ----------
      app.post('/api/models', async (req, res) => {
        const schema = z.object({
          model_name: z.string().min(1),
          model_version: z.string().min(1),
          workstream: z.string().min(1),
          workspace: z.string().min(1),
          region: z.string().min(1),
          serving_type: z.enum(['realtime', 'batch']),
          owner: z.string().min(1),
          upstream_feed: z.string().min(1),
          risk_tier: z.enum(['High', 'Medium', 'Low']),
        });
        const parsed = schema.safeParse(req.body);
        if (!parsed.success) {
          res.status(400).json({ error: 'Invalid input', fields: parsed.error.flatten().fieldErrors });
          return;
        }
        const m = parsed.data;
        try {
          const runSql = asUser(req);
          const dup = rowsOf(await runSql(
            `SELECT COUNT(*) AS n FROM ${fq('model_registry')}
             WHERE model_name = ${strLit(m.model_name)} AND model_version = ${strLit(m.model_version)}
               AND workspace = ${strLit(m.workspace)}`));
          if (Number(dup[0]?.n ?? 0) > 0) {
            res.status(409).json({ error: 'A model with this name + version already exists in this workspace.' });
            return;
          }
          await runSql(
            `INSERT INTO ${fq('model_registry')}
             (model_name, model_version, workstream, workspace, region, serving_type, owner, upstream_feed, risk_tier, onboarded_at, active)
             VALUES (${strLit(m.model_name)}, ${strLit(m.model_version)}, ${strLit(m.workstream)}, ${strLit(m.workspace)},
             ${strLit(m.region)}, ${strLit(m.serving_type)}, ${strLit(m.owner)}, ${strLit(m.upstream_feed)},
             ${strLit(m.risk_tier)}, CURRENT_TIMESTAMP(), TRUE)`);
          res.status(201).json({ ok: true });
        } catch (err) {
          res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
        }
      });

      // ---------- ALERT ACTIONS ----------
      app.post('/api/alerts/:id', async (req, res) => {
        const schema = z.object({
          action: z.enum(['ack', 'assign', 'resolve', 'note']),
          assignee: z.string().optional(),
          note: z.string().optional(),
        });
        const parsed = schema.safeParse(req.body);
        if (!parsed.success) {
          res.status(400).json({ error: 'Invalid input' });
          return;
        }
        const id = req.params.id;
        const { action, assignee, note } = parsed.data;
        const sets: string[] = [];
        if (action === 'ack') sets.push(`status = 'ACK'`);
        if (action === 'resolve') sets.push(`status = 'RESOLVED'`, `resolved_at = CURRENT_TIMESTAMP()`);
        if (assignee !== undefined) sets.push(`assignee = ${strLit(assignee)}`);
        if (note !== undefined) sets.push(`note = ${strLit(note)}`);
        if (sets.length === 0) {
          res.status(400).json({ error: 'Nothing to update' });
          return;
        }
        try {
          const runSql = asUser(req);
          await runSql(
            `UPDATE ${fq('alerts')} SET ${sets.join(', ')} WHERE alert_id = ${strLit(id)}`);
          res.json({ ok: true });
        } catch (err) {
          res.status(500).json({ error: err instanceof Error ? err.message : String(err) });
        }
      });
    });
  },
}).catch(console.error);
