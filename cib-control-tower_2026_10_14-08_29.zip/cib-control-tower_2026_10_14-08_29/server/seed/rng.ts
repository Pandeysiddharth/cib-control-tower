/** Deterministic, seeded pseudo-random utilities for reproducible synthetic data. */

/** FNV-1a 32-bit string hash → unsigned int seed. */
export function hashSeed(key: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < key.length; i++) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** mulberry32 PRNG. Returns a function producing floats in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Deterministic RNG keyed by an arbitrary string. */
export function rngFor(key: string): () => number {
  return mulberry32(hashSeed(key));
}

/** Uniform noise in [-pct, +pct] (fractional), deterministic from key. */
export function noise(key: string, pct: number): number {
  const r = rngFor(key)();
  return (r * 2 - 1) * pct;
}

/** Gaussian-ish value around mean with std (sum of two uniforms), deterministic. */
export function around(key: string, mean: number, std: number): number {
  const rnd = rngFor(key);
  const g = (rnd() + rnd() + rnd() - 1.5) / 1.5; // ~[-1,1], centered
  return mean + g * std;
}

export function clip(x: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, x));
}

export function round(x: number, dp: number): number {
  const f = Math.pow(10, dp);
  return Math.round(x * f) / f;
}
