/** DDL for the hub schema. All objects carry COMMENTS so Genie can reason about them. */
import { CONFIG, fq, schemaFqn } from '../config.js';

export function createSchemaSql(): string {
  return `CREATE SCHEMA IF NOT EXISTS ${schemaFqn()}
    COMMENT 'Unified Model Monitoring Control Tower hub. Aggregated monitoring metrics only — no customer data, inference rows, features, predictions or logs.'`;
}

export function createTableSqls(): string[] {
  return [
    `CREATE TABLE IF NOT EXISTS ${fq('unified_metrics')} (
      model_name STRING COMMENT 'Model name as registered in model_registry',
      model_version STRING COMMENT 'Model version string, e.g. v7',
      workspace STRING COMMENT 'Spoke Databricks workspace that produced the metric',
      region STRING COMMENT 'Cloud region of the spoke workspace',
      workstream STRING COMMENT 'Business workstream, e.g. Financial Crime Compliance',
      window_start TIMESTAMP COMMENT 'Start of the daily aggregation window',
      window_end TIMESTAMP COMMENT 'End of the daily aggregation window',
      slice_name STRING COMMENT "Slice dimension name; 'overall' for whole-model rows, e.g. 'country'",
      slice_value STRING COMMENT "Slice value; 'all' for whole-model rows, e.g. a country code",
      metric_name STRING COMMENT 'Metric name from metric_allowlist (row_count, prediction_drift_js, auc, ...)',
      metric_value DOUBLE COMMENT 'Aggregated metric value for the window and slice',
      threshold DOUBLE COMMENT 'Threshold used to decide status; NULL means informational',
      status STRING COMMENT 'OK, WARN or BREACH for this metric row',
      received_at TIMESTAMP COMMENT 'When the hub received this row; accuracy metrics arrive after the label lag'
    ) COMMENT 'One row per model, metric, daily window and slice. Aggregated monitoring metrics only — contains no customer or inference data.'`,

    `CREATE TABLE IF NOT EXISTS ${fq('model_registry')} (
      model_name STRING COMMENT 'Model name',
      model_version STRING COMMENT 'Model version',
      workstream STRING COMMENT 'Business workstream',
      workspace STRING COMMENT 'Spoke workspace hosting the model',
      region STRING COMMENT 'Region of the spoke workspace',
      serving_type STRING COMMENT 'realtime or batch',
      owner STRING COMMENT 'Model owner responsible for the model',
      upstream_feed STRING COMMENT 'Upstream data feed; models sharing a feed share upstream incidents',
      risk_tier STRING COMMENT 'High, Medium or Low model risk tier',
      onboarded_at TIMESTAMP COMMENT 'When the model was onboarded to monitoring',
      active BOOLEAN COMMENT 'Whether the model is currently active'
    ) COMMENT 'Registry of all monitored classical ML models across workspaces and regions.'`,

    `CREATE TABLE IF NOT EXISTS ${fq('metric_allowlist')} (
      metric_name STRING COMMENT 'Allowlisted metric name',
      description STRING COMMENT 'Human description of the metric',
      category STRING COMMENT 'Metric category: Volume, Data quality, Drift, Freshness, Performance, Accuracy',
      unit STRING COMMENT 'Unit of the metric value',
      default_threshold DOUBLE COMMENT 'Default threshold; NULL when the threshold is model-specific',
      breach_direction STRING COMMENT "ABOVE (value above threshold breaches) or BELOW (value below threshold breaches)"
    ) COMMENT 'The only metrics allowed to leave a spoke workspace. The export gate rejects anything not listed here.'`,

    `CREATE TABLE IF NOT EXISTS ${fq('alerts')} (
      alert_id STRING COMMENT 'Unique alert identifier',
      model_name STRING COMMENT 'Model the alert is for',
      workspace STRING COMMENT 'Workspace of the model',
      region STRING COMMENT 'Region of the model',
      metric_name STRING COMMENT "Metric that triggered the alert; 'sync_stale' means the workspace stopped reporting",
      severity STRING COMMENT 'Critical, High or Medium',
      opened_at TIMESTAMP COMMENT 'When the alert was opened',
      status STRING COMMENT 'OPEN, ACK or RESOLVED',
      assignee STRING COMMENT 'Person the alert is assigned to',
      note STRING COMMENT 'Free-text note on the alert',
      resolved_at TIMESTAMP COMMENT 'When the alert was resolved; NULL if still open'
    ) COMMENT 'Alerts raised from breaching metrics and stale workspaces.'`,

    `CREATE TABLE IF NOT EXISTS ${fq('boundary_ledger')} (
      workspace STRING COMMENT 'Spoke workspace',
      region STRING COMMENT 'Region of the workspace',
      run_date DATE COMMENT 'Window date the export covers',
      raw_rows_exported BIGINT COMMENT 'Always 0 — raw data never leaves the spoke',
      log_rows_exported BIGINT COMMENT 'Always 0 — logs never leave the spoke',
      metric_rows_exported BIGINT COMMENT 'Number of aggregated metric rows accepted by the export gate',
      bytes_transferred BIGINT COMMENT 'Approximate bytes of aggregated metrics transferred',
      rejected_fields_count INT COMMENT 'Number of fields the export gate rejected that day',
      suppressed_slices_count INT COMMENT 'Number of small slices suppressed (fewer than 100 records)',
      last_sync_at TIMESTAMP COMMENT 'When the workspace last synced metrics to the hub',
      transport_option STRING COMMENT 'Transport mechanism used by the spoke'
    ) COMMENT 'Data boundary ledger: proves only aggregated metrics leave each spoke workspace.'`,

    `CREATE TABLE IF NOT EXISTS ${fq('rejected_fields_log')} (
      workspace STRING COMMENT 'Spoke workspace',
      run_date DATE COMMENT 'Window date',
      field_name STRING COMMENT 'Name of the field the export gate blocked (never the value)',
      reason STRING COMMENT 'Why the field was blocked'
    ) COMMENT 'Fields blocked at the source by the export gate. Field names only, never values.'`,

    `CREATE TABLE IF NOT EXISTS ${fq('serving_cost_daily')} (
      date DATE COMMENT 'Day of the cost',
      workspace STRING COMMENT 'Workspace hosting the endpoint',
      region STRING COMMENT 'Region of the workspace',
      endpoint_name STRING COMMENT 'Serving endpoint or batch job name',
      model_name STRING COMMENT 'Model served by the endpoint',
      dbus DOUBLE COMMENT 'DBUs consumed that day',
      cost_usd DOUBLE COMMENT 'Cost in USD (dbus x 0.07)'
    ) COMMENT 'Daily serving cost per endpoint. Keeps flowing even when a workspace stops sending metrics.'`,
  ];
}

export function createViewSqls(): string[] {
  const um = fq('unified_metrics');
  const reg = fq('model_registry');
  const led = fq('boundary_ledger');
  return [
    `CREATE OR REPLACE VIEW ${fq('v_model_daily_status')} (
      model_name COMMENT 'Model name',
      model_version COMMENT 'Model version',
      workspace COMMENT 'Workspace',
      region COMMENT 'Region',
      workstream COMMENT 'Workstream',
      window_date COMMENT 'Window date',
      breach_metrics COMMENT 'Count of metrics in BREACH on this window (overall slice)',
      warn_metrics COMMENT 'Count of metrics in WARN on this window (overall slice)',
      worst_status COMMENT 'Worst status for the day: BREACH > WARN > OK'
    ) COMMENT 'Per model per window date: breach/warn counts and worst status, overall slice only.' AS
    SELECT model_name, model_version, workspace, region, workstream,
      CAST(window_start AS DATE) AS window_date,
      SUM(CASE WHEN status = 'BREACH' THEN 1 ELSE 0 END) AS breach_metrics,
      SUM(CASE WHEN status = 'WARN' THEN 1 ELSE 0 END) AS warn_metrics,
      CASE
        WHEN SUM(CASE WHEN status = 'BREACH' THEN 1 ELSE 0 END) > 0 THEN 'BREACH'
        WHEN SUM(CASE WHEN status = 'WARN' THEN 1 ELSE 0 END) > 0 THEN 'WARN'
        ELSE 'OK'
      END AS worst_status
    FROM ${um}
    WHERE slice_name = 'overall'
    GROUP BY model_name, model_version, workspace, region, workstream, CAST(window_start AS DATE)`,

    `CREATE OR REPLACE VIEW ${fq('v_current_status')} (
      model_name COMMENT 'Model name',
      model_version COMMENT 'Model version',
      workspace COMMENT 'Workspace',
      region COMMENT 'Region',
      workstream COMMENT 'Workstream',
      risk_tier COMMENT 'Risk tier from model_registry',
      owner COMMENT 'Model owner',
      upstream_feed COMMENT 'Upstream feed',
      serving_type COMMENT 'realtime or batch',
      breach_count COMMENT 'Number of metrics currently in BREACH (latest value per metric)',
      warn_count COMMENT 'Number of metrics currently in WARN',
      breached_metrics COMMENT 'Comma-separated breached metric names',
      warned_metrics COMMENT 'Comma-separated warned metric names',
      last_sync_at COMMENT 'Latest sync time for the workspace',
      latest_window COMMENT 'Latest window start seen for the model',
      current_status COMMENT "STALE, BREACH, WARN or OK. STALE means the workspace stopped sending metrics and must never be treated as healthy."
    ) COMMENT 'One row per model with its current status. Use this for right-now / current / latest questions.' AS
    WITH latest_metric AS (
      SELECT *, ROW_NUMBER() OVER (
        PARTITION BY model_name, model_version, workspace, metric_name
        ORDER BY window_start DESC, received_at DESC
      ) AS rn
      FROM ${um}
      WHERE slice_name = 'overall'
    ),
    cur AS (
      SELECT model_name, model_version, workspace, region, workstream,
        SUM(CASE WHEN status = 'BREACH' THEN 1 ELSE 0 END) AS breach_count,
        SUM(CASE WHEN status = 'WARN' THEN 1 ELSE 0 END) AS warn_count,
        CONCAT_WS(', ', COLLECT_LIST(CASE WHEN status = 'BREACH' THEN metric_name END)) AS breached_metrics,
        CONCAT_WS(', ', COLLECT_LIST(CASE WHEN status = 'WARN' THEN metric_name END)) AS warned_metrics,
        MAX(window_start) AS latest_window
      FROM latest_metric WHERE rn = 1
      GROUP BY model_name, model_version, workspace, region, workstream
    ),
    ws_sync AS (
      SELECT workspace, MAX(last_sync_at) AS last_sync_at FROM ${led} GROUP BY workspace
    ),
    global_sync AS (
      SELECT MAX(last_sync_at) AS newest_sync FROM ${led}
    )
    SELECT c.model_name, c.model_version, c.workspace, c.region, c.workstream,
      r.risk_tier, r.owner, r.upstream_feed, r.serving_type,
      c.breach_count, c.warn_count, c.breached_metrics, c.warned_metrics,
      s.last_sync_at, c.latest_window,
      CASE
        WHEN s.last_sync_at IS NULL OR s.last_sync_at < g.newest_sync - INTERVAL 30 HOURS THEN 'STALE'
        WHEN c.breach_count > 0 THEN 'BREACH'
        WHEN c.warn_count > 0 THEN 'WARN'
        ELSE 'OK'
      END AS current_status
    FROM cur c
    LEFT JOIN ${reg} r
      ON c.model_name = r.model_name AND c.model_version = r.model_version AND c.workspace = r.workspace
    LEFT JOIN ws_sync s ON c.workspace = s.workspace
    CROSS JOIN global_sync g`,
  ];
}

/** app_config persists small key/value app state (e.g. the Genie space id). */
export function createConfigTableSql(): string {
  return `CREATE TABLE IF NOT EXISTS ${fq('app_config')} (
    config_key STRING COMMENT 'Config key',
    config_value STRING COMMENT 'Config value',
    updated_at TIMESTAMP COMMENT 'Last update time'
  ) COMMENT 'Internal key/value store for Control Tower app settings.'`;
}

export const ALL_TABLE_NAMES = [
  'unified_metrics', 'model_registry', 'metric_allowlist', 'alerts',
  'boundary_ledger', 'rejected_fields_log', 'serving_cost_daily',
];

export function dropObjectsSqls(): string[] {
  return [
    `DROP VIEW IF EXISTS ${fq('v_current_status')}`,
    `DROP VIEW IF EXISTS ${fq('v_model_daily_status')}`,
    ...ALL_TABLE_NAMES.map((t) => `DROP TABLE IF EXISTS ${fq(t)}`),
  ];
}

export const CATALOG = CONFIG.catalog;
