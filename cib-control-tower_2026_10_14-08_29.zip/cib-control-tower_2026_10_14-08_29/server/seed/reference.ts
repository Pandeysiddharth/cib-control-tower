/** Static reference data: workspaces, models, metric allowlist, slices. */

export interface Workspace {
  workspace: string;
  region: string;
  transport: string;
}

export const WORKSPACES: Workspace[] = [
  { workspace: 'cib-fcc-prod-uks', region: 'UK South', transport: 'Option 1 - Shared catalog' },
  { workspace: 'cib-credit-prod-uks', region: 'UK South', transport: 'Option 1 - Shared catalog' },
  { workspace: 'cib-markets-prod-sea', region: 'Southeast Asia', transport: 'Option 2a - API push' },
  { workspace: 'cib-txnbank-prod-cin', region: 'Central India', transport: 'Option 2a - API push' },
];

/** The silent spoke that stops reporting for the last 3 window dates. */
export const SILENT_WORKSPACE = 'cib-markets-prod-sea';

export type Serving = 'realtime' | 'batch';
export type RiskTier = 'High' | 'Medium' | 'Low';

export interface ModelDef {
  model_name: string;
  model_version: string;
  workspace: string;
  workstream: string;
  serving_type: Serving;
  risk_tier: RiskTier;
  upstream_feed: string;
  owner: string;
  onboarded_months_ago: number;
  base_rows: number;
  label_lag_days: number | null; // null = no labels
  auc_baseline: number | null;
  auc_threshold: number | null;
  f1_baseline: number | null;
  f1_threshold: number | null;
  pos_rate: number | null; // baseline positive rate, null = none
  p95_ms: number | null; // realtime latency baseline
  slices: boolean;
}

export const MODELS: ModelDef[] = [
  {
    model_name: 'aml_alert_scorer', model_version: 'v7', workspace: 'cib-fcc-prod-uks',
    workstream: 'Financial Crime Compliance', serving_type: 'realtime', risk_tier: 'High',
    upstream_feed: 'transaction_monitoring_feed', owner: 'Priya Nair', onboarded_months_ago: 22,
    base_rows: 180000, label_lag_days: 14, auc_baseline: 0.88, auc_threshold: 0.80,
    f1_baseline: 0.62, f1_threshold: 0.50, pos_rate: 0.04, p95_ms: 120, slices: true,
  },
  {
    model_name: 'txn_fraud_classifier', model_version: 'v4', workspace: 'cib-fcc-prod-uks',
    workstream: 'Financial Crime Compliance', serving_type: 'realtime', risk_tier: 'High',
    upstream_feed: 'payments_gateway_feed', owner: 'Daniel Okoro', onboarded_months_ago: 18,
    base_rows: 2400000, label_lag_days: 7, auc_baseline: 0.96, auc_threshold: 0.90,
    f1_baseline: 0.78, f1_threshold: 0.50, pos_rate: 0.006, p95_ms: 45, slices: true,
  },
  {
    model_name: 'sanctions_name_match', model_version: 'v3', workspace: 'cib-fcc-prod-uks',
    workstream: 'Financial Crime Compliance', serving_type: 'realtime', risk_tier: 'High',
    upstream_feed: 'payments_gateway_feed', owner: 'Aisha Rahman', onboarded_months_ago: 15,
    base_rows: 650000, label_lag_days: 21, auc_baseline: 0.94, auc_threshold: 0.88,
    f1_baseline: 0.71, f1_threshold: 0.50, pos_rate: 0.012, p95_ms: 70, slices: false,
  },
  {
    model_name: 'kyc_risk_rating', model_version: 'v5', workspace: 'cib-fcc-prod-uks',
    workstream: 'Financial Crime Compliance', serving_type: 'batch', risk_tier: 'Medium',
    upstream_feed: 'kyc_customer_master_feed', owner: 'Priya Nair', onboarded_months_ago: 20,
    base_rows: 90000, label_lag_days: 30, auc_baseline: 0.85, auc_threshold: 0.78,
    f1_baseline: 0.66, f1_threshold: 0.50, pos_rate: 0.15, p95_ms: null, slices: true,
  },
  {
    model_name: 'corporate_pd', model_version: 'v12', workspace: 'cib-credit-prod-uks',
    workstream: 'Credit Risk', serving_type: 'batch', risk_tier: 'High',
    upstream_feed: 'obligor_financials_feed', owner: 'Marcus Webb', onboarded_months_ago: 24,
    base_rows: 42000, label_lag_days: 30, auc_baseline: 0.82, auc_threshold: 0.75,
    f1_baseline: 0.60, f1_threshold: 0.50, pos_rate: 0.035, p95_ms: null, slices: false,
  },
  {
    model_name: 'lgd_model', model_version: 'v6', workspace: 'cib-credit-prod-uks',
    workstream: 'Credit Risk', serving_type: 'batch', risk_tier: 'Medium',
    upstream_feed: 'collateral_valuation_feed', owner: 'Helena Vosa', onboarded_months_ago: 16,
    base_rows: 15000, label_lag_days: null, auc_baseline: null, auc_threshold: null,
    f1_baseline: null, f1_threshold: null, pos_rate: null, p95_ms: null, slices: false,
  },
  {
    model_name: 'early_warning_watchlist', model_version: 'v3', workspace: 'cib-credit-prod-uks',
    workstream: 'Credit Risk', serving_type: 'batch', risk_tier: 'Medium',
    upstream_feed: 'obligor_financials_feed', owner: 'Marcus Webb', onboarded_months_ago: 12,
    base_rows: 38000, label_lag_days: 60, auc_baseline: 0.79, auc_threshold: 0.70,
    f1_baseline: 0.60, f1_threshold: 0.45, pos_rate: 0.08, p95_ms: null, slices: false,
  },
  {
    model_name: 'trade_surveillance_anomaly', model_version: 'v2', workspace: 'cib-markets-prod-sea',
    workstream: 'Markets', serving_type: 'batch', risk_tier: 'High',
    upstream_feed: 'trade_blotter_feed', owner: 'Wei Lun Tan', onboarded_months_ago: 10,
    base_rows: 520000, label_lag_days: null, auc_baseline: null, auc_threshold: null,
    f1_baseline: null, f1_threshold: null, pos_rate: 0.01, p95_ms: null, slices: false,
  },
  {
    model_name: 'client_propensity', model_version: 'v4', workspace: 'cib-markets-prod-sea',
    workstream: 'Markets', serving_type: 'batch', risk_tier: 'Low',
    upstream_feed: 'client_interaction_feed', owner: 'Grace Lim', onboarded_months_ago: 14,
    base_rows: 120000, label_lag_days: 7, auc_baseline: 0.74, auc_threshold: 0.65,
    f1_baseline: 0.42, f1_threshold: 0.35, pos_rate: 0.09, p95_ms: null, slices: true,
  },
  {
    model_name: 'fx_flow_forecast', model_version: 'v3', workspace: 'cib-markets-prod-sea',
    workstream: 'Markets', serving_type: 'batch', risk_tier: 'Medium',
    upstream_feed: 'market_data_feed', owner: 'Wei Lun Tan', onboarded_months_ago: 9,
    base_rows: 8000, label_lag_days: null, auc_baseline: null, auc_threshold: null,
    f1_baseline: null, f1_threshold: null, pos_rate: null, p95_ms: null, slices: false,
  },
  {
    model_name: 'cashflow_forecast', model_version: 'v2', workspace: 'cib-txnbank-prod-cin',
    workstream: 'Transaction Banking', serving_type: 'batch', risk_tier: 'Medium',
    upstream_feed: 'payments_gateway_feed', owner: 'Rohan Mehta', onboarded_months_ago: 11,
    base_rows: 300000, label_lag_days: null, auc_baseline: null, auc_threshold: null,
    f1_baseline: null, f1_threshold: null, pos_rate: null, p95_ms: null, slices: false,
  },
  {
    model_name: 'trade_finance_risk', model_version: 'v3', workspace: 'cib-txnbank-prod-cin',
    workstream: 'Transaction Banking', serving_type: 'batch', risk_tier: 'High',
    upstream_feed: 'trade_docs_feed', owner: 'Rohan Mehta', onboarded_months_ago: 13,
    base_rows: 25000, label_lag_days: 30, auc_baseline: 0.83, auc_threshold: 0.76,
    f1_baseline: 0.60, f1_threshold: 0.50, pos_rate: 0.05, p95_ms: null, slices: true,
  },
];

export type BreachDir = 'ABOVE' | 'BELOW';

export interface AllowlistEntry {
  metric_name: string;
  description: string;
  category: string;
  unit: string;
  default_threshold: number | null;
  breach_direction: BreachDir;
}

export const ALLOWLIST: AllowlistEntry[] = [
  { metric_name: 'row_count', description: 'Scored record volume for the window. Model-specific threshold = 50% of the daily baseline.', category: 'Volume', unit: 'rows', default_threshold: null, breach_direction: 'BELOW' },
  { metric_name: 'null_pct', description: 'Percent of feature values that were null in the window.', category: 'Data quality', unit: 'percent', default_threshold: 5, breach_direction: 'ABOVE' },
  { metric_name: 'feature_psi_max', description: 'Maximum Population Stability Index across input features vs the training baseline.', category: 'Drift', unit: 'psi', default_threshold: 0.20, breach_direction: 'ABOVE' },
  { metric_name: 'prediction_drift_js', description: 'Jensen-Shannon divergence of the prediction distribution vs the baseline.', category: 'Drift', unit: 'js_divergence', default_threshold: 0.15, breach_direction: 'ABOVE' },
  { metric_name: 'positive_rate', description: 'Share of positive predictions. Model-specific threshold = 1.6x the baseline positive rate.', category: 'Drift', unit: 'ratio', default_threshold: null, breach_direction: 'ABOVE' },
  { metric_name: 'freshness_hours', description: 'Hours between the window end and when metrics were produced.', category: 'Freshness', unit: 'hours', default_threshold: 24, breach_direction: 'ABOVE' },
  { metric_name: 'latency_p95_ms', description: 'P95 serving latency in milliseconds (realtime models only).', category: 'Performance', unit: 'ms', default_threshold: 500, breach_direction: 'ABOVE' },
  { metric_name: 'error_rate_pct', description: 'Percent of serving requests returning an error (realtime models only).', category: 'Performance', unit: 'percent', default_threshold: 1.0, breach_direction: 'ABOVE' },
  { metric_name: 'auc', description: 'Area under the ROC curve. Model-specific threshold. Arrives after the label lag.', category: 'Accuracy', unit: 'score', default_threshold: null, breach_direction: 'BELOW' },
  { metric_name: 'f1', description: 'F1 score. Model-specific threshold. Arrives after the label lag.', category: 'Accuracy', unit: 'score', default_threshold: 0.50, breach_direction: 'BELOW' },
  { metric_name: 'precision', description: 'Precision. Model-specific threshold. Arrives after the label lag.', category: 'Accuracy', unit: 'score', default_threshold: 0.50, breach_direction: 'BELOW' },
  { metric_name: 'recall', description: 'Recall. Model-specific threshold. Arrives after the label lag.', category: 'Accuracy', unit: 'score', default_threshold: 0.50, breach_direction: 'BELOW' },
];

/** Country slices used for slice-aware models. MU is deliberately tiny and gets suppressed. */
export const COUNTRY_SHARES: { code: string; share: number }[] = [
  { code: 'SG', share: 0.22 },
  { code: 'HK', share: 0.20 },
  { code: 'GB', share: 0.30 },
  { code: 'IN', share: 0.18 },
  { code: 'AE', share: 0.10 },
];

/** Fields the spoke-side export gate blocks, with the reason logged (never the value). */
export const REJECTED_FIELD_CATALOG: { field: string; reason: string }[] = [
  { field: 'customer_id', reason: 'Potential identifier, not in the metrics contract' },
  { field: 'account_number', reason: 'Potential identifier, not in the metrics contract' },
  { field: 'client_name', reason: 'Potential identifier, not in the metrics contract' },
  { field: 'free_text_note', reason: 'Free text is not allowed in the metrics contract' },
  { field: 'top_values', reason: 'Frequent-value lists can expose real values' },
  { field: 'metric:frequent_items', reason: 'Frequent-value lists can expose real values' },
  { field: 'metric:column_max_value', reason: 'Raw value statistic, not on the metric allowlist' },
];

/** The contract columns that are allowed to leave a spoke workspace. */
export const CONTRACT_COLUMNS: string[] = [
  'model_name', 'model_version', 'workspace', 'region', 'workstream',
  'window_start', 'window_end', 'slice_name', 'slice_value',
  'metric_name', 'metric_value', 'threshold', 'status', 'received_at',
];

export const NUM_WINDOWS = 90;
