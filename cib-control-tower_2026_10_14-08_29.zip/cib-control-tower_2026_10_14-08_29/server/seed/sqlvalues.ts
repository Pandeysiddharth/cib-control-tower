/** Serialize JS values to safe Databricks SQL literals for bulk INSERT of synthetic data. */

function pad(n: number): string {
  return n < 10 ? '0' + n : String(n);
}

export function tsLit(d: Date): string {
  const s = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ` +
    `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
  return `TIMESTAMP '${s}'`;
}

export function dateLit(d: Date): string {
  return `DATE '${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}'`;
}

export function strLit(s: string): string {
  return `'${s.replace(/'/g, "''")}'`;
}

export function numLit(n: number | null): string {
  if (n === null || n === undefined || Number.isNaN(n)) return 'NULL';
  return String(n);
}

export function boolLit(b: boolean): string {
  return b ? 'TRUE' : 'FALSE';
}

export function strOrNull(s: string | null | undefined): string {
  return s === null || s === undefined ? 'NULL' : strLit(s);
}
