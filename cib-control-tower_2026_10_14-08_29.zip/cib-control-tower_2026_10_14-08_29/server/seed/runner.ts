/** Orchestrates idempotent schema creation and batched seeding of synthetic data. */
import { fq } from '../config.js';
import {
  createConfigTableSql, createSchemaSql, createTableSqls, createViewSqls, dropObjectsSqls,
} from './ddl.js';
import { GeneratedData, generate } from './generate.js';
import { boolLit, dateLit, numLit, strLit, strOrNull, tsLit } from './sqlvalues.js';

export type RunSql = (sql: string) => Promise<unknown>;
export interface ProgressEvent {
  phase: string;
  table?: string;
  inserted?: number;
  total?: number;
  message?: string;
}
export type ProgressFn = (ev: ProgressEvent) => void;

const BATCH = 500;

interface TableSpec {
  name: string;
  columns: string[];
  toValues: (row: Record<string, unknown>) => string;
}

function col(columns: string[]): string {
  return columns.join(', ');
}

const SPECS: Record<keyof GeneratedData, TableSpec> = {
  unified_metrics: {
    name: 'unified_metrics',
    columns: ['model_name', 'model_version', 'workspace', 'region', 'workstream', 'window_start',
      'window_end', 'slice_name', 'slice_value', 'metric_name', 'metric_value', 'threshold',
      'status', 'received_at'],
    toValues: (r) => `(${strLit(r.model_name as string)}, ${strLit(r.model_version as string)}, ` +
      `${strLit(r.workspace as string)}, ${strLit(r.region as string)}, ${strLit(r.workstream as string)}, ` +
      `${tsLit(r.window_start as Date)}, ${tsLit(r.window_end as Date)}, ${strLit(r.slice_name as string)}, ` +
      `${strLit(r.slice_value as string)}, ${strLit(r.metric_name as string)}, ${numLit(r.metric_value as number)}, ` +
      `${numLit(r.threshold as number | null)}, ${strLit(r.status as string)}, ${tsLit(r.received_at as Date)})`,
  },
  model_registry: {
    name: 'model_registry',
    columns: ['model_name', 'model_version', 'workstream', 'workspace', 'region', 'serving_type',
      'owner', 'upstream_feed', 'risk_tier', 'onboarded_at', 'active'],
    toValues: (r) => `(${strLit(r.model_name as string)}, ${strLit(r.model_version as string)}, ` +
      `${strLit(r.workstream as string)}, ${strLit(r.workspace as string)}, ${strLit(r.region as string)}, ` +
      `${strLit(r.serving_type as string)}, ${strLit(r.owner as string)}, ${strLit(r.upstream_feed as string)}, ` +
      `${strLit(r.risk_tier as string)}, ${tsLit(r.onboarded_at as Date)}, ${boolLit(r.active as boolean)})`,
  },
  metric_allowlist: {
    name: 'metric_allowlist',
    columns: ['metric_name', 'description', 'category', 'unit', 'default_threshold', 'breach_direction'],
    toValues: (r) => `(${strLit(r.metric_name as string)}, ${strLit(r.description as string)}, ` +
      `${strLit(r.category as string)}, ${strLit(r.unit as string)}, ${numLit(r.default_threshold as number | null)}, ` +
      `${strLit(r.breach_direction as string)})`,
  },
  alerts: {
    name: 'alerts',
    columns: ['alert_id', 'model_name', 'workspace', 'region', 'metric_name', 'severity',
      'opened_at', 'status', 'assignee', 'note', 'resolved_at'],
    toValues: (r) => `(${strLit(r.alert_id as string)}, ${strLit(r.model_name as string)}, ` +
      `${strLit(r.workspace as string)}, ${strLit(r.region as string)}, ${strLit(r.metric_name as string)}, ` +
      `${strLit(r.severity as string)}, ${tsLit(r.opened_at as Date)}, ${strLit(r.status as string)}, ` +
      `${strOrNull(r.assignee as string | null)}, ${strOrNull(r.note as string | null)}, ` +
      `${r.resolved_at ? tsLit(r.resolved_at as Date) : 'NULL'})`,
  },
  boundary_ledger: {
    name: 'boundary_ledger',
    columns: ['workspace', 'region', 'run_date', 'raw_rows_exported', 'log_rows_exported',
      'metric_rows_exported', 'bytes_transferred', 'rejected_fields_count', 'suppressed_slices_count',
      'last_sync_at', 'transport_option'],
    toValues: (r) => `(${strLit(r.workspace as string)}, ${strLit(r.region as string)}, ` +
      `${dateLit(r.run_date as Date)}, ${numLit(r.raw_rows_exported as number)}, ${numLit(r.log_rows_exported as number)}, ` +
      `${numLit(r.metric_rows_exported as number)}, ${numLit(r.bytes_transferred as number)}, ` +
      `${numLit(r.rejected_fields_count as number)}, ${numLit(r.suppressed_slices_count as number)}, ` +
      `${tsLit(r.last_sync_at as Date)}, ${strLit(r.transport_option as string)})`,
  },
  rejected_fields_log: {
    name: 'rejected_fields_log',
    columns: ['workspace', 'run_date', 'field_name', 'reason'],
    toValues: (r) => `(${strLit(r.workspace as string)}, ${dateLit(r.run_date as Date)}, ` +
      `${strLit(r.field_name as string)}, ${strLit(r.reason as string)})`,
  },
  serving_cost_daily: {
    name: 'serving_cost_daily',
    columns: ['date', 'workspace', 'region', 'endpoint_name', 'model_name', 'dbus', 'cost_usd'],
    toValues: (r) => `(${dateLit(r.date as Date)}, ${strLit(r.workspace as string)}, ${strLit(r.region as string)}, ` +
      `${strLit(r.endpoint_name as string)}, ${strLit(r.model_name as string)}, ${numLit(r.dbus as number)}, ` +
      `${numLit(r.cost_usd as number)})`,
  },
};

const SEED_ORDER: (keyof GeneratedData)[] = [
  'metric_allowlist', 'model_registry', 'unified_metrics', 'boundary_ledger',
  'rejected_fields_log', 'serving_cost_daily', 'alerts',
];

export async function initSchema(runSql: RunSql, progress: ProgressFn): Promise<void> {
  progress({ phase: 'schema', message: 'Creating schema' });
  await runSql(createSchemaSql());
  await runSql(createConfigTableSql());
  const tables = createTableSqls();
  for (let i = 0; i < tables.length; i++) {
    progress({ phase: 'tables', message: `Creating tables (${i + 1}/${tables.length})` });
    await runSql(tables[i]);
  }
  const views = createViewSqls();
  for (let i = 0; i < views.length; i++) {
    progress({ phase: 'views', message: `Creating views (${i + 1}/${views.length})` });
    await runSql(views[i]);
  }
}

async function truncateDataTables(runSql: RunSql): Promise<void> {
  for (const t of SEED_ORDER) {
    await runSql(`DELETE FROM ${fq(t)} WHERE 1=1`);
  }
}

async function insertTable(
  runSql: RunSql, spec: TableSpec, rows: readonly unknown[], progress: ProgressFn,
): Promise<void> {
  const total = rows.length;
  let inserted = 0;
  for (let i = 0; i < rows.length; i += BATCH) {
    const batch = rows.slice(i, i + BATCH);
    const values = batch.map((r) => spec.toValues(r as Record<string, unknown>)).join(',\n');
    await runSql(`INSERT INTO ${fq(spec.name)} (${col(spec.columns)}) VALUES\n${values}`);
    inserted += batch.length;
    progress({ phase: 'insert', table: spec.name, inserted, total });
  }
  if (total === 0) progress({ phase: 'insert', table: spec.name, inserted: 0, total: 0 });
}

export interface SeedResult { tables: Record<string, number>; }

export async function seedAll(
  runSql: RunSql, progress: ProgressFn, nowOverride?: Date,
): Promise<SeedResult> {
  await initSchema(runSql, progress);
  progress({ phase: 'clean', message: 'Clearing existing data' });
  await truncateDataTables(runSql);
  progress({ phase: 'generate', message: 'Generating synthetic metrics' });
  const data = generate(nowOverride);
  const counts: Record<string, number> = {};
  for (const key of SEED_ORDER) {
    const spec = SPECS[key];
    const rows = data[key];
    counts[spec.name] = rows.length;
    await insertTable(runSql, spec, rows, progress);
  }
  progress({ phase: 'done', message: 'Seed complete' });
  return { tables: counts };
}

export async function resetAll(runSql: RunSql, progress: ProgressFn): Promise<void> {
  progress({ phase: 'reset', message: 'Dropping objects' });
  for (const sql of dropObjectsSqls()) {
    await runSql(sql);
  }
  progress({ phase: 'done', message: 'Reset complete' });
}
