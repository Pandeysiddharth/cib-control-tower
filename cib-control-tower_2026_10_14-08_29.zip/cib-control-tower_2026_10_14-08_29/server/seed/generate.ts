/**
 * Deterministic synthetic data generator for the Control Tower hub.
 * Produces aggregated monitoring metrics only — never any customer / inference data.
 * All randomness is seeded so re-running yields identical data (idempotent seeds).
 */
import {
  ALLOWLIST, AllowlistEntry, COUNTRY_SHARES, ModelDef, MODELS,
  NUM_WINDOWS, REJECTED_FIELD_CATALOG, SILENT_WORKSPACE, WORKSPACES, BreachDir,
} from './reference.js';
import { around, clip, noise, rngFor, round } from './rng.js';

// ---------- row shapes ----------
export interface UnifiedMetricRow {
  model_name: string; model_version: string; workspace: string; region: string; workstream: string;
  window_start: Date; window_end: Date; slice_name: string; slice_value: string;
  metric_name: string; metric_value: number; threshold: number | null; status: string; received_at: Date;
}
export interface ModelRegistryRow {
  model_name: string; model_version: string; workstream: string; workspace: string; region: string;
  serving_type: string; owner: string; upstream_feed: string; risk_tier: string;
  onboarded_at: Date; active: boolean;
}
export interface AlertRow {
  alert_id: string; model_name: string; workspace: string; region: string; metric_name: string;
  severity: string; opened_at: Date; status: string; assignee: string | null; note: string | null;
  resolved_at: Date | null;
}
export interface BoundaryLedgerRow {
  workspace: string; region: string; run_date: Date; raw_rows_exported: number; log_rows_exported: number;
  metric_rows_exported: number; bytes_transferred: number; rejected_fields_count: number;
  suppressed_slices_count: number; last_sync_at: Date; transport_option: string;
}
export interface RejectedFieldRow { workspace: string; run_date: Date; field_name: string; reason: string; }
export interface ServingCostRow {
  date: Date; workspace: string; region: string; endpoint_name: string; model_name: string;
  dbus: number; cost_usd: number;
}

export interface GeneratedData {
  unified_metrics: UnifiedMetricRow[];
  model_registry: ModelRegistryRow[];
  metric_allowlist: AllowlistEntry[];
  alerts: AlertRow[];
  boundary_ledger: BoundaryLedgerRow[];
  rejected_fields_log: RejectedFieldRow[];
  serving_cost_daily: ServingCostRow[];
}

// ---------- date helpers ----------
function startOfDayUTC(d: Date): Date {
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
}
function addDays(d: Date, n: number): Date {
  return new Date(d.getTime() + n * 86400000);
}
function addMonths(d: Date, n: number): Date {
  const r = new Date(d);
  r.setUTCMonth(r.getUTCMonth() - n);
  return r;
}
function isWeekend(d: Date): boolean {
  const g = d.getUTCDay();
  return g === 0 || g === 6;
}

const CRITICAL_METRICS = new Set(['prediction_drift_js', 'feature_psi_max', 'auc', 'row_count', 'freshness_hours']);

function statusFor(value: number, threshold: number | null, dir: BreachDir, isRowCount: boolean): string {
  if (threshold === null) return 'OK';
  if (dir === 'ABOVE') {
    if (value > threshold) return 'BREACH';
    if (value > 0.8 * threshold) return 'WARN';
    return 'OK';
  }
  // BELOW
  if (value < threshold) return 'BREACH';
  const warnMult = isRowCount ? 1.4 : 1.05;
  if (value < threshold * warnMult) return 'WARN';
  return 'OK';
}

export function generate(nowOverride?: Date): GeneratedData {
  const now = nowOverride ?? new Date();
  // latest window date is "yesterday"
  const yesterday = addDays(startOfDayUTC(now), -1);

  const unified: UnifiedMetricRow[] = [];
  const modelReg: ModelRegistryRow[] = [];
  const alerts: AlertRow[] = [];
  const ledger: BoundaryLedgerRow[] = [];
  const rejected: RejectedFieldRow[] = [];
  const cost: ServingCostRow[] = [];

  const wsByName = new Map(WORKSPACES.map((w) => [w.workspace, w]));

  // ----- model_registry -----
  for (const m of MODELS) {
    const ws = wsByName.get(m.workspace)!;
    modelReg.push({
      model_name: m.model_name, model_version: m.model_version, workstream: m.workstream,
      workspace: m.workspace, region: ws.region, serving_type: m.serving_type, owner: m.owner,
      upstream_feed: m.upstream_feed, risk_tier: m.risk_tier,
      onboarded_at: addMonths(yesterday, m.onboarded_months_ago), active: true,
    });
  }

  const windowStart = (daysAgo: number) => addDays(yesterday, -daysAgo);
  const windowEnd = (daysAgo: number) => addDays(windowStart(daysAgo), 1);
  const receivedMorningAfter = (daysAgo: number, key: string) => {
    const base = windowEnd(daysAgo); // next day 00:00
    const mins = 150 + Math.floor(rngFor('rcv' + key)() * 25); // 02:30 - 02:55
    return new Date(base.getTime() + mins * 60000);
  };
  const receivedAfterLag = (daysAgo: number, lag: number, key: string) => {
    const base = addDays(windowStart(daysAgo), lag);
    const mins = 150 + Math.floor(rngFor('rcvl' + key)() * 25);
    return new Date(base.getTime() + mins * 60000);
  };

  const isSilent = (m: ModelDef, daysAgo: number) =>
    m.workspace === SILENT_WORKSPACE && daysAgo <= 2;

  // ----- per model, per window -----
  for (const m of MODELS) {
    const ws = wsByName.get(m.workspace)!;
    const addMetric = (
      daysAgo: number, slice_name: string, slice_value: string, metric_name: string,
      value: number, threshold: number | null, dir: BreachDir, received: Date,
    ) => {
      const isRc = metric_name === 'row_count';
      const status = statusFor(value, threshold, dir, isRc);
      unified.push({
        model_name: m.model_name, model_version: m.model_version, workspace: m.workspace,
        region: ws.region, workstream: m.workstream,
        window_start: windowStart(daysAgo), window_end: windowEnd(daysAgo),
        slice_name, slice_value, metric_name,
        metric_value: value, threshold, status, received_at: received,
      });
    };

    const rcThreshold = 0.5 * m.base_rows;
    const posThreshold = m.pos_rate !== null ? round(1.6 * m.pos_rate, 4) : null;

    for (let d = 0; d < NUM_WINDOWS; d++) {
      if (isSilent(m, d)) continue;
      const wStart = windowStart(d);
      const weekend = isWeekend(wStart);
      const wkFactor = weekend ? (m.serving_type === 'realtime' ? 0.8 : 0.95) : 1.0;
      const rcv = receivedMorningAfter(d, `${m.model_name}-${d}`);

      // story ramps
      const amlR = clip((25 - d) / 25, 0, 1); // story 1
      const outageDay = d <= 2; // story 2 window
      const corpDecay = clip((75 - d) / 45, 0, 1); // story 3

      // ---- row_count ----
      let rowCount = m.base_rows * (1 + noise(`rc${m.model_name}${d}`, 0.03)) * wkFactor;
      if (outageDay && (m.model_name === 'txn_fraud_classifier' || m.model_name === 'sanctions_name_match')) {
        rowCount = m.base_rows * (0.05 + noise(`out${m.model_name}${d}`, 0.01));
      } else if (outageDay && m.model_name === 'cashflow_forecast') {
        rowCount = m.base_rows * (0.60 + noise(`out${m.model_name}${d}`, 0.03));
      }
      rowCount = Math.max(1, Math.round(rowCount));
      addMetric(d, 'overall', 'all', 'row_count', rowCount, round(rcThreshold, 0), 'BELOW', rcv);

      // ---- null_pct ----
      let nullPct = clip(around(`np${m.model_name}${d}`, 1.0, 0.4), 0.1, 20);
      if (m.model_name === 'kyc_risk_rating' && (d === 9 || d === 10)) nullPct = 4.4 + noise(`kycnp${d}`, 0.05) * 2;
      addMetric(d, 'overall', 'all', 'null_pct', round(nullPct, 3), 5, 'ABOVE', rcv);

      // ---- feature_psi_max ----
      let psi = clip(around(`psi${m.model_name}${d}`, 0.05, 0.02), 0.005, 2);
      if (m.model_name === 'aml_alert_scorer') psi += 0.30 * amlR;
      if (outageDay && (m.model_name === 'txn_fraud_classifier' || m.model_name === 'sanctions_name_match')) psi += 0.12;
      addMetric(d, 'overall', 'all', 'feature_psi_max', round(psi, 3), 0.20, 'ABOVE', rcv);

      // ---- prediction_drift_js ----
      let drift = clip(around(`drift${m.model_name}${d}`, 0.05, 0.015), 0.005, 2);
      if (m.model_name === 'aml_alert_scorer') drift += 0.23 * Math.pow(amlR, 1.3);
      addMetric(d, 'overall', 'all', 'prediction_drift_js', round(drift, 3), 0.15, 'ABOVE', rcv);

      // ---- positive_rate ----
      if (m.pos_rate !== null) {
        let pr = m.pos_rate * (1 + noise(`pr${m.model_name}${d}`, 0.03));
        if (m.model_name === 'aml_alert_scorer') pr *= (1 + 1.2 * amlR);
        addMetric(d, 'overall', 'all', 'positive_rate', round(pr, 4), posThreshold, 'ABOVE', rcv);
      }

      // ---- freshness_hours ----
      let fresh = m.serving_type === 'realtime'
        ? clip(around(`fr${m.model_name}${d}`, 0.3, 0.1), 0.05, 5)
        : clip(around(`fr${m.model_name}${d}`, 5, 1.2), 1, 12);
      if (outageDay && (m.model_name === 'txn_fraud_classifier' || m.model_name === 'sanctions_name_match')) {
        fresh = 28 + noise(`frout${m.model_name}${d}`, 0.03) * 10; // ~28-29h
      } else if (outageDay && m.model_name === 'cashflow_forecast') {
        fresh = 20.5 + noise(`frout${m.model_name}${d}`, 0.03) * 5;
      } else if (m.model_name === 'lgd_model' && (d === 39 || d === 40)) {
        fresh = 30 + noise(`lgdfr${d}`, 0.02) * 5;
      } else if (m.model_name === 'fx_flow_forecast' && (d === 4 || d === 5)) {
        fresh = 21 + noise(`fxfr${d}`, 0.02) * 5;
      }
      addMetric(d, 'overall', 'all', 'freshness_hours', round(fresh, 2), 24, 'ABOVE', rcv);

      // ---- realtime-only performance metrics ----
      if (m.serving_type === 'realtime') {
        let lat = m.p95_ms! * (1 + noise(`lat${m.model_name}${d}`, 0.06));
        if (m.model_name === 'txn_fraud_classifier' && (d === 34 || d === 35)) lat = 640 + noise(`txnlat${d}`, 0.02) * 100;
        addMetric(d, 'overall', 'all', 'latency_p95_ms', round(lat, 1), 500, 'ABOVE', rcv);
        const err = clip(around(`err${m.model_name}${d}`, 0.12, 0.05), 0.01, 3);
        addMetric(d, 'overall', 'all', 'error_rate_pct', round(err, 3), 1.0, 'ABOVE', rcv);
      }

      // ---- accuracy metrics (arrive after label lag) ----
      if (m.label_lag_days !== null && d >= m.label_lag_days) {
        const lag = m.label_lag_days;
        const accRcv = receivedAfterLag(d, lag, `${m.model_name}-${d}`);
        let auc = m.auc_baseline!;
        let f1 = m.f1_baseline!;
        if (m.model_name === 'aml_alert_scorer') auc = m.auc_baseline! - 0.05 * amlR;
        if (m.model_name === 'corporate_pd') {
          auc = 0.82 - 0.12 * corpDecay; // smooth, no noise
          f1 = 0.60 - 0.10 * corpDecay;
        } else {
          auc += noise(`auc${m.model_name}${d}`, 0.01);
          f1 += noise(`f1${m.model_name}${d}`, 0.015);
        }
        const prec = f1 + 0.04;
        const rec = f1 - 0.04;
        addMetric(d, 'overall', 'all', 'auc', round(auc, 3), m.auc_threshold, 'BELOW', accRcv);
        addMetric(d, 'overall', 'all', 'f1', round(f1, 3), m.f1_threshold, 'BELOW', accRcv);
        addMetric(d, 'overall', 'all', 'precision', round(prec, 3), m.f1_threshold, 'BELOW', accRcv);
        addMetric(d, 'overall', 'all', 'recall', round(rec, 3), m.f1_threshold, 'BELOW', accRcv);
      }

      // ---- country slices (row_count, prediction_drift_js, positive_rate) ----
      if (m.slices) {
        for (const c of COUNTRY_SHARES) {
          const sliceRows = Math.max(1, Math.round(rowCount * c.share * (1 + noise(`src${m.model_name}${d}${c.code}`, 0.04))));
          addMetric(d, 'country', c.code, 'row_count', sliceRows, null, 'BELOW', rcv);

          let sDrift = clip(around(`sd${m.model_name}${d}${c.code}`, 0.05, 0.012), 0.005, 2);
          if (m.model_name === 'aml_alert_scorer' && c.code === 'SG') sDrift = 0.06 + 0.40 * Math.pow(amlR, 1.2);
          addMetric(d, 'country', c.code, 'prediction_drift_js', round(sDrift, 3), 0.15, 'ABOVE', rcv);

          if (m.pos_rate !== null) {
            let sPr = m.pos_rate * (1 + noise(`spr${m.model_name}${d}${c.code}`, 0.04));
            if (m.model_name === 'aml_alert_scorer' && c.code === 'SG') sPr *= (1 + 1.8 * amlR);
            addMetric(d, 'country', c.code, 'positive_rate', round(sPr, 4), posThreshold, 'ABOVE', rcv);
          }
        }
        // MU slice is tiny -> suppressed by the export gate, never stored in unified_metrics.
      }
    }
  }

  // ----- serving cost: continues for every model every day, even when the spoke is silent -----
  for (const m of MODELS) {
    const ws = wsByName.get(m.workspace)!;
    const endpoint = m.serving_type === 'realtime' ? `${m.model_name}-endpoint` : `${m.model_name}-batch-job`;
    for (let d = 0; d < NUM_WINDOWS; d++) {
      const wStart = windowStart(d);
      const weekend = isWeekend(wStart);
      const wkFactor = weekend ? (m.serving_type === 'realtime' ? 0.8 : 0.95) : 1.0;
      const dbus = (m.serving_type === 'realtime' ? 20 + m.base_rows / 20000 : 8 + m.base_rows / 60000)
        * (1 + noise(`dbus${m.model_name}${d}`, 0.05)) * wkFactor;
      cost.push({
        date: wStart, workspace: m.workspace, region: ws.region, endpoint_name: endpoint,
        model_name: m.model_name, dbus: round(dbus, 2), cost_usd: round(dbus * 0.07, 2),
      });
    }
  }

  // ----- boundary_ledger (per workspace per window) + rejected_fields -----
  for (const w of WORKSPACES) {
    for (let d = 0; d < NUM_WINDOWS; d++) {
      if (w.workspace === SILENT_WORKSPACE && d <= 2) continue; // silent spoke: no ledger
      const wStart = windowStart(d);
      // accepted metric rows for this workspace on this window
      const accepted = unified.filter(
        (r) => r.workspace === w.workspace && r.window_start.getTime() === wStart.getTime(),
      ).length;
      // suppressed slices = MU for each slice-model in this workspace that has slices
      const sliceModels = MODELS.filter((m) => m.workspace === w.workspace && m.slices).length;
      const suppressed = sliceModels; // one MU slice suppressed per slice-model per day

      // occasional rejected fields; force a few within the last 14 days
      const rejRng = rngFor(`rej${w.workspace}${d}`);
      let rejCount = 0;
      const forceRecent = d <= 14 && d % 4 === 0;
      if (forceRecent || rejRng() < 0.2) {
        const n = 1 + Math.floor(rejRng() * 3);
        const picks = new Set<number>();
        while (picks.size < n) picks.add(Math.floor(rejRng() * REJECTED_FIELD_CATALOG.length));
        for (const idx of picks) {
          const f = REJECTED_FIELD_CATALOG[idx];
          rejected.push({ workspace: w.workspace, run_date: wStart, field_name: f.field, reason: f.reason });
          rejCount++;
        }
      }

      const bytes = Math.round(accepted * 200 + 1500 + rngFor(`by${w.workspace}${d}`)() * 500);
      const syncMins = 150 + Math.floor(rngFor(`sync${w.workspace}${d}`)() * 25);
      const lastSync = new Date(windowEnd(d).getTime() + syncMins * 60000);
      ledger.push({
        workspace: w.workspace, region: w.region, run_date: wStart,
        raw_rows_exported: 0, log_rows_exported: 0, metric_rows_exported: accepted,
        bytes_transferred: bytes, rejected_fields_count: rejCount, suppressed_slices_count: suppressed,
        last_sync_at: lastSync, transport_option: w.transport,
      });
    }
  }

  // ----- alerts from consecutive BREACH runs on the overall slice -----
  let alertSeq = 1000;
  const nextId = () => `ALT-${++alertSeq}`;
  const byModelMetric = new Map<string, UnifiedMetricRow[]>();
  for (const r of unified) {
    if (r.slice_name !== 'overall' || r.threshold === null) continue;
    const key = `${r.model_name}|${r.metric_name}`;
    if (!byModelMetric.has(key)) byModelMetric.set(key, []);
    byModelMetric.get(key)!.push(r);
  }
  for (const [key, rows] of byModelMetric) {
    const [modelName, metricName] = key.split('|');
    const m = MODELS.find((x) => x.model_name === modelName)!;
    const ws = wsByName.get(m.workspace)!;
    // sort ascending by window_start
    rows.sort((a, b) => a.window_start.getTime() - b.window_start.getTime());
    let i = 0;
    while (i < rows.length) {
      if (rows[i].status !== 'BREACH') { i++; continue; }
      // find consecutive breach run (consecutive window dates)
      let j = i;
      while (
        j + 1 < rows.length &&
        rows[j + 1].status === 'BREACH' &&
        Math.round((rows[j + 1].window_start.getTime() - rows[j].window_start.getTime()) / 86400000) === 1
      ) j++;
      const first = rows[i];
      const last = rows[j];
      const ongoing = Math.round((yesterday.getTime() - last.window_start.getTime()) / 86400000) === 0;

      let severity: string;
      if (m.risk_tier === 'High' && CRITICAL_METRICS.has(metricName)) severity = 'Critical';
      else if (m.risk_tier === 'High' || m.risk_tier === 'Medium') severity = 'High';
      else severity = 'Medium';

      let status = ongoing ? 'OPEN' : 'RESOLVED';
      let assignee: string | null = ongoing ? null : 'Platform on-call';
      let note: string | null = ongoing ? null : 'Recovered, no action needed';
      let resolvedAt: Date | null = ongoing ? null : new Date(last.received_at.getTime() + 86400000);

      // txn_fraud_classifier open alerts are acknowledged (payments outage investigation)
      if (ongoing && m.model_name === 'txn_fraud_classifier') {
        status = 'ACK';
        assignee = 'Marcus Webb';
        note = 'Investigating payments_gateway_feed outage with the payments platform team';
      }

      alerts.push({
        alert_id: nextId(), model_name: m.model_name, workspace: m.workspace, region: ws.region,
        metric_name: metricName, severity, opened_at: first.received_at, status, assignee, note,
        resolved_at: resolvedAt,
      });
      i = j + 1;
    }
  }

  // ----- sync_stale alerts for the silent spoke's models -----
  const silentLastSync = (() => {
    // newest last_sync for the silent workspace
    const rows = ledger.filter((l) => l.workspace === SILENT_WORKSPACE);
    return rows.reduce((mx, r) => (r.last_sync_at > mx ? r.last_sync_at : mx), new Date(0));
  })();
  const newestSync = ledger.reduce((mx, r) => (r.last_sync_at > mx ? r.last_sync_at : mx), new Date(0));
  const hoursStale = Math.round((newestSync.getTime() - silentLastSync.getTime()) / 3600000);
  for (const m of MODELS.filter((x) => x.workspace === SILENT_WORKSPACE)) {
    const ws = wsByName.get(m.workspace)!;
    alerts.push({
      alert_id: nextId(), model_name: m.model_name, workspace: m.workspace, region: ws.region,
      metric_name: 'sync_stale', severity: m.risk_tier === 'High' ? 'Critical' : 'High',
      opened_at: new Date(silentLastSync.getTime() + 30 * 3600000), status: 'OPEN',
      assignee: null, note: `No metrics received for ~${hoursStale} hours (last sync ${silentLastSync.toISOString()}).`,
      resolved_at: null,
    });
  }

  return {
    unified_metrics: unified,
    model_registry: modelReg,
    metric_allowlist: ALLOWLIST,
    alerts,
    boundary_ledger: ledger,
    rejected_fields_log: rejected,
    serving_cost_daily: cost,
  };
}
